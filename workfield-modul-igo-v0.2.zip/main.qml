import QtQuick
import org.qfield
import org.qfield.core
import Theme

/**
 * WorkFieldGIS — MODUŁ „Inwentaryzacja IGO” jako wtyczka (wersja 0.1, 16.10.2026).
 *
 * Moduł instaluje się na gotowym APK, tak jak każda wtyczka. Po włączeniu
 * zgłasza swój silnik aplikacji: iface.zarejestrujModul(silnik). Panel
 * „Moduły” (prawa szuflada) buduje z silnik.opis() kartę modułu i „Nowy
 * projekt z modułu”. Wyłączona albo odinstalowana wtyczka znika z panelu
 * sama — aplikacja trzyma do silnika tylko słaby wskaźnik.
 *
 * Etap 1 (decyzja Piotra 16.10.2026): projekt + płaty + eksport.
 *  - projekt w EPSG:2180, przyciąganie w metrach, załączniki (moduły
 *    wyposażenia aplikacji: „przyciaganie”, „zalaczniki”);
 *  - warstwy: granica gminy, gminy sąsiednie, działki, płaty IGO;
 *  - JEDEN GATUNEK = JEDEN PŁAT (płaty różnych gatunków mogą na siebie
 *    zachodzić);
 *  - pola płatu jak w projekcie APPL HM Nakło (gatunek, jednostka, ilość,
 *    miejsce, data) — czyli układ zgłoszenia IGO — plus faza, obserwator,
 *    działka i stan zgłoszenia;
 *  - ortofoto GUGiK: akcja „Podkłady…” prowadzi do okna z odmianą Ortofoto.
 *
 * Etapy 2–4 (zgłoszenie mailem, raport PDF działek, model zasięgu) — patrz
 * claude/MODUL_IGO_plan.md.
 *
 * Diagnostyka: log z prefiksem "IGO:".
 */
Item {
  id: wtyczka

  readonly property string wersja: "0.2"

  Component.onCompleted: {
    if (typeof iface.zarejestrujModul !== "function") {
      log("ta wersja aplikacji nie ma rejestru modułów (iface.zarejestrujModul) — potrzebna nowsza");
      return;
    }
    iface.zarejestrujModul(silnik);
    log("moduł " + wersja + " zarejestrowany");
  }

  function log(t) {
    console.log("IGO: " + t);
    try {
      iface.logMessage("IGO: " + t);
    } catch (e) {}
  }

  QtObject {
    id: silnik

    // Gatunki: Polska nazwa (łacińska). Wartość zapisywana = to samo.
    // DO SPRAWDZENIA PRZEZ PIOTRA z listami IGO (unijną i krajową) — lista
    // jest w JEDNYM miejscu, nowa wersja wtyczki ją poprawia.
    readonly property var gatunki: [
      "barszcz Sosnowskiego (Heracleum sosnowskyi)",
      "barszcz Mantegazziego (Heracleum mantegazzianum)",
      "rdestowiec ostrokończysty (Reynoutria japonica)",
      "rdestowiec sachaliński (Reynoutria sachalinensis)",
      "rdestowiec czeski (Reynoutria ×bohemica)",
      "niecierpek gruczołowaty (Impatiens glandulifera)",
      "nawłoć kanadyjska (Solidago canadensis)",
      "nawłoć późna (Solidago gigantea)",
      "kolczurka klapowana (Echinocystis lobata)",
      "czeremcha amerykańska (Prunus serotina)",
      "klon jesionolistny (Acer negundo)",
      "robinia akacjowa (Robinia pseudoacacia)",
      "róża pomarszczona (Rosa rugosa)",
      "inny gatunek (wpisz w uwagach)"
    ]

    function mapa(lista) {
      return lista.map(function (x) {
        const m = {};
        m[x] = x;
        return m;
      });
    }

    function mapaPar(pary) {
      return pary.map(function (p) {
        const m = {};
        m[p[0]] = p[1];
        return m;
      });
    }

    function opis() {
      return {
        "id": "inwentaryzacja_igo",
        "nazwa": "Inwentaryzacja IGO",
        "wersja": wtyczka.wersja,
        "silnik": "InwentaryzacjaIGO",
        "opis": "Płaty inwazyjnych gatunków obcych (jeden gatunek = jeden płat), działki zamawiającego i znalezione w terenie, granice gmin. EPSG:2180, przyciąganie w metrach, załączniki; ortofoto GUGiK w oknie podkładów.",
        "wymaga_silnika": ["InwentaryzacjaIGO.rozpoznaj", "InwentaryzacjaIGO.raport"],
        "rozpoznanie": "InwentaryzacjaIGO.rozpoznaj",
        "role": [
          { "klucz": "opisGatunkow", "nazwa": "gatunki" },
          { "klucz": "opisDzialek", "nazwa": "działki" },
          { "klucz": "opisZgloszen", "nazwa": "zgłoszenia" }
        ],
        "przepis": {
          "uklad": "EPSG:2180",
          "grupa": "Inwentaryzacja IGO",
          "ustawienia": { "wfg_igo/warstwaPlatow": "platy_igo", "wfg_igo/warstwaDzialek": "dzialki" },
          "wyposazenie": ["przyciaganie", "zalaczniki"],
          // kolejność = kolejność dokładania; ostatnia na wierzchu legendy
          "warstwy": [
            { "nazwa": "gminy_sasiednie", "typ": "Polygon", "pola": [
              { "name": "teryt", "type": "text", "alias": "TERYT" },
              { "name": "nazwa", "type": "text", "alias": "Gmina" }
            ] },
            { "nazwa": "granica_gminy", "typ": "Polygon", "pola": [
              { "name": "teryt", "type": "text", "alias": "TERYT" },
              { "name": "nazwa", "type": "text", "alias": "Gmina" }
            ] },
            { "nazwa": "dzialki", "typ": "Polygon", "pola": [
              { "name": "teryt_dzialki", "type": "text", "alias": "Identyfikator działki (TERYT)" },
              { "name": "obreb", "type": "text", "alias": "Obręb" },
              { "name": "numer", "type": "text", "alias": "Numer działki" },
              { "name": "zrodlo", "type": "text", "alias": "Skąd działka", "widget": "ValueMap",
                "opcje": { "map": mapaPar([["z listy zamawiającego", "zamawiajacy"], ["znaleziona w terenie", "teren"]]) }, "domyslna": "'teren'" },
              { "name": "stan", "type": "text", "alias": "Stan kontroli", "widget": "ValueMap",
                "opcje": { "map": mapaPar([["niesprawdzona", "niesprawdzona"], ["sprawdzona — bez IGO", "bez_igo"], ["sprawdzona — z IGO", "z_igo"]]) }, "domyslna": "'niesprawdzona'" },
              { "name": "powierzchnia_ha", "type": "real", "alias": "Powierzchnia [ha]", "domyslna": "round($area / 10000, 4)", "przy_zmianie": true },
              { "name": "data_kontroli", "type": "date", "alias": "Data kontroli" },
              { "name": "uwagi", "type": "multiline", "alias": "Uwagi" }
            ] },
            { "nazwa": "platy_igo", "typ": "Polygon", "pola": [
              { "name": "gatunek", "type": "text", "alias": "Gatunek", "widget": "ValueMap", "opcje": { "map": mapa(gatunki) } },
              { "name": "jednostka", "type": "text", "alias": "Jednostka miary ilości", "widget": "ValueMap",
                "opcje": { "map": mapaPar([["powierzchnia [m²]", "m2"], ["liczba okazów [szt.]", "szt"]]) }, "domyslna": "'m2'" },
              { "name": "ilosc", "type": "real", "alias": "Ilość (m² albo okazy)",
                "domyslna": "if(\"jednostka\" = 'm2', round($area, 1), \"ilosc\")", "przy_zmianie": true },
              { "name": "powierzchnia_m2", "type": "real", "alias": "Powierzchnia płatu [m²]", "domyslna": "round($area, 1)", "przy_zmianie": true },
              { "name": "faza", "type": "text", "alias": "Faza rozwojowa", "widget": "ValueMap",
                "opcje": { "map": mapa(["siewki", "rozety", "kwitnące", "owocujące", "zamierające", "mieszane"]) } },
              { "name": "miejsce", "type": "text", "alias": "Opis lokalizacji" },
              { "name": "data_stwierdzenia", "type": "date", "alias": "Data stwierdzenia", "domyslna": "now()" },
              { "name": "obserwator", "type": "text", "alias": "Obserwator", "domyslna": "@wykonawca" },
              { "name": "teryt_dzialki", "type": "text", "alias": "Działka (TERYT)",
                "domyslna": "array_first(overlay_intersects(layer:='dzialki', expression:=\"teryt_dzialki\"))", "przy_zmianie": true },
              { "name": "zgloszony", "type": "text", "alias": "Zgłoszony do gminy", "widget": "ValueMap",
                "opcje": { "map": mapaPar([["nie", "nie"], ["tak", "tak"]]) }, "domyslna": "'nie'" },
              { "name": "data_zgloszenia", "type": "date", "alias": "Data zgłoszenia" },
              { "name": "uwagi", "type": "multiline", "alias": "Uwagi" }
            ] }
          ]
        },
        "akcje": [
          { "etykieta": "Podkłady, ortofoto i dane wysokościowe…", "okno": "podklady" },
          { "etykieta": "Raport płatów (CSV)", "czasownik": "InwentaryzacjaIGO.raport", "wyslij": "pliki",
            "komunikat": "Raport: {platy} płatów, {powierzchnia} m², gatunków: {gatunkow}; niezgłoszonych: {niezgloszone}. Pliki w RAPORTY/" }
        ]
      };
    }

    //! Warstwa po nazwie; w projekcie z Nakła płaty nazywają się „platy_IGO”.
    function warstwa(projekt, nazwy) {
      if (typeof NarzedziaProjektu === "undefined")
        return null;
      for (const n of nazwy) {
        const w = NarzedziaProjektu.warstwaPoNazwie(projekt, n);
        if (w)
          return w;
      }
      return null;
    }

    //! Pierwsza NIEPUSTA wartość z podanych pól. Brak pola i puste pole
    //! traktujemy tak samo: w aplikacji QgsFeature.attribute() dla pola,
    //! którego warstwa nie ma, potrafi oddać null, a nie undefined (16.10:
    //! projekt z Nakła pokazał „gatunki: — 71”, choć ma nazwa_gatunku).
    function wartosc(f, pola) {
      let jest = false;
      for (const p of pola) {
        const v = f.attribute(p);
        if (v === undefined)
          continue;
        jest = true;
        if (v !== null && String(v) !== "")
          return { "jest": true, "v": v };
      }
      return { "jest": jest, "v": null };
    }

    //! Zliczenie obiektów wg pierwszego istniejącego pola z `pola`;
    //! `polaSumy` — pola do zsumowania (np. powierzchnia).
    function zlicz(w, pola, polaSumy) {
      const wynik = { "obiekty": 0, "wg": {}, "suma": 0, "jestPole": false };
      if (!w)
        return wynik;
      const it = LayerUtils.createFeatureIteratorFromExpression(w, "TRUE");
      let ile = 0;
      while (it.hasNext() && ile < 20000) {
        const f = it.next();
        ile++;
        const a = wartosc(f, pola);
        if (a.jest) {
          wynik.jestPole = true;
          const k = a.v === null || String(a.v) === "" ? "—" : String(a.v);
          wynik.wg[k] = (wynik.wg[k] || 0) + 1;
        }
        if (polaSumy) {
          const b = wartosc(f, polaSumy);
          const liczba = parseFloat(b.v);
          if (!isNaN(liczba))
            wynik.suma += liczba;
        }
      }
      it.close();
      wynik.obiekty = ile;
      return wynik;
    }

    function skrot(wg) {
      // same puste („—”) to nie informacja: pole jest, ale nikt go nie wypełnia
      if (Object.keys(wg).length === 1 && wg["—"] !== undefined)
        return "";
      return Object.keys(wg).sort(function (a, b) {
        return wg[b] - wg[a];
      }).map(function (k) {
        return k.replace(/\s*\(.*\)$/, "") + " " + wg[k];
      }).join(", ");
    }

    function rozpoznaj(projekt) {
      const platy = warstwa(projekt, ["platy_igo", "platy_IGO"]);
      if (!platy)
        return { "blad": "brak warstwy platy_igo" };
      const dzialki = warstwa(projekt, ["dzialki"]);
      const g = zlicz(platy, ["gatunek", "nazwa_gatunku"], null);
      const z = zlicz(platy, ["zgloszony"], null);
      const d = dzialki ? zlicz(dzialki, ["stan"], null) : null;
      return {
        "warstwa": platy.name,
        "obiekty": g.obiekty,
        "opisGatunkow": g.jestPole ? skrot(g.wg) : "",
        "opisDzialek": d && d.jestPole ? d.obiekty + ": " + skrot(d.wg) : "",
        "opisZgloszen": z.jestPole ? skrot(z.wg) : "",
        "zModulu": iface.readProjectEntry("wfg_moduly", "inwentaryzacja_igo", "") !== ""
      };
    }

    // ── Geometria z WKT (bez API geometrii z QML) ─────────────────────────
    // Pole i środek liczone w układzie warstwy — dla 2180 to metry. Dla
    // układu kątowego pole jest bez sensu, więc wtedy zostaje puste.

    function pierscienie(wkt) {
      const wynik = [];
      const grupy = String(wkt).match(/\(\([^()]*(\)\s*,\s*\([^()]*)*\)\)/g) || [];
      for (const g of grupy) {
        const ringi = g.replace(/^\(\(|\)\)$/g, "").split(/\)\s*,\s*\(/);
        wynik.push(ringi.map(function (r) {
          return r.trim().split(/\s*,\s*/).map(function (pt) {
            const xy = pt.trim().split(/\s+/);
            return [parseFloat(xy[0]), parseFloat(xy[1])];
          });
        }));
      }
      return wynik;
    }

    function poleIsrodek(wkt) {
      let pole = 0, sx = 0, sy = 0;
      for (const poligon of pierscienie(wkt)) {
        for (let r = 0; r < poligon.length; r++) {
          const p = poligon[r];
          let a = 0, cx = 0, cy = 0;
          for (let k = 0; k < p.length - 1; k++) {
            const c = p[k][0] * p[k + 1][1] - p[k + 1][0] * p[k][1];
            a += c;
            cx += (p[k][0] + p[k + 1][0]) * c;
            cy += (p[k][1] + p[k + 1][1]) * c;
          }
          a /= 2;
          // zewnętrzny pierścień dodaje, otwory odejmują (bez względu na kierunek)
          const znak = r === 0 ? 1 : -1;
          pole += znak * Math.abs(a);
          if (r === 0 && a !== 0) {
            sx += cx / 6;
            sy += cy / 6;
          }
        }
      }
      // środek ciężkości sumy zewnętrznych pierścieni (wystarcza do zgłoszenia)
      let aZew = 0;
      for (const poligon of pierscienie(wkt)) {
        const p = poligon[0];
        let a = 0;
        for (let k = 0; k < p.length - 1; k++)
          a += p[k][0] * p[k + 1][1] - p[k + 1][0] * p[k][1];
        aZew += a / 2;
      }
      return { "pole": pole, "x": aZew !== 0 ? sx / aZew : NaN, "y": aZew !== 0 ? sy / aZew : NaN };
    }

    function csv(v) {
      const t = v === null || v === undefined ? "" : String(v);
      return /[;"\n]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t;
    }

    function liczba(v, miejsca) {
      return isNaN(v) ? "" : v.toFixed(miejsca).replace(".", ",");
    }

    function data(v) {
      if (v === null || v === undefined || v === "")
        return "";
      if (v instanceof Date)
        return Qt.formatDate(v, "yyyy-MM-dd");
      return String(v).substring(0, 10);
    }

    /**
     * Raport płatów: dwa pliki CSV (średnik, UTF-8 z BOM — Excel i LibreOffice
     * otwierają bez pytania) w <projekt>/RAPORTY/:
     *   platy_<data>.csv         — płat po płacie: gatunek, ilość, jednostka,
     *                              powierzchnia z geometrii, miejsce, data,
     *                              działka, zgłoszenie, środek X/Y;
     *   platy_gatunki_<data>.csv — zestawienie: gatunek, płatów, m².
     * Pola czytane po kilku nazwach, więc działa też na projekcie z Nakła
     * (nazwa_gatunku, Jednostka, Ilosc, miejsce, data_obserwacji).
     */
    function raport(projekt) {
      const platy = warstwa(projekt, ["platy_igo", "platy_IGO"]);
      if (!platy)
        return { "blad": "W projekcie nie ma warstwy platy_igo" };
      const uklad = platy.crs && platy.crs.authid ? platy.crs.authid : "";
      const metry = uklad !== "EPSG:4326" && uklad !== "EPSG:4258" && uklad !== "";
      const kolumny = [
        ["gatunek", ["gatunek", "nazwa_gatunku"]],
        ["ilosc", ["ilosc", "Ilosc"]],
        ["jednostka", ["jednostka", "Jednostka"]],
        ["faza", ["faza"]],
        ["miejsce", ["miejsce"]],
        ["data_stwierdzenia", ["data_stwierdzenia", "data_obserwacji"]],
        ["obserwator", ["obserwator"]],
        ["teryt_dzialki", ["teryt_dzialki"]],
        ["zgloszony", ["zgloszony"]],
        ["data_zgloszenia", ["data_zgloszenia"]],
        ["uwagi", ["uwagi", "UWAGI"]]
      ];
      const naglowek = ["lp", "fid"].concat(kolumny.map(function (k) {
        return k[0];
      })).concat(["powierzchnia_m2", "x", "y", "uklad"]);
      const wiersze = [naglowek.join(";")];
      const wg = {};
      let suma = 0, ile = 0, niezgloszone = 0;
      const it = LayerUtils.createFeatureIteratorFromExpression(platy, "TRUE");
      while (it.hasNext() && ile < 20000) {
        const f = it.next();
        ile++;
        let wkt = "";
        try {
          wkt = f.geometry.asWkt();
        } catch (e) {
          wkt = "";
        }
        const g = wkt ? poleIsrodek(wkt) : { "pole": NaN, "x": NaN, "y": NaN };
        const pole = metry ? g.pole : NaN;
        const w = [String(ile), String(f.id)];
        for (const k of kolumny) {
          const a = wartosc(f, k[1]);
          w.push(csv(k[0].indexOf("data") === 0 ? data(a.v) : a.v));
        }
        w.push(liczba(pole, 1), liczba(g.x, 2), liczba(g.y, 2), uklad);
        wiersze.push(w.join(";"));
        const gat = wartosc(f, ["gatunek", "nazwa_gatunku"]).v;
        const kl = gat === null ? "(bez gatunku)" : String(gat);
        if (!wg[kl])
          wg[kl] = { "platow": 0, "m2": 0 };
        wg[kl].platow++;
        if (!isNaN(pole)) {
          wg[kl].m2 += pole;
          suma += pole;
        }
        if (String(wartosc(f, ["zgloszony"]).v) !== "tak")
          niezgloszone++;
      }
      it.close();

      const zest = ["gatunek;platow;powierzchnia_m2"];
      Object.keys(wg).sort(function (a, b) {
        return wg[b].m2 - wg[a].m2;
      }).forEach(function (k) {
        zest.push(csv(k) + ";" + wg[k].platow + ";" + liczba(wg[k].m2, 1));
      });
      zest.push("RAZEM;" + ile + ";" + liczba(suma, 1));

      const dzis = Qt.formatDateTime(new Date(), "yyyy-MM-dd_hhmm");
      const katalog = projekt.homePath + "/RAPORTY/";
      const plik1 = katalog + "platy_" + dzis + ".csv";
      const plik2 = katalog + "platy_gatunki_" + dzis + ".csv";
      const bom = "\ufeff";
      const ok1 = iface.writeTextFile(plik1, bom + wiersze.join("\n") + "\n");
      const ok2 = iface.writeTextFile(plik2, bom + zest.join("\n") + "\n");
      wtyczka.log("raport: " + ile + " płatów, " + Math.round(suma) + " m2 -> " + plik1 + " (" + ok1 + "), " + plik2 + " (" + ok2 + ")");
      if (!ok1 || !ok2)
        return { "blad": "Nie udało się zapisać raportu w " + katalog };
      return {
        "platy": ile,
        "powierzchnia": Math.round(suma),
        "gatunkow": Object.keys(wg).filter(function (k) {
          return k !== "(bez gatunku)";
        }).length,
        "niezgloszone": niezgloszone,
        "pliki": [plik1, plik2]
      };
    }

    //! Zgodność wstecz: dawna akcja „Podsumowanie płatów” (0.1).
    function podsumuj(projekt) {
      return raport(projekt);
    }
  }
}
