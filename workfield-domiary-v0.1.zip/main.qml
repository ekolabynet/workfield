import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import Theme
import "obliczenia.js" as Obl

/**
 * WorkField Domiary — domiary dalmierzem od punktów RTK (bez tachimetru).
 *
 * Wersja 0.1 (07.10.2026).
 *
 * Punkty nawiązania:
 *   • GPS/RTK uśredniony (N próbek, odrzuca próbki gorsze niż próg dokładności),
 *   • punkt z warstwy punktowej (np. wcześniej zmierzone RTK),
 *   • celownik na środku mapy,
 *   • wpisane współrzędne X/Y PL-2000.
 *
 * Metody:
 *   1. przecięcie liniowe — 2 punkty + 2 odległości, wybór strony (lewa/prawa patrząc z 1 na 2),
 *   2. punkt na prostej / przedłużenie — od punktu 1 w kierunku 2 (albo wstecz),
 *   3. wcięcie liniowe — 3 i więcej odległości, MNK, σ₀, wskazanie błędnej odległości.
 *
 * Odległości: odczyt dalmierza (+ opcjonalny kąt pionowy dla odczytu skośnego);
 * redukcja do układu 2000: skala odwzorowania i wysokość (wyłączalna).
 * Obliczenia w PL-2000 strefy wyznaczonej z pierwszego punktu.
 *
 * Zapis: warstwa „Domiary” (zakładana w bazie projektu) albo wybrana warstwa punktowa,
 * oraz dziennik DOMIARY/dziennik_domiarow.csv w katalogu projektu.
 *
 * Dalmierz Bluetooth: jeszcze nie — wpisuje się odczyt z ekranu.
 * Diagnostyka: log z prefiksem "DOMIARY:".
 */
Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property var kontenerMapy: iface.findItemByObjectName("mapCanvasContainer")
  property var zrodloPozycji: iface.findItemByObjectName("positionSource")

  readonly property string wersja: "0.1"
  readonly property string nazwaWarstwy: "Domiary"
  readonly property var metody: [qsTr("Przecięcie liniowe (2 punkty)"), qsTr("Punkt na prostej / przedłużenie"), qsTr("Wcięcie liniowe (3 i więcej)")]

  //! Punkty nawiązania: [{ nazwa, e, n, h, s, zrodlo, wWarstwie, wDzienniku }] w PL-2000 `epsg`.
  property var punkty: []
  property int epsg: 0

  property int metoda: 0
  onMetodaChanged: przelicz()
  property int strona: 0            // przecięcie: 0 = lewa, 1 = prawa (patrząc z 1 na 2)
  property string wyb1: ""
  property string wyb2: ""
  property var wcieciePola: ({})    // nazwa → { uzyj, d, kat }
  property var wynik: null
  property string bladWyniku: ""

  property bool podglad: false
  property bool celownik: false
  property var rysunek: null

  property var warstwyPunktowe: []
  property var obiektyWarstwy: []
  property bool pokazWarstwe: false
  property bool pokazWpisz: false
  property bool pokazUstawienia: false

  // uśrednianie GPS
  property bool usrAktywne: false
  property string usrNazwa: ""
  property var usrProbki: []
  property int usrOdrzucone: 0
  property int usrTykniecia: 0
  property string usrStan: ""

  property string statusZapisu: ""

  Settings {
    id: ustawienia
    category: "WorkFieldDomiary"
    property string punktyJson: "[]"
    property int epsg: 0
    property real sigmaD: 0.02        // [m] odczyt + ustawienie dalmierza nad punktem
    property real maxHacc: 0.05       // [m] próbki GPS gorsze są odrzucane; 0 = bez progu
    property int liczbaProbek: 10
    property bool redukcja: true
    property real tolerancja: 0.05    // [m] ile „braku” w trójkącie zrzucić na pomiar
    property string warstwa: ""       // pusta = „Domiary” w bazie projektu
    property int licznik: 1
  }

  MapLayerModel {
    id: modelWarstw
    project: qgisProject
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(przycisk)
    if (kontenerMapy) {
      nakladka.parent = kontenerMapy
      nakladka.anchors.fill = kontenerMapy
    }
    try {
      var l = JSON.parse(ustawienia.punktyJson)
      if (Array.isArray(l)) {
        punkty = l
        epsg = l.length > 0 ? ustawienia.epsg : 0
      }
    } catch (e) {
      punkty = []
    }
    domyslneWybory()
    log("wtyczka " + wersja + " wczytana; mapa: " + (kontenerMapy ? "jest" : "BRAK")
        + ", GPS: " + (zrodloPozycji ? "jest" : "BRAK") + ", punktów: " + punkty.length)
  }

  QfToolButton {
    id: przycisk
    iconSource: 'icon.svg'
    iconColor: plugin.usrAktywne ? "#39ff14" : "#B0BEC5"
    bgcolor: plugin.usrAktywne ? "#1b5e20" : Theme.darkGray
    round: true
    onClicked: {
      if (plugin.celownik) {
        plugin.celownik = false
        plotno.requestPaint()
      }
      plugin.odswiezWarstwy()
      okno.open()
    }
  }

  // ══════════════════════════════════════════════════ pomocnicze

  function log(t) {
    console.log("DOMIARY: " + t)
    try { iface.logMessage("DOMIARY: " + t) } catch (e) {}
  }

  function toast(t) {
    if (mainWindow && mainWindow.displayToast)
      mainWindow.displayToast(t)
    log("toast: " + t)
  }

  function projectHome() {
    if (typeof qgisProject === "undefined" || !qgisProject || !qgisProject.homePath)
      return ""
    var p = qgisProject.homePath
    return p.endsWith("/") ? p : p + "/"
  }

  function mapSettings() {
    try { return iface.mapCanvas().mapSettings } catch (e) { return null }
  }

  function crs2000() {
    return CoordinateReferenceSystemUtils.fromDescription("EPSG:" + epsg)
  }

  function dwa(n) { return (n < 10 ? "0" : "") + n }

  function teraz() {
    var d = new Date()
    return d.getFullYear() + "-" + dwa(d.getMonth() + 1) + "-" + dwa(d.getDate()) + " "
      + dwa(d.getHours()) + ":" + dwa(d.getMinutes()) + ":" + dwa(d.getSeconds())
  }

  function cm(x) {
    return Obl.f(x * 100, 1) + " cm"
  }

  function strefaOpis() {
    return epsg > 0 ? qsTr("PL-2000 strefa %1 (EPSG:%2)").arg(Obl.STREFY[epsg].strefa).arg(epsg) : qsTr("układ ustali pierwszy punkt")
  }

  function nazwyPunktow() {
    return punkty.map(function (p) { return p.nazwa })
  }

  function punktONazwie(n) {
    for (var i = 0; i < punkty.length; i++)
      if (punkty[i].nazwa === n)
        return punkty[i]
    return null
  }

  // ══════════════════════════════════════════════════ punkty nawiązania

  function zapamietaj() {
    ustawienia.punktyJson = JSON.stringify(punkty)
    ustawienia.epsg = epsg
  }

  function domyslneWybory() {
    var n = nazwyPunktow()
    if (n.indexOf(wyb1) < 0)
      wyb1 = n.length > 0 ? n[0] : ""
    if (n.indexOf(wyb2) < 0 || wyb2 === wyb1)
      wyb2 = n.length > 1 ? (n[0] === wyb1 ? n[1] : n[0]) : ""
  }

  //! Ustala strefę z pierwszego punktu; dla kolejnych — tę samą.
  function strefaDla(lon) {
    if (epsg === 0)
      epsg = Obl.epsgDlaDlugosci(lon)
    return epsg
  }

  function nazwaNowego() {
    var t = poleNazwy.text.trim()
    return t !== "" ? t : Obl.nastepnaNazwa(punkty)
  }

  function dodajPunkt(p) {
    if (punktONazwie(p.nazwa)) {
      toast(qsTr("Punkt %1 już jest — nadaj inną nazwę albo usuń stary.").arg(p.nazwa))
      return false
    }
    p.wWarstwie = p.wWarstwie === true
    p.wDzienniku = false
    var l = punkty.slice()
    l.push(p)
    punkty = l
    zapamietaj()
    domyslneWybory()
    poleNazwy.text = ""
    log("punkt " + p.nazwa + ": e=" + p.e.toFixed(3) + " n=" + p.n.toFixed(3) + " s=" + p.s + " (" + p.zrodlo + ")")
    toast(qsTr("Dodano punkt %1 (σ %2)").arg(p.nazwa).arg(cm(p.s)))
    przelicz()
    return true
  }

  function usunPunkt(nazwa) {
    punkty = punkty.filter(function (p) { return p.nazwa !== nazwa })
    if (punkty.length === 0)
      epsg = 0
    zapamietaj()
    domyslneWybory()
    przelicz()
  }

  function wyczyscPunkty() {
    punkty = []
    epsg = 0
    wynik = null
    bladWyniku = ""
    wcieciePola = ({})
    podglad = false
    zapamietaj()
    domyslneWybory()
    plotno.requestPaint()
  }

  //! Punkt w dowolnym układzie (crs) → PL-2000 bieżącej strefy.
  function do2000(x, y, crs) {
    var w = GeometryUtils.reprojectPointToWgs84(GeometryUtils.point(x, y), crs)
    strefaDla(w.x)
    var p = GeometryUtils.reprojectPoint(GeometryUtils.point(x, y), crs, crs2000())
    return { e: p.x, n: p.y }
  }

  // ── GPS uśredniony
  function zaczniUsrednianie() {
    if (!zrodloPozycji) {
      toast(qsTr("Nie znalazłem źródła pozycji GPS."))
      return
    }
    if (!zrodloPozycji.active) {
      toast(qsTr("GPS jest wyłączony — włącz pozycjonowanie i spróbuj ponownie."))
      return
    }
    usrNazwa = nazwaNowego()
    if (punktONazwie(usrNazwa)) {
      toast(qsTr("Punkt %1 już jest — nadaj inną nazwę.").arg(usrNazwa))
      return
    }
    usrProbki = []
    usrOdrzucone = 0
    usrTykniecia = 0
    usrStan = qsTr("Zbieram próbki…")
    usrAktywne = true
    zegarGps.start()
    log("uśrednianie " + usrNazwa + " start")
  }

  function przerwijUsrednianie(powod) {
    zegarGps.stop()
    usrAktywne = false
    usrStan = powod
    log("uśrednianie przerwane: " + powod)
  }

  Timer {
    id: zegarGps
    interval: 1000
    repeat: true
    onTriggered: plugin.krokUsredniania()
  }

  function krokUsredniania() {
    usrTykniecia++
    var pi = null
    try { pi = zrodloPozycji.positionInformation } catch (e) { pi = null }
    var dobra = false
    var opisFix = ""
    if (pi) {
      var lat = pi.latitude, lon = pi.longitude
      var waznaPoz = isFinite(lat) && isFinite(lon) && (pi.latitudeValid !== false) && (pi.longitudeValid !== false) && !(lat === 0 && lon === 0)
      var hacc = (pi.haccValid === true || (pi.haccValid === undefined && isFinite(pi.hacc))) ? pi.hacc : NaN
      opisFix = pi.fixStatusDescription ? String(pi.fixStatusDescription) : ""
      if (waznaPoz) {
        if (ustawienia.maxHacc > 0 && !(hacc <= ustawienia.maxHacc)) {
          usrOdrzucone++
        } else {
          var h = (pi.elevationValid !== false && isFinite(pi.elevation)) ? pi.elevation : null
          var l = usrProbki.slice()
          l.push({ lon: lon, lat: lat, h: h, hacc: hacc, fix: opisFix })
          usrProbki = l
          dobra = true
        }
      }
    }
    usrStan = qsTr("Próbki: %1/%2   odrzucone: %3%4")
      .arg(usrProbki.length).arg(ustawienia.liczbaProbek).arg(usrOdrzucone)
      .arg(opisFix !== "" ? "   (" + opisFix + ")" : "")
    if (usrProbki.length >= ustawienia.liczbaProbek) {
      zakonczUsrednianie()
      return
    }
    if (usrTykniecia > ustawienia.liczbaProbek * 3 + 10)
      przerwijUsrednianie(qsTr("Przerwane: za mało dobrych próbek (%1 z %2). Dokładność gorsza niż %3 albo brak pozycji. Poczekaj na RTK fix albo podnieś próg w ustawieniach.")
                          .arg(usrProbki.length).arg(ustawienia.liczbaProbek).arg(cm(ustawienia.maxHacc)))
  }

  function zakonczUsrednianie() {
    zegarGps.stop()
    usrAktywne = false
    var pr = usrProbki
    try {
      strefaDla(pr[0].lon)
      var wgs = CoordinateReferenceSystemUtils.fromDescription("EPSG:4326")
      var c = crs2000()
      var pts = pr.map(function (q) {
        var p = GeometryUtils.reprojectPoint(GeometryUtils.point(q.lon, q.lat), wgs, c)
        return { e: p.x, n: p.y }
      })
      var se = 0, sn = 0, sh = 0, nh = 0, sacc = 0, nacc = 0
      for (var i = 0; i < pts.length; i++) {
        se += pts[i].e; sn += pts[i].n
        if (pr[i].h !== null) { sh += pr[i].h; nh++ }
        if (isFinite(pr[i].hacc)) { sacc += pr[i].hacc; nacc++ }
      }
      se /= pts.length; sn /= pts.length
      var r2 = 0
      for (var j = 0; j < pts.length; j++)
        r2 += Math.pow(pts[j].e - se, 2) + Math.pow(pts[j].n - sn, 2)
      var rozrzut = pts.length > 1 ? Math.sqrt(r2 / (pts.length - 1)) : 0
      var srAcc = nacc > 0 ? sacc / nacc : NaN
      var s = Math.max(isFinite(srAcc) ? srAcc : 0.05, rozrzut)
      var fix = pr[pr.length - 1].fix
      usrStan = ""
      dodajPunkt({
        nazwa: usrNazwa, e: se, n: sn, h: nh > 0 ? sh / nh : null, s: s,
        zrodlo: qsTr("GPS %1, %2 próbek, rozrzut %3").arg(fix !== "" ? fix : "").arg(pts.length).arg(cm(rozrzut))
      })
    } catch (e) {
      usrStan = qsTr("Nie udało się przeliczyć pozycji: ") + e
      log("uśrednianie: " + e)
    }
  }

  // ── celownik (środek mapy)
  function zaczniCelownik() {
    if (!kontenerMapy) {
      toast(qsTr("Nie znalazłem mapy."))
      return
    }
    usrNazwa = nazwaNowego()
    celownik = true
    okno.close()
    plotno.requestPaint()
  }

  function wezZCelownika() {
    var ms = mapSettings()
    if (!ms)
      return
    var srodek = ms.screenToCoordinate(Qt.point(nakladka.width / 2, nakladka.height / 2))
    try {
      var p = do2000(srodek.x, srodek.y, ms.destinationCrs)
      celownik = false
      if (dodajPunkt({ nazwa: usrNazwa, e: p.e, n: p.n, h: null, s: 0.5, zrodlo: qsTr("celownik na mapie (dokładność podkładu)") }))
        okno.open()
    } catch (e) {
      toast(qsTr("Nie udało się przeliczyć punktu: ") + e)
    }
    plotno.requestPaint()
  }

  // ── z warstwy punktowej
  function odswiezWarstwy() {
    var lista = []
    try {
      var n = modelWarstw.rowCount()
      for (var i = 0; i < n; i++) {
        var w = modelWarstw.get(i).LayerPointer
        if (!w)
          continue
        var pkt = false
        try { pkt = (w.geometryType() === 0) } catch (e) { pkt = false }
        if (pkt)
          lista.push({ warstwa: w, nazwa: modelWarstw.get(i).Name })
      }
    } catch (e) {
      log("nie umiem przejrzeć warstw: " + e)
    }
    warstwyPunktowe = lista
  }

  function wczytajObiekty(w) {
    var lista = []
    if (!w) {
      obiektyWarstwy = []
      return
    }
    try {
      var it = LayerUtils.createFeatureIteratorFromExpression(w, "TRUE")
      var ile = 0
      while (it.hasNext() && ile < 500) {
        var f = it.next()
        var opis = ""
        try { opis = FeatureUtils.displayName(w, f) } catch (e) {}
        lista.push({ obiekt: f, opis: (opis && opis !== "" ? String(opis) : "#" + f.id) })
        ile++
      }
      it.close()
    } catch (e) {
      log("nie umiem odczytać obiektów: " + e)
    }
    obiektyWarstwy = lista
  }

  function zObiektu(w, f, opis) {
    var wkt = ""
    try { wkt = f.geometry.asWkt() } catch (e) { wkt = "" }
    var q = Obl.punktZWkt(wkt)
    if (!q) {
      toast(qsTr("Obiekt nie jest punktem (albo ma pustą geometrię)."))
      return
    }
    try {
      var p = do2000(q.x, q.y, w.crs)
      var nazwa = poleNazwy.text.trim() !== "" ? poleNazwy.text.trim() : String(opis).substring(0, 20)
      dodajPunkt({ nazwa: nazwa, e: p.e, n: p.n, h: q.z, s: ustawienia.maxHacc > 0 ? ustawienia.maxHacc : 0.03,
                   zrodlo: qsTr("warstwa %1: %2").arg(w.name).arg(opis), wWarstwie: true })
    } catch (e) {
      toast(qsTr("Nie udało się przeliczyć punktu: ") + e)
    }
  }

  // ── wpisany
  function zWpisu() {
    var x = Obl.liczba(poleX.text), y = Obl.liczba(poleY.text), s = Obl.liczba(poleS.text)
    if (!isFinite(x) || !isFinite(y)) {
      toast(qsTr("Podaj X i Y (PL-2000, w metrach)."))
      return
    }
    // Y w PL-2000 zaczyna się cyfrą strefy (5–8)
    var strefa = Math.floor(y / 1000000)
    var e = 2171 + strefa
    if (!Obl.STREFY[e]) {
      toast(qsTr("Y = %1 nie wygląda na PL-2000 (powinno zaczynać się od 5, 6, 7 albo 8).").arg(poleY.text))
      return
    }
    if (epsg !== 0 && e !== epsg) {
      toast(qsTr("Ten punkt jest w strefie %1, a pozostałe w strefie %2 — nie mieszam stref.").arg(strefa).arg(Obl.STREFY[epsg].strefa))
      return
    }
    epsg = e
    if (dodajPunkt({ nazwa: nazwaNowego(), e: y, n: x, h: null, s: isFinite(s) ? s / 100 : 0.02, zrodlo: qsTr("wpisany") })) {
      poleX.text = ""
      poleY.text = ""
    }
  }

  // ══════════════════════════════════════════════════ obliczenie

  function odczyt(tekstD, tekstKat) {
    var d = Obl.liczba(tekstD)
    var k = Obl.liczba(tekstKat)
    return { d: d, kat: isFinite(k) ? k : null, poz: Obl.pozioma(d, isFinite(k) ? k : null) }
  }

  function opisOdczytu(nazwa, o, wsp) {
    var t = nazwa + " " + Obl.f(o.d, 3)
    if (o.kat !== null)
      t += " (kąt " + Obl.f(o.kat, 1) + "°, poz. " + Obl.f(o.poz, 3) + ")"
    if (wsp !== 1)
      t += " → " + Obl.f(o.poz * wsp, 3)
    return t
  }

  function przelicz() {
    wynik = null
    bladWyniku = ""
    statusZapisu = ""
    try {
      if (metoda === 0)
        liczPrzeciecie()
      else if (metoda === 1)
        liczNaProstej()
      else
        liczWciecie()
    } catch (e) {
      bladWyniku = qsTr("Błąd obliczenia: ") + e
      log("przelicz: " + e)
    }
    zbudujRysunek()
  }

  function liczPrzeciecie() {
    var A = punktONazwie(wyb1), B = punktONazwie(wyb2)
    if (!A || !B || A === B) {
      bladWyniku = punkty.length < 2 ? qsTr("Potrzebne są dwa punkty nawiązania.") : qsTr("Wybierz dwa różne punkty.")
      return
    }
    var oA = odczyt(poleD1.text, poleK1.text), oB = odczyt(poleD2.text, poleK2.text)
    if (!(oA.d > 0) || !(oB.d > 0)) {
      bladWyniku = qsTr("Wpisz odległości od %1 i od %2.").arg(A.nazwa).arg(B.nazwa)
      return
    }
    var wsp = Obl.wspolczynnik([A, B], epsg, ustawienia.redukcja)
    var dA = oA.poz * wsp, dB = oB.poz * wsp
    var r = Obl.przeciecie(A, B, dA, dB, ustawienia.tolerancja)
    if (r.blad) {
      bladWyniku = r.blad
      return
    }
    var p = strona === 0 ? r.lewy : r.prawy
    var obs = [{ stacja: A, d: dA, sd: ustawienia.sigmaD }, { stacja: B, d: dB, sd: ustawienia.sigmaD }]
    var oc = Obl.ocena(p, obs)
    var szczegoly = qsTr("Strona: %1 (patrząc z %2 na %3)\nKąt przecięcia: %4°   baza %2–%3: %5 m\nBłąd położenia mp = %6   (elipsa %7 × %8)")
      .arg(strona === 0 ? qsTr("lewa") : qsTr("prawa")).arg(A.nazwa).arg(B.nazwa)
      .arg(Obl.f(r.gamma, 0)).arg(Obl.f(r.baza, 3))
      .arg(cm(oc.mp)).arg(cm(oc.osA)).arg(cm(oc.osB))
    wynik = {
      metoda: qsTr("przecięcie liniowe"), punkt: p, mp: oc.mp, wsp: wsp,
      szczegoly: szczegoly, uwagi: r.uwagi,
      kandydaci: [{ e: r.lewy.e, n: r.lewy.n, etykieta: qsTr("lewa") }, { e: r.prawy.e, n: r.prawy.n, etykieta: qsTr("prawa") }],
      stacje: [A, B], okregi: [{ s: A, d: dA }, { s: B, d: dB }],
      nawiazania: A.nazwa + ", " + B.nazwa,
      odleglosci: opisOdczytu(A.nazwa, oA, wsp) + "; " + opisOdczytu(B.nazwa, oB, wsp),
      poprawki: ""
    }
  }

  function liczNaProstej() {
    var A = punktONazwie(wyb1), B = punktONazwie(wyb2)
    if (!A || !B || A === B) {
      bladWyniku = punkty.length < 2 ? qsTr("Potrzebne są dwa punkty nawiązania.") : qsTr("Wybierz dwa różne punkty.")
      return
    }
    var o = odczyt(poleD1.text, poleK1.text)
    if (!(o.d >= 0)) {
      bladWyniku = qsTr("Wpisz odległość od %1.").arg(A.nazwa)
      return
    }
    var wsp = Obl.wspolczynnik([A, B], epsg, ustawienia.redukcja)
    var r = Obl.naProstej(A, B, o.poz * wsp, wsteczPole.checked, ustawienia.sigmaD)
    if (r.blad) {
      bladWyniku = r.blad
      return
    }
    var szczegoly = qsTr("Położenie: %1\nBaza %2–%3: %4 m\nBłąd położenia mp = %5   (wzdłuż %6, w poprzek %7)")
      .arg(r.opis).arg(A.nazwa).arg(B.nazwa).arg(Obl.f(r.baza, 3))
      .arg(cm(r.mp)).arg(cm(r.wzdluzny)).arg(cm(r.poprzeczny))
    wynik = {
      metoda: wsteczPole.checked || r.t > 1 ? qsTr("przedłużenie prostej") : qsTr("punkt na prostej"),
      punkt: r.punkt, mp: r.mp, wsp: wsp, szczegoly: szczegoly, uwagi: r.uwagi,
      kandydaci: [{ e: r.punkt.e, n: r.punkt.n, etykieta: "" }],
      stacje: [A, B], okregi: [], linia: true,
      nawiazania: A.nazwa + " → " + B.nazwa,
      odleglosci: opisOdczytu(A.nazwa, o, wsp) + (wsteczPole.checked ? " (wstecz)" : ""),
      poprawki: ""
    }
  }

  function liczWciecie() {
    var obs = [], uzyte = [], opisy = []
    var wsp = 1
    var kandydatki = []
    for (var i = 0; i < punkty.length; i++) {
      var pole = wcieciePola[punkty[i].nazwa]
      if (!pole || pole.uzyj === false)
        continue
      var o = odczyt(pole.d, pole.kat)
      if (!(o.d > 0))
        continue
      kandydatki.push({ st: punkty[i], o: o })
    }
    if (kandydatki.length < 3) {
      bladWyniku = qsTr("Wcięcie: wpisz odległości do co najmniej 3 punktów (teraz %1).").arg(kandydatki.length)
      return
    }
    wsp = Obl.wspolczynnik(kandydatki.map(function (k) { return k.st }), epsg, ustawienia.redukcja)
    for (var j = 0; j < kandydatki.length; j++) {
      obs.push({ stacja: kandydatki[j].st, d: kandydatki[j].o.poz * wsp, sd: ustawienia.sigmaD })
      uzyte.push(kandydatki[j].st)
      opisy.push(opisOdczytu(kandydatki[j].st.nazwa, kandydatki[j].o, wsp))
    }
    var r = Obl.wciecie(obs, ustawienia.tolerancja)
    if (r.blad) {
      bladWyniku = r.blad
      return
    }
    var oc = r.ocena
    var popr = oc.poprawki.map(function (q) { return q.nazwa + " " + (q.v >= 0 ? "+" : "") + Obl.f(q.v * 100, 1) + " cm" })
    var szczegoly = qsTr("Odległości: %1 (nadmiarowych: %2)\nBłąd położenia mp = %3   (elipsa %4 × %5)\nσ₀ = %6   odchyłki: %7")
      .arg(obs.length).arg(obs.length - 2)
      .arg(cm(oc.mp)).arg(cm(oc.osA)).arg(cm(oc.osB))
      .arg(oc.sigma0 !== null ? Obl.f(oc.sigma0, 2) : "—").arg(popr.join(", "))
    var kand = [{ e: r.punkt.e, n: r.punkt.n, etykieta: "" }]
    wynik = {
      metoda: qsTr("wcięcie liniowe"), punkt: r.punkt, mp: oc.mp, wsp: wsp,
      szczegoly: szczegoly, uwagi: r.uwagi, kandydaci: kand,
      alternatywa: r.alternatywa,
      stacje: uzyte, okregi: obs.map(function (q) { return { s: q.stacja, d: q.d } }),
      nawiazania: uzyte.map(function (s) { return s.nazwa }).join(", "),
      odleglosci: opisy.join("; "),
      poprawki: oc.poprawki.map(function (q) { return q.nazwa + " " + Obl.f(q.v, 3) }).join("; ")
    }
  }

  // ══════════════════════════════════════════════════ podgląd na mapie

  function doMapy(e, n, c, ms) {
    var m = GeometryUtils.reprojectPoint(GeometryUtils.point(e, n), c, ms.destinationCrs)
    return { x: m.x, y: m.y }
  }

  function zbudujRysunek() {
    var ms = mapSettings()
    if (!ms || epsg === 0) {
      rysunek = null
      plotno.requestPaint()
      return
    }
    try {
      var c = crs2000()
      var r = { crs: ms.destinationCrs.authid, stacje: [], kandydaci: [], okregi: [], linie: [] }
      for (var i = 0; i < punkty.length; i++) {
        var m = doMapy(punkty[i].e, punkty[i].n, c, ms)
        r.stacje.push({ x: m.x, y: m.y, nazwa: punkty[i].nazwa })
      }
      if (wynik) {
        for (var k = 0; k < wynik.kandydaci.length; k++) {
          var q = wynik.kandydaci[k]
          var mq = doMapy(q.e, q.n, c, ms)
          var wybrany = wynik.kandydaci.length === 1 || k === strona
          r.kandydaci.push({ x: mq.x, y: mq.y, etykieta: q.etykieta, wybrany: wybrany })
        }
        for (var o = 0; o < wynik.okregi.length; o++) {
          var ok = wynik.okregi[o]
          var pier = []
          for (var a = 0; a <= 72; a++) {
            var t = a * Math.PI / 36
            pier.push(doMapy(ok.s.e + ok.d * Math.sin(t), ok.s.n + ok.d * Math.cos(t), c, ms))
          }
          r.okregi.push(pier)
        }
        var cel = doMapy(wynik.punkt.e, wynik.punkt.n, c, ms)
        for (var s = 0; s < wynik.stacje.length; s++) {
          var ms2 = doMapy(wynik.stacje[s].e, wynik.stacje[s].n, c, ms)
          r.linie.push([ms2, cel])
        }
      }
      rysunek = r
    } catch (e) {
      log("rysunek: " + e)
      rysunek = null
    }
    plotno.requestPaint()
  }

  Item {
    id: nakladka
    visible: plugin.podglad || plugin.celownik
    z: 900

    function naEkran(p) {
      var ms = plugin.mapSettings()
      if (!ms)
        return Qt.point(0, 0)
      return ms.coordinateToScreen(GeometryUtils.point(p.x, p.y))
    }

    Connections {
      target: plugin.mapSettings()
      ignoreUnknownSignals: true
      function onExtentChanged() { plotno.requestPaint() }
      function onVisibleExtentChanged() { plotno.requestPaint() }
      function onDestinationCrsChanged() { plugin.zbudujRysunek() }
    }

    Canvas {
      id: plotno
      anchors.fill: parent
      onPaint: {
        var ctx = getContext("2d")
        ctx.reset()
        var r = plugin.rysunek
        if (plugin.podglad && r) {
          // okręgi odległości
          ctx.lineWidth = 1.5
          ctx.strokeStyle = "#aa00e5ff"
          for (var o = 0; o < r.okregi.length; o++) {
            ctx.beginPath()
            for (var i = 0; i < r.okregi[o].length; i++) {
              var e = nakladka.naEkran(r.okregi[o][i])
              if (i === 0) ctx.moveTo(e.x, e.y)
              else ctx.lineTo(e.x, e.y)
            }
            ctx.stroke()
          }
          // linie stacja → punkt
          ctx.lineWidth = 2
          ctx.strokeStyle = "#ffea00"
          for (var l = 0; l < r.linie.length; l++) {
            var a = nakladka.naEkran(r.linie[l][0]), b = nakladka.naEkran(r.linie[l][1])
            ctx.beginPath()
            ctx.moveTo(a.x, a.y)
            ctx.lineTo(b.x, b.y)
            ctx.stroke()
          }
          // kandydaci
          for (var k = 0; k < r.kandydaci.length; k++) {
            var q = r.kandydaci[k]
            var s = nakladka.naEkran(q)
            ctx.fillStyle = q.wybrany ? "#ff1744" : "#80ff9100"
            ctx.strokeStyle = "#ffffff"
            ctx.lineWidth = 2
            ctx.beginPath()
            ctx.arc(s.x, s.y, q.wybrany ? 9 : 7, 0, 2 * Math.PI)
            ctx.fill()
            ctx.stroke()
            if (q.etykieta !== "") {
              ctx.font = "bold 15px sans-serif"
              ctx.fillStyle = "#000000"
              ctx.fillText(q.etykieta, s.x + 13, s.y + 6)
              ctx.fillStyle = q.wybrany ? "#ff1744" : "#ff9100"
              ctx.fillText(q.etykieta, s.x + 12, s.y + 5)
            }
          }
        }
        if ((plugin.podglad || plugin.celownik) && r) {
          // punkty nawiązania: trójkąty
          for (var t = 0; t < r.stacje.length; t++) {
            var p = nakladka.naEkran(r.stacje[t])
            ctx.fillStyle = "#2979ff"
            ctx.strokeStyle = "#ffffff"
            ctx.lineWidth = 2
            ctx.beginPath()
            ctx.moveTo(p.x, p.y - 10)
            ctx.lineTo(p.x + 9, p.y + 6)
            ctx.lineTo(p.x - 9, p.y + 6)
            ctx.closePath()
            ctx.fill()
            ctx.stroke()
            ctx.font = "bold 15px sans-serif"
            ctx.fillStyle = "#000000"
            ctx.fillText(r.stacje[t].nazwa, p.x + 12, p.y - 5)
            ctx.fillStyle = "#ffffff"
            ctx.fillText(r.stacje[t].nazwa, p.x + 11, p.y - 6)
          }
        }
        if (plugin.celownik) {
          var cx = width / 2, cy = height / 2
          ctx.lineWidth = 3
          ctx.strokeStyle = "#000000"
          ctx.beginPath()
          ctx.moveTo(cx - 24, cy); ctx.lineTo(cx - 6, cy)
          ctx.moveTo(cx + 6, cy); ctx.lineTo(cx + 24, cy)
          ctx.moveTo(cx, cy - 24); ctx.lineTo(cx, cy - 6)
          ctx.moveTo(cx, cy + 6); ctx.lineTo(cx, cy + 24)
          ctx.stroke()
          ctx.lineWidth = 1.5
          ctx.strokeStyle = "#ff1744"
          ctx.stroke()
        }
      }
    }
  }

  // ══════════════════════════════════════════════════ pływający panel
  Rectangle {
    id: panel
    parent: mainWindow.contentItem
    visible: plugin.celownik || (plugin.podglad && !okno.visible && (plugin.wynik !== null || plugin.bladWyniku !== ""))
    z: 10000
    width: Math.min(parent ? parent.width - 24 : 400, 480)
    x: parent ? (parent.width - width) / 2 : 0
    y: (typeof mainWindow.sceneTopMargin !== "undefined" ? mainWindow.sceneTopMargin : 0) + 72
    height: kolPanelu.implicitHeight + 16
    radius: 12
    color: "#f0263238"
    border.color: plugin.celownik ? "#ff1744" : "#2979ff"
    border.width: 2

    ColumnLayout {
      id: kolPanelu
      anchors.fill: parent
      anchors.margins: 8
      spacing: 6

      Text {
        Layout.fillWidth: true
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.WordWrap
        color: "#ffffff"
        font.pointSize: 10
        text: plugin.celownik
              ? qsTr("Przesuń mapę, aby krzyż był nad punktem %1, i zatwierdź").arg(plugin.usrNazwa)
              : (plugin.wynik
                 ? plugin.wynik.metoda + ":  X = " + Obl.f(plugin.wynik.punkt.n, 2) + "   Y = " + Obl.f(plugin.wynik.punkt.e, 2)
                   + "\nmp = " + plugin.cm(plugin.wynik.mp) + (plugin.wynik.uwagi.length > 0 ? "   ⚠ " + plugin.wynik.uwagi.length : "")
                 : plugin.bladWyniku)
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8
        visible: plugin.celownik
        Button {
          Layout.fillWidth: true
          Layout.preferredHeight: 48
          text: qsTr("✕ Anuluj")
          onClicked: {
            plugin.celownik = false
            plotno.requestPaint()
            okno.open()
          }
        }
        Button {
          Layout.fillWidth: true
          Layout.preferredHeight: 48
          text: qsTr("✓ Weź punkt")
          highlighted: true
          onClicked: plugin.wezZCelownika()
        }
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8
        visible: !plugin.celownik
        Button {
          Layout.fillWidth: true
          Layout.preferredHeight: 48
          visible: plugin.metoda === 0 && plugin.wynik !== null
          text: plugin.strona === 0 ? qsTr("⇄ na prawą") : qsTr("⇄ na lewą")
          onClicked: {
            plugin.strona = 1 - plugin.strona
            plugin.przelicz()
          }
        }
        Button {
          Layout.fillWidth: true
          Layout.preferredHeight: 48
          text: qsTr("Okno")
          onClicked: okno.open()
        }
        Button {
          Layout.fillWidth: true
          Layout.preferredHeight: 48
          visible: plugin.wynik !== null
          text: qsTr("✓ Zapisz")
          highlighted: true
          onClicked: plugin.zapiszWynik()
        }
        Button {
          Layout.preferredWidth: 48
          Layout.preferredHeight: 48
          text: "✕"
          onClicked: {
            plugin.podglad = false
            plotno.requestPaint()
          }
        }
      }
    }
  }

  // ══════════════════════════════════════════════════ zapis

  function bazaDocelowa() {
    if (typeof NarzedziaProjektu !== "undefined") {
      var p = NarzedziaProjektu.plikDanych(qgisProject)
      if (p && p !== "")
        return p
    }
    return projectHome() + "dane.gpkg"
  }

  readonly property var polaWarstwy: [
    { name: "NR", type: "text" },
    { name: "RODZAJ", type: "text" },
    { name: "METODA", type: "text" },
    { name: "X_2000", type: "real" },
    { name: "Y_2000", type: "real" },
    { name: "EPSG", type: "text" },
    { name: "MP_M", type: "real" },
    { name: "NAWIAZANIA", type: "text" },
    { name: "ODLEGLOSCI", type: "text" },
    { name: "POPRAWKI", type: "text" },
    { name: "UWAGI", type: "text" },
    { name: "OPIS", type: "text" },
    { name: "DATA", type: "text" }
  ]

  function warstwaDocelowa() {
    var nazwa = ustawienia.warstwa !== "" ? ustawienia.warstwa : nazwaWarstwy
    var istniejaca = LayerUtils.vectorLayerByName(qgisProject, nazwa)
    if (istniejaca && istniejaca.isValid)
      return istniejaca
    if (ustawienia.warstwa !== "") {
      toast(qsTr("Nie ma prawidłowej warstwy „%1” — wybierz inną w ustawieniach.").arg(nazwa))
      return null
    }
    if (istniejaca) {
      log("warstwa " + nazwa + " jest, ale NIEPRAWIDŁOWA — zakładam od nowa")
      ProjectUtils.removeMapLayer(qgisProject, istniejaca)
    }
    if (projectHome() === "") {
      toast(qsTr("Najpierw otwórz projekt — warstwa powstaje w jego bazie."))
      return null
    }
    var authid = iface.projectCrsAuthid()
    if (!authid || authid === "")
      authid = "EPSG:" + epsg
    var sciezka = bazaDocelowa()
    log("zakładam warstwę " + nazwa + " w " + sciezka + " (" + authid + ")")
    var w = LayerUtils.createEmptyLayer(sciezka, nazwa, "Point", authid, polaWarstwy)
    if (!w) {
      log("createEmptyLayer zwróciło null")
      return null
    }
    if (!ProjectUtils.addMapLayer(qgisProject, w)) {
      log("addMapLayer nieudane")
      return null
    }
    try { LayerUtils.setLabelsEnabled(w, true, "NR") } catch (e) {}
    try {
      if (typeof NarzedziaProjektu !== "undefined")
        NarzedziaProjektu.zapiszProjekt(qgisProject)
      else
        ProjectUtils.saveProject(qgisProject)
    } catch (e) {}
    return w
  }

  function ustawPole(w, obiekt, nazwa, wartosc) {
    var idx = w.fields.indexOf(nazwa)
    if (idx >= 0)
      obiekt.setAttribute(idx, wartosc)
  }

  function ileObiektow(w, nr, data) {
    if (w.fields.indexOf("NR") < 0 || w.fields.indexOf("DATA") < 0)
      return -1
    try {
      var wyr = "\"NR\" = '" + String(nr).replace(/'/g, "''") + "' AND \"DATA\" = '" + data + "'"
      var it = LayerUtils.createFeatureIteratorFromExpression(w, wyr)
      var n = 0
      while (it.hasNext()) { it.next(); n++ }
      it.close()
      return n
    } catch (e) {
      return -1
    }
  }

  //! r: { nr, rodzaj, metoda, e, n, mp, nawiazania, odleglosci, poprawki, uwagi, opis, data }
  function doWarstwy(w, r) {
    var geom = GeometryUtils.createGeometryFromWkt("POINT(" + r.e.toFixed(4) + " " + r.n.toFixed(4) + ")")
    if (!geom)
      return false
    var g = GeometryUtils.reprojectGeometry(geom, crs2000(), w.crs)
    var obiekt = FeatureUtils.createBlankFeature(w.fields, g)
    ustawPole(w, obiekt, "NR", r.nr)
    ustawPole(w, obiekt, "RODZAJ", r.rodzaj)
    ustawPole(w, obiekt, "METODA", r.metoda)
    ustawPole(w, obiekt, "X_2000", Math.round(r.n * 1000) / 1000)
    ustawPole(w, obiekt, "Y_2000", Math.round(r.e * 1000) / 1000)
    ustawPole(w, obiekt, "EPSG", String(epsg))
    if (r.mp !== null && isFinite(r.mp))
      ustawPole(w, obiekt, "MP_M", Math.round(r.mp * 1000) / 1000)
    ustawPole(w, obiekt, "NAWIAZANIA", r.nawiazania)
    ustawPole(w, obiekt, "ODLEGLOSCI", r.odleglosci)
    ustawPole(w, obiekt, "POPRAWKI", r.poprawki)
    ustawPole(w, obiekt, "UWAGI", r.uwagi)
    ustawPole(w, obiekt, "OPIS", r.opis)
    ustawPole(w, obiekt, "DATA", r.data)
    w.startEditing()
    var dodane = LayerUtils.addFeature(w, obiekt)
    var zapisane = w.commitChanges()
    var jest = ileObiektow(w, r.nr, r.data)
    log("zapis " + r.nr + ": addFeature=" + dodane + " commit=" + zapisane + " kontrola=" + jest)
    return jest > 0 || (jest < 0 && dodane && zapisane)
  }

  //! Dopisuje wiersze do DOMIARY/dziennik_domiarow.csv. Nie nadpisuje pliku, którego nie umie odczytać.
  function doDziennika(wiersze) {
    var home = projectHome()
    if (home === "")
      return ""
    platformUtilities.createDir(qgisProject.homePath, "DOMIARY")
    var sciezka = home + "DOMIARY/dziennik_domiarow.csv"
    var tresc = ""
    var istnieje = false
    try { istnieje = FileUtils.fileExists(sciezka) } catch (e) { istnieje = false }
    if (istnieje) {
      var bufor = null
      try { bufor = FileUtils.readFileContent(sciezka) } catch (e) { bufor = null }
      var stary = (bufor && bufor.byteLength > 0) ? Obl.zUtf8(bufor) : null
      if (stary === null) {
        var d = new Date()
        sciezka = home + "DOMIARY/dziennik_domiarow_" + d.getFullYear() + dwa(d.getMonth() + 1) + dwa(d.getDate())
          + "_" + dwa(d.getHours()) + dwa(d.getMinutes()) + dwa(d.getSeconds()) + ".csv"
        log("dziennika nie da się odczytać — piszę do nowego pliku " + sciezka)
      } else {
        tresc = stary
        if (tresc.length > 0 && !tresc.endsWith("\n"))
          tresc += "\n"
      }
    }
    if (tresc === "")
      tresc = Obl.NAGLOWEK_CSV.join(";") + "\n"
    for (var i = 0; i < wiersze.length; i++)
      tresc += Obl.wierszCsv(wiersze[i]) + "\n"
    return iface.writeTextFile(sciezka, tresc) ? sciezka : ""
  }

  function zapiszWynik() {
    if (!wynik)
      return
    if (projectHome() === "") {
      toast(qsTr("Najpierw otwórz projekt."))
      return
    }
    var w = warstwaDocelowa()
    if (!w) {
      statusZapisu = qsTr("⚠ Nie udało się przygotować warstwy — szczegóły w logu.")
      return
    }
    var data = teraz()
    var nr = poleNr.text.trim() !== "" ? poleNr.text.trim() : "P" + ustawienia.licznik
    var doDz = []
    var bledy = []
    // punkty nawiązania — raz, przy pierwszym użyciu
    var lista = punkty.slice()
    for (var i = 0; i < wynik.stacje.length; i++) {
      var st = wynik.stacje[i]
      var r0 = { nr: st.nazwa, rodzaj: qsTr("nawiązanie"), metoda: st.zrodlo, e: st.e, n: st.n, mp: st.s, epsg: epsg,
                 nawiazania: "", odleglosci: "", poprawki: "", uwagi: "", opis: "", data: data, wsp: null }
      for (var k = 0; k < lista.length; k++) {
        if (lista[k].nazwa !== st.nazwa)
          continue
        if (!lista[k].wWarstwie) {
          if (doWarstwy(w, r0))
            lista[k].wWarstwie = true
          else
            bledy.push(st.nazwa)
        }
        if (!lista[k].wDzienniku) {
          doDz.push(r0)
          lista[k].wDzienniku = true
        }
      }
    }
    punkty = lista
    zapamietaj()

    var r = {
      nr: nr, rodzaj: qsTr("wyznaczony"), metoda: wynik.metoda, e: wynik.punkt.e, n: wynik.punkt.n, mp: wynik.mp, epsg: epsg,
      nawiazania: wynik.nawiazania, odleglosci: wynik.odleglosci, poprawki: wynik.poprawki,
      uwagi: wynik.uwagi.join(" | "), opis: poleOpis.text.trim(), data: data, wsp: wynik.wsp
    }
    var okW = doWarstwy(w, r)
    if (!okW)
      bledy.push(nr)
    doDz.push(r)
    var dz = doDziennika(doDz)
    statusZapisu = (bledy.length === 0 ? "✓ " : "⚠ ") + qsTr("%1 → warstwa %2%3; dziennik: %4")
      .arg(nr).arg(w.name)
      .arg(bledy.length > 0 ? qsTr(" (NIE zapisano: %1)").arg(bledy.join(", ")) : "")
      .arg(dz !== "" ? dz : qsTr("NIE zapisany"))
    if (okW) {
      ustawienia.licznik = ustawienia.licznik + 1
      poleNr.text = ""
      poleOpis.text = ""
      toast(qsTr("Zapisano punkt %1").arg(nr))
    } else {
      toast(qsTr("Nie udało się zapisać punktu %1 — szczegóły w oknie.").arg(nr))
    }
  }

  // ══════════════════════════════════════════════════ okno
  component Naglowek: Label {
    Layout.fillWidth: true
    Layout.topMargin: 6
    font.bold: true
    font.pointSize: 11
    wrapMode: Text.WordWrap
  }

  component Pomoc: Label {
    Layout.fillWidth: true
    wrapMode: Text.WordWrap
    color: "#9e9e9e"
    font.pointSize: 9
  }

  component PoleLiczby: TextField {
    Layout.fillWidth: true
    inputMethodHints: Qt.ImhFormattedNumbersOnly
    selectByMouse: true
  }

  Dialog {
    id: okno
    parent: mainWindow.contentItem
    modal: true
    title: qsTr("Domiary dalmierzem")
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 24, 540)
    height: Math.min(mainWindow.height - 40, 820)
    standardButtons: Dialog.Close
    onOpened: plugin.zbudujRysunek()

    Flickable {
      anchors.fill: parent
      contentHeight: kol.implicitHeight + 20
      clip: true

      ColumnLayout {
        id: kol
        width: parent.width
        spacing: 8

        // ───────────────────────────── punkty nawiązania
        Naglowek { text: qsTr("1. Punkty nawiązania — %1").arg(plugin.strefaOpis()) }

        Repeater {
          model: plugin.punkty
          delegate: Rectangle {
            Layout.fillWidth: true
            implicitHeight: wierszPunktu.implicitHeight + 10
            radius: 6
            color: "#263238"
            RowLayout {
              id: wierszPunktu
              anchors.fill: parent
              anchors.margins: 5
              spacing: 6
              Label {
                text: modelData.nazwa
                font.bold: true
                font.pointSize: modelData.nazwa.length > 3 ? 10 : 13
                color: "#64b5f6"
                Layout.preferredWidth: 72
                wrapMode: Text.WrapAnywhere
                maximumLineCount: 2
                elide: Text.ElideRight
              }
              Label {
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
                color: "#ffffff"
                font.pointSize: 9
                text: "X " + Obl.f(modelData.n, 2) + "   Y " + Obl.f(modelData.e, 2)
                      + "   σ " + plugin.cm(modelData.s)
                      + (modelData.h !== null && modelData.h !== undefined ? "   H " + Obl.f(modelData.h, 2) : "")
                      + "\n" + modelData.zrodlo
              }
              Button {
                text: "✕"
                Layout.preferredWidth: 44
                onClicked: plugin.usunPunkt(modelData.nazwa)
              }
            }
          }
        }

        Pomoc {
          visible: plugin.punkty.length === 0
          text: qsTr("Zmierz RTK co najmniej dwa punkty (np. tyczki, narożniki, słupki), od których potem domierzysz dalmierzem odległości do szukanego punktu.")
        }

        TextField {
          id: poleNazwy
          objectName: "poleNazwy"
          Layout.fillWidth: true
          placeholderText: qsTr("Nazwa następnego punktu (puste = %1)").arg(Obl.nastepnaNazwa(plugin.punkty))
        }

        RowLayout {
          Layout.fillWidth: true
          spacing: 8
          Button {
            Layout.fillWidth: true
            enabled: !plugin.usrAktywne
            highlighted: true
            text: qsTr("⌖ GPS — uśrednij %1").arg(ustawienia.liczbaProbek)
            onClicked: plugin.zaczniUsrednianie()
          }
          Button {
            Layout.fillWidth: true
            enabled: !plugin.usrAktywne
            text: qsTr("✛ Celownik")
            onClicked: plugin.zaczniCelownik()
          }
        }

        RowLayout {
          Layout.fillWidth: true
          spacing: 8
          visible: plugin.usrAktywne || plugin.usrStan !== ""
          Label {
            Layout.fillWidth: true
            wrapMode: Text.WordWrap
            color: plugin.usrAktywne ? "#39ff14" : "#ffab40"
            font.pointSize: 9
            text: (plugin.usrAktywne ? plugin.usrNazwa + ": " : "") + plugin.usrStan
          }
          Button {
            visible: plugin.usrAktywne
            text: qsTr("Stop")
            onClicked: plugin.przerwijUsrednianie(qsTr("Przerwane ręcznie."))
          }
        }

        RowLayout {
          Layout.fillWidth: true
          spacing: 8
          Button {
            Layout.fillWidth: true
            text: (plugin.pokazWarstwe ? "▾ " : "▸ ") + qsTr("Z warstwy")
            onClicked: {
              plugin.pokazWarstwe = !plugin.pokazWarstwe
              if (plugin.pokazWarstwe) {
                plugin.odswiezWarstwy()
                if (plugin.warstwyPunktowe.length > 0)
                  plugin.wczytajObiekty(plugin.warstwyPunktowe[Math.max(0, wyborWarstwy.currentIndex)].warstwa)
              }
            }
          }
          Button {
            Layout.fillWidth: true
            text: (plugin.pokazWpisz ? "▾ " : "▸ ") + qsTr("Wpisz X/Y")
            onClicked: plugin.pokazWpisz = !plugin.pokazWpisz
          }
        }

        ColumnLayout {
          Layout.fillWidth: true
          visible: plugin.pokazWarstwe
          spacing: 6
          Pomoc {
            visible: plugin.warstwyPunktowe.length === 0
            text: qsTr("W projekcie nie ma warstwy punktowej.")
          }
          ComboBox {
            id: wyborWarstwy
            Layout.fillWidth: true
            visible: plugin.warstwyPunktowe.length > 0
            model: plugin.warstwyPunktowe.map(function (x) { return x.nazwa })
            onActivated: plugin.wczytajObiekty(plugin.warstwyPunktowe[currentIndex].warstwa)
          }
          RowLayout {
            Layout.fillWidth: true
            visible: plugin.warstwyPunktowe.length > 0
            ComboBox {
              id: wyborObiektu
              Layout.fillWidth: true
              model: plugin.obiektyWarstwy.map(function (x) { return x.opis })
              enabled: plugin.obiektyWarstwy.length > 0
            }
            Button {
              text: qsTr("Dodaj")
              enabled: plugin.obiektyWarstwy.length > 0 && wyborObiektu.currentIndex >= 0
              onClicked: {
                var w = plugin.warstwyPunktowe[wyborWarstwy.currentIndex]
                var o = plugin.obiektyWarstwy[wyborObiektu.currentIndex]
                plugin.zObiektu(w.warstwa, o.obiekt, o.opis)
              }
            }
          }
        }

        ColumnLayout {
          Layout.fillWidth: true
          visible: plugin.pokazWpisz
          spacing: 6
          RowLayout {
            Layout.fillWidth: true
            PoleLiczby { id: poleX; objectName: "poleX"; placeholderText: qsTr("X (północ)") }
            PoleLiczby { id: poleY; objectName: "poleY"; placeholderText: qsTr("Y (wschód, 5…8 mln)") }
          }
          RowLayout {
            Layout.fillWidth: true
            PoleLiczby { id: poleS; objectName: "poleS"; placeholderText: qsTr("błąd σ [cm], puste = 2") }
            Button {
              text: qsTr("Dodaj")
              onClicked: plugin.zWpisu()
            }
          }
        }

        // ───────────────────────────── metoda i odczyty
        Naglowek { text: qsTr("2. Metoda i odczyty dalmierza") }

        ComboBox {
          id: wyborMetody
          objectName: "wyborMetody"
          Layout.fillWidth: true
          model: plugin.metody
          currentIndex: plugin.metoda
          onActivated: plugin.metoda = currentIndex
        }

        Pomoc {
          text: plugin.metoda === 0
                ? qsTr("Odległości od dwóch punktów do szukanego. Dwa możliwe położenia — wybierz stronę (lewa/prawa patrząc z punktu 1 na 2); oba są pokazane na mapie. Najlepiej, gdy kąt w szukanym punkcie wynosi 60–120°.")
                : (plugin.metoda === 1
                   ? qsTr("Punkt na prostej przez dwa punkty: odległość od punktu 1 w stronę punktu 2. Odległość większa od bazy = przedłużenie za punkt 2. „Wstecz” = przedłużenie za punkt 1.")
                   : qsTr("Odległości do 3 i więcej punktów. Wyrównanie metodą najmniejszych kwadratów, kontrola zgodności i wskazanie błędnej odległości (przy 4+)."))
        }

        GridLayout {
          Layout.fillWidth: true
          visible: plugin.metoda !== 2
          columns: 3
          columnSpacing: 6
          rowSpacing: 4

          Label { text: plugin.metoda === 0 ? qsTr("Punkt 1") : qsTr("Od") }
          ComboBox {
            id: wybor1
            Layout.columnSpan: 2
            Layout.fillWidth: true
            model: plugin.nazwyPunktow()
            function zgraj() { currentIndex = model.indexOf(plugin.wyb1) }
            Component.onCompleted: zgraj()
            onModelChanged: zgraj()
            Connections {
              target: plugin
              function onWyb1Changed() { wybor1.zgraj() }
            }
            onActivated: {
              plugin.wyb1 = currentText
              plugin.przelicz()
            }
          }

          Label { text: qsTr("odległość") }
          PoleLiczby {
            id: poleD1
            objectName: "poleD1"
            placeholderText: qsTr("m (dalmierz)")
            onTextChanged: plugin.przelicz()
          }
          PoleLiczby {
            id: poleK1
            objectName: "poleK1"
            Layout.maximumWidth: 110
            placeholderText: qsTr("kąt ° (skośna)")
            onTextChanged: plugin.przelicz()
          }

          Label { text: plugin.metoda === 0 ? qsTr("Punkt 2") : qsTr("W stronę") }
          ComboBox {
            id: wybor2
            Layout.columnSpan: 2
            Layout.fillWidth: true
            model: plugin.nazwyPunktow()
            function zgraj() { currentIndex = model.indexOf(plugin.wyb2) }
            Component.onCompleted: zgraj()
            onModelChanged: zgraj()
            Connections {
              target: plugin
              function onWyb2Changed() { wybor2.zgraj() }
            }
            onActivated: {
              plugin.wyb2 = currentText
              plugin.przelicz()
            }
          }

          Label { text: qsTr("odległość"); visible: plugin.metoda === 0 }
          PoleLiczby {
            id: poleD2
            objectName: "poleD2"
            visible: plugin.metoda === 0
            placeholderText: qsTr("m (dalmierz)")
            onTextChanged: plugin.przelicz()
          }
          PoleLiczby {
            id: poleK2
            objectName: "poleK2"
            visible: plugin.metoda === 0
            Layout.maximumWidth: 110
            placeholderText: qsTr("kąt ° (skośna)")
            onTextChanged: plugin.przelicz()
          }
        }

        CheckBox {
          id: wsteczPole
          objectName: "wsteczPole"
          visible: plugin.metoda === 1
          text: qsTr("Wstecz — przedłużenie za punkt „Od”")
          onToggled: plugin.przelicz()
        }

        RowLayout {
          Layout.fillWidth: true
          visible: plugin.metoda === 0
          spacing: 8
          Button {
            Layout.fillWidth: true
            text: qsTr("◀ lewa strona")
            highlighted: plugin.strona === 0
            onClicked: { plugin.strona = 0; plugin.przelicz() }
          }
          Button {
            Layout.fillWidth: true
            text: qsTr("prawa strona ▶")
            highlighted: plugin.strona === 1
            onClicked: { plugin.strona = 1; plugin.przelicz() }
          }
        }

        // wcięcie: wszystkie punkty, każdy z odległością
        Repeater {
          model: plugin.metoda === 2 ? plugin.punkty : []
          delegate: RowLayout {
            Layout.fillWidth: true
            spacing: 6
            property var stan: plugin.wcieciePola[modelData.nazwa] || ({ uzyj: true, d: "", kat: "" })
            function zmien(klucz, wartosc) {
              var m = Object.assign({}, plugin.wcieciePola)
              var s = Object.assign({ uzyj: true, d: "", kat: "" }, m[modelData.nazwa] || {})
              s[klucz] = wartosc
              m[modelData.nazwa] = s
              plugin.wcieciePola = m
              plugin.przelicz()
            }
            CheckBox {
              checked: stan.uzyj !== false
              text: modelData.nazwa
              font.bold: true
              Layout.preferredWidth: 80
              onToggled: zmien("uzyj", checked)
            }
            PoleLiczby {
              text: stan.d
              placeholderText: qsTr("m")
              onTextChanged: if (activeFocus && text !== stan.d) zmien("d", text)
            }
            PoleLiczby {
              Layout.maximumWidth: 90
              text: stan.kat
              placeholderText: qsTr("kąt °")
              onTextChanged: if (activeFocus && text !== stan.kat) zmien("kat", text)
            }
          }
        }

        Pomoc {
          text: qsTr("Kąt pionowy wpisz tylko wtedy, gdy dalmierz podał odległość skośną (pochyloną). Puste = odległość pozioma. Odczyty przeliczane są do układu 2000 (skala odwzorowania i wysokość).")
        }

        // ───────────────────────────── wynik
        Naglowek { text: qsTr("3. Wynik") }

        Label {
          Layout.fillWidth: true
          visible: plugin.bladWyniku !== ""
          wrapMode: Text.WordWrap
          color: "#ffab40"
          text: plugin.bladWyniku
        }

        Rectangle {
          Layout.fillWidth: true
          visible: plugin.wynik !== null
          implicitHeight: kolWyniku.implicitHeight + 14
          radius: 6
          color: "#263238"
          ColumnLayout {
            id: kolWyniku
            anchors.fill: parent
            anchors.margins: 7
            spacing: 4
            Label {
              Layout.fillWidth: true
              color: "#ffffff"
              font.bold: true
              font.pointSize: 13
              wrapMode: Text.WordWrap
              text: plugin.wynik ? Obl.xy(plugin.wynik.punkt) : ""
            }
            Label {
              Layout.fillWidth: true
              color: "#cfd8dc"
              font.pointSize: 9
              wrapMode: Text.WordWrap
              text: plugin.wynik
                    ? plugin.wynik.szczegoly + "\n" + plugin.strefaOpis()
                      + (plugin.wynik.wsp !== 1 ? qsTr("   redukcja ×%1 (%2 mm na 50 m)").arg(plugin.wynik.wsp.toFixed(7)).arg(Obl.f((plugin.wynik.wsp - 1) * 50000, 1)) : "")
                    : ""
            }
            Label {
              Layout.fillWidth: true
              visible: plugin.wynik !== null && plugin.wynik.uwagi.length > 0
              color: "#ffab40"
              font.pointSize: 10
              wrapMode: Text.WordWrap
              text: plugin.wynik ? plugin.wynik.uwagi.map(function (u) { return "⚠ " + u }).join("\n") : ""
            }
          }
        }

        Button {
          Layout.fillWidth: true
          enabled: plugin.wynik !== null || plugin.punkty.length > 0 || plugin.podglad
          text: plugin.podglad ? qsTr("Ukryj z mapy") : qsTr("Pokaż na mapie")
          onClicked: {
            if (plugin.podglad) {
              plugin.podglad = false
              plotno.requestPaint()
              return
            }
            plugin.podglad = true
            plugin.zbudujRysunek()
            okno.close()
          }
        }

        // ───────────────────────────── zapis
        Naglowek { text: qsTr("4. Zapis") }

        RowLayout {
          Layout.fillWidth: true
          spacing: 6
          TextField {
            id: poleNr
            objectName: "poleNr"
            Layout.preferredWidth: 110
            placeholderText: "P" + ustawienia.licznik
          }
          TextField {
            id: poleOpis
            objectName: "poleOpis"
            Layout.fillWidth: true
            placeholderText: qsTr("Opis (np. narożnik budynku)")
          }
        }

        Button {
          Layout.fillWidth: true
          enabled: plugin.wynik !== null
          highlighted: true
          text: qsTr("Zapisz punkt")
          onClicked: plugin.zapiszWynik()
        }

        Label {
          Layout.fillWidth: true
          visible: plugin.statusZapisu !== ""
          wrapMode: Text.WrapAnywhere
          color: plugin.statusZapisu.indexOf("⚠") === 0 ? "#ffab40" : "#39ff14"
          font.pointSize: 9
          text: plugin.statusZapisu
        }

        Pomoc {
          text: qsTr("Punkt trafia do warstwy „%1” (punkty nawiązania też, raz) i do dziennika DOMIARY/dziennik_domiarow.csv w katalogu projektu. Współrzędne: X = północ, Y = wschód.")
                  .arg(ustawienia.warstwa !== "" ? ustawienia.warstwa : plugin.nazwaWarstwy)
        }

        // ───────────────────────────── ustawienia
        Button {
          Layout.fillWidth: true
          flat: true
          text: (plugin.pokazUstawienia ? "▾ " : "▸ ") + qsTr("Ustawienia")
          onClicked: plugin.pokazUstawienia = !plugin.pokazUstawienia
        }

        GridLayout {
          Layout.fillWidth: true
          visible: plugin.pokazUstawienia
          columns: 2
          columnSpacing: 8

          Label { text: qsTr("σ odległości [cm]") }
          PoleLiczby {
            text: (ustawienia.sigmaD * 100).toFixed(1)
            onEditingFinished: {
              var v = Obl.liczba(text)
              if (v > 0) { ustawienia.sigmaD = v / 100; plugin.przelicz() }
            }
          }
          Label { text: qsTr("próg GPS σ [cm], 0 = bez") }
          PoleLiczby {
            text: (ustawienia.maxHacc * 100).toFixed(1)
            onEditingFinished: {
              var v = Obl.liczba(text)
              if (v >= 0) ustawienia.maxHacc = v / 100
            }
          }
          Label { text: qsTr("próbek GPS") }
          PoleLiczby {
            text: String(ustawienia.liczbaProbek)
            onEditingFinished: {
              var v = Math.round(Obl.liczba(text))
              if (v >= 1 && v <= 600) ustawienia.liczbaProbek = v
            }
          }
          Label { text: qsTr("tolerancja trójkąta [cm]") }
          PoleLiczby {
            text: (ustawienia.tolerancja * 100).toFixed(1)
            onEditingFinished: {
              var v = Obl.liczba(text)
              if (v >= 0) { ustawienia.tolerancja = v / 100; plugin.przelicz() }
            }
          }
          Label { text: qsTr("warstwa zapisu") }
          ComboBox {
            Layout.fillWidth: true
            model: [qsTr("Domiary (zakładana)")].concat(plugin.warstwyPunktowe.map(function (x) { return x.nazwa }).filter(function (n) { return n !== plugin.nazwaWarstwy }))
            currentIndex: ustawienia.warstwa === "" ? 0 : Math.max(0, model.indexOf(ustawienia.warstwa))
            onActivated: ustawienia.warstwa = currentIndex === 0 ? "" : currentText
          }
          CheckBox {
            Layout.columnSpan: 2
            text: qsTr("Redukcja odległości do układu 2000 (skala + wysokość)")
            checked: ustawienia.redukcja
            onToggled: { ustawienia.redukcja = checked; plugin.przelicz() }
          }
          Button {
            Layout.columnSpan: 2
            Layout.fillWidth: true
            text: qsTr("Wyczyść wszystkie punkty nawiązania")
            enabled: plugin.punkty.length > 0
            onClicked: potwierdzenie.open()
          }
        }

        Pomoc {
          text: qsTr("Dalmierz Bluetooth: jeszcze nie — wpisz odczyt z ekranu dalmierza. Wersja %1.").arg(plugin.wersja)
        }
      }
    }
  }

  Dialog {
    id: potwierdzenie
    parent: mainWindow.contentItem
    modal: true
    title: qsTr("Wyczyścić punkty nawiązania?")
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 40, 400)
    standardButtons: Dialog.Yes | Dialog.No
    Label {
      width: parent.width
      wrapMode: Text.WordWrap
      text: qsTr("Lista punktów w tej wtyczce zostanie wyczyszczona. Punkty już zapisane w warstwie i dzienniku zostają.")
    }
    onAccepted: plugin.wyczyscPunkty()
  }
}
