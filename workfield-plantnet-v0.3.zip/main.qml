import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import QtCore
import org.qfield
import Theme

/**
 * WorkField Pl@ntNet — rozpoznawanie gatunków roślin ze zdjęcia.
 * Wersja 0.3 — zdjęcie czytane przez FileUtils.readFileContent (XHR nie ma
 * prawa czytać lokalnych plików), komunikaty krok po kroku, timeout 45 s.
 * Klucz API przechowywany lokalnie w ustawieniach (nigdy w kodzie!).
 */
Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property url selectedFile: ""
  property bool busy: false

  Settings {
    id: pluginSettings
    category: "WorkFieldPlantNet"
    property string apiKey: ""
    property string organ: "leaf"
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(pluginButton)
  }

  QfToolButton {
    id: pluginButton
    iconSource: 'icon.svg'
    iconColor: Theme.mainColor
    bgcolor: Theme.darkGray
    round: true
    onClicked: {
      resultsModel.clear()
      statusLabel.text = ""
      dialog.open()
    }
  }

  FileDialog {
    id: fileDialog
    title: qsTr("Wybierz zdjęcie rośliny")
    nameFilters: ["Zdjęcia (*.jpg *.jpeg *.png)", "Wszystkie pliki (*)"]
    onAccepted: {
      plugin.selectedFile = selectedFile
      statusLabel.text = ""
    }
  }

  ListModel {
    id: resultsModel
  }

  // Ukryte pole do kopiowania nazwy do schowka
  TextEdit {
    id: clipboardHelper
    visible: false
    function copyText(t) {
      text = t
      selectAll()
      copy()
    }
  }

  Dialog {
    id: dialog
    parent: mainWindow.contentItem
    modal: true
    title: "Pl@ntNet — rozpoznanie gatunku"
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 40, 500)
    height: Math.min(mainWindow.height - 80, 640)
    standardButtons: Dialog.Close

    ColumnLayout {
      anchors.fill: parent
      spacing: 8

      TextField {
        id: apiKeyField
        Layout.fillWidth: true
        placeholderText: qsTr("Klucz API Pl@ntNet")
        text: pluginSettings.apiKey
        echoMode: TextInput.PasswordEchoOnEdit
        onEditingFinished: pluginSettings.apiKey = text.trim()
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        ComboBox {
          id: organCombo
          Layout.preferredWidth: 140
          textRole: "label"
          valueRole: "value"
          model: [
            { label: qsTr("liść"),  value: "leaf" },
            { label: qsTr("kwiat"), value: "flower" },
            { label: qsTr("owoc"),  value: "fruit" },
            { label: qsTr("kora"),  value: "bark" },
            { label: qsTr("pokrój"), value: "auto" }
          ]
          Component.onCompleted: {
            currentIndex = Math.max(0, indexOfValue(pluginSettings.organ))
          }
          onActivated: pluginSettings.organ = currentValue
        }

        Button {
          Layout.fillWidth: true
          text: plugin.selectedFile != ""
                ? plugin.selectedFile.toString().split("/").pop()
                : qsTr("Wybierz zdjęcie…")
          onClicked: fileDialog.open()
        }
      }

      Button {
        Layout.fillWidth: true
        enabled: !plugin.busy && plugin.selectedFile != "" && apiKeyField.text.trim() !== ""
        text: plugin.busy ? qsTr("Rozpoznawanie…") : qsTr("Rozpoznaj gatunek")
        onClicked: plugin.identify()
      }

      Label {
        id: statusLabel
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        property bool isError: false
        color: isError ? "#c62828" : "#33691e"
        visible: text !== ""
        function step(t) { isError = false; text = t }
        function error(t) { isError = true; text = t; plugin.busy = false }
      }

      ListView {
        id: resultsView
        Layout.fillWidth: true
        Layout.fillHeight: true
        clip: true
        model: resultsModel
        spacing: 4

        delegate: Rectangle {
          width: resultsView.width
          height: rowCol.implicitHeight + 16
          radius: 6
          color: index === 0 ? "#e8f5e9" : "#f5f5f5"

          Column {
            id: rowCol
            anchors.verticalCenter: parent.verticalCenter
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.margins: 10
            spacing: 2

            Label {
              width: parent.width
              text: score + "%  —  " + scientificName
              font.bold: index === 0
              font.italic: true
              wrapMode: Text.WordWrap
              color: "#212121"
            }
            Label {
              width: parent.width
              visible: commonName !== ""
              text: commonName
              wrapMode: Text.WordWrap
              color: "#555555"
            }
          }

          MouseArea {
            anchors.fill: parent
            onClicked: {
              clipboardHelper.copyText(scientificName)
              mainWindow.displayToast(qsTr("Skopiowano: ") + scientificName)
            }
          }
        }
      }

      Label {
        Layout.fillWidth: true
        text: qsTr("Dotknij gatunku, aby skopiować nazwę. Dane: Pl@ntNet (my.plantnet.org).")
        wrapMode: Text.WordWrap
        font.pointSize: 9
        color: "#777777"
      }
    }
  }

  // ---------------------------------------------------------- logika sieciowa

  function localPath(u) {
    var s = u.toString()
    if (s.indexOf("content://") === 0)
      return s                                  // Android: QFile umie content://
    if (s.indexOf("file://") === 0)
      s = s.substring(7)
    return decodeURIComponent(s)
  }

  function identify() {
    plugin.busy = true
    resultsModel.clear()
    var stage = "start"
    try {
      stage = "ścieżka"
      var path = localPath(plugin.selectedFile)
      stage = "readFileContent: " + path
      statusLabel.step(qsTr("Czytam zdjęcie…"))
      var content = FileUtils.readFileContent(path)
      stage = "wynik: " + (content === null ? "null" : typeof content)
              + (content && content.constructor ? "/" + content.constructor.name : "")
              + ", byteLength=" + ((content && content.byteLength !== undefined) ? content.byteLength : "brak")
      var fileBytes = null
      if (content && content.byteLength !== undefined) {
        stage += " → Uint8Array z ArrayBuffer"
        fileBytes = new Uint8Array(content)
      } else if (typeof content === "string") {
        stage += " → Uint8Array ze stringa, dł. " + content.length
        fileBytes = new Uint8Array(content.length)
        for (var i = 0; i < content.length; i++)
          fileBytes[i] = content.charCodeAt(i) & 0xff
      } else {
        statusLabel.error(qsTr("Nieobsługiwany typ danych [") + stage + "]")
        return
      }
      if (fileBytes.length === 0) {
        statusLabel.error(qsTr("Plik pusty lub nieczytelny. Uwaga: QField czyta ")
                          + qsTr("tylko pliki z katalogu OTWARTEGO projektu. [") + stage + "]")
        return
      }
      statusLabel.step(qsTr("Zdjęcie wczytane (") + Math.round(fileBytes.length / 1024)
                       + qsTr(" KB). Wysyłam do Pl@ntNet…"))
      plugin.sendToPlantNet(fileBytes)
    } catch (e) {
      statusLabel.error(qsTr("Błąd: ") + e + qsTr(" [etap: ") + stage + "]")
    }
  }

  function str2bytes(s) {
    var u = unescape(encodeURIComponent(s))
    var arr = new Uint8Array(u.length)
    for (var i = 0; i < u.length; i++)
      arr[i] = u.charCodeAt(i)
    return arr
  }

  function sendToPlantNet(fileBytes) {
    var boundary = "----WorkFieldPlantNet" + Date.now()
    var fname = plugin.selectedFile.toString().split("/").pop()
    var mime = fname.toLowerCase().indexOf(".png") > -1 ? "image/png" : "image/jpeg"

    var head = "--" + boundary + "\r\n"
        + 'Content-Disposition: form-data; name="organs"\r\n\r\n'
        + pluginSettings.organ + "\r\n"
        + "--" + boundary + "\r\n"
        + 'Content-Disposition: form-data; name="images"; filename="' + fname + '"\r\n'
        + "Content-Type: " + mime + "\r\n\r\n"
    var tail = "\r\n--" + boundary + "--\r\n"

    var h = str2bytes(head)
    var t = str2bytes(tail)
    var body = new Uint8Array(h.length + fileBytes.length + t.length)
    body.set(h, 0)
    body.set(fileBytes, h.length)
    body.set(t, h.length + fileBytes.length)

    var url = "https://my-api.plantnet.org/v2/identify/all"
        + "?api-key=" + encodeURIComponent(pluginSettings.apiKey.trim())
        + "&lang=pl&nb-results=6"

    try {
      var xhr = new XMLHttpRequest()
      xhr.open("POST", url)
      xhr.timeout = 45000
      xhr.ontimeout = function () {
        statusLabel.error(qsTr("Serwer nie odpowiedział w 45 s. Sprawdź zasięg."))
      }
      xhr.setRequestHeader("Content-Type", "multipart/form-data; boundary=" + boundary)
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== XMLHttpRequest.DONE)
          return
        plugin.busy = false
        if (xhr.status === 200) {
          statusLabel.step("")
          plugin.showResults(xhr.responseText)
        } else if (xhr.status === 401) {
          statusLabel.error(qsTr("Błędny klucz API (401). Sprawdź klucz na my.plantnet.org."))
        } else if (xhr.status === 404) {
          statusLabel.error(qsTr("Pl@ntNet nie rozpoznał żadnego gatunku na tym zdjęciu (404)."))
        } else if (xhr.status === 429) {
          statusLabel.error(qsTr("Wyczerpany dzienny limit zapytań (429)."))
        } else if (xhr.status === 0) {
          statusLabel.error(qsTr("Brak odpowiedzi (status 0) — problem z siecią lub wysyłką."))
        } else {
          statusLabel.error(qsTr("Błąd serwera: ") + xhr.status + " " + xhr.responseText.substring(0, 120))
        }
      }
      xhr.send(body.buffer)
    } catch (e) {
      statusLabel.error(qsTr("Błąd przy wysyłce: ") + e)
    }
  }

  function showResults(responseText) {
    try {
      var json = JSON.parse(responseText)
      var results = json.results || []
      if (results.length === 0) {
        statusLabel.error(qsTr("Brak wyników."))
        return
      }
      for (var i = 0; i < results.length; i++) {
        var r = results[i]
        var common = ""
        if (r.species.commonNames && r.species.commonNames.length > 0)
          common = r.species.commonNames.join(", ")
        resultsModel.append({
          score: Math.round(r.score * 100),
          scientificName: r.species.scientificNameWithoutAuthor,
          commonName: common
        })
      }
    } catch (e) {
      statusLabel.error(qsTr("Nie udało się odczytać odpowiedzi serwera: ") + e)
    }
  }
}
