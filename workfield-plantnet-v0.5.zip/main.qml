import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import Theme

/**
 * WorkField Pl@ntNet — rozpoznawanie gatunków roślin ze zdjęcia.
 * Wersja 0.5 (0.4 + miniatura zdjęcia):
 *  - zdjęcie przez aparat lub galerię mechanizmem QFielda
 *    (platformUtilities.getCameraPicture/getGalleryPicture) — plik trafia
 *    do katalogu projektu, więc FileUtils.readFileContent ma prawo go czytać;
 *  - naprawa TypeError: kontrola pustego bufora PRZED konwersją;
 *  - statusy w neonowej zieleni (czytelne na ciemnym tle).
 * Klucz API przechowywany lokalnie w ustawieniach (nigdy w kodzie!).
 */
Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property string selectedFile: ""          // pełna ścieżka w katalogu projektu
  property bool busy: false
  property var __resourceSource

  Settings {
    id: pluginSettings
    category: "WorkFieldPlantNet"
    property string apiKey: ""
    property string organ: "leaf"
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(pluginButton)
  }

  QfToolButton {
    id: pluginButton
    iconSource: 'icon.svg'
    iconColor: Theme.mainColor
    bgcolor: Theme.darkGray
    round: true
    onClicked: {
      resultsModel.clear()
      statusLabel.text = ""
      dialog.open()
    }
  }

  function projectHome() {
    if (typeof qgisProject === "undefined" || !qgisProject || !qgisProject.homePath)
      return ""
    var p = qgisProject.homePath
    return p.endsWith("/") ? p : p + "/"
  }

  function newPhotoName() {
    var d = new Date()
    function p2(n) { return (n < 10 ? "0" : "") + n }
    return "DCIM/plantnet_" + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate())
        + "_" + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds()) + ".JPG"
  }

  function acquire(fromCamera) {
    var home = projectHome()
    if (home === "") {
      statusLabel.error(qsTr("Najpierw otwórz projekt — zdjęcia lądują w jego katalogu."))
      return
    }
    platformUtilities.createDir(qgisProject.homePath, "DCIM")
    var filepath = newPhotoName()
    statusLabel.step(fromCamera ? qsTr("Uruchamiam aparat…") : qsTr("Otwieram galerię…"))
    if (fromCamera) {
      plugin.__resourceSource = platformUtilities.getCameraPicture(home, filepath, "JPG", plugin)
    } else {
      plugin.__resourceSource = platformUtilities.getGalleryPicture(home, filepath, plugin)
    }
  }

  Connections {
    target: plugin.__resourceSource ? plugin.__resourceSource : null
    ignoreUnknownSignals: true
    function onResourceReceived(path) {
      if (!path || path === "") {
        statusLabel.error(qsTr("Nie otrzymano zdjęcia (anulowano?)."))
        return
      }
      plugin.selectedFile = path.startsWith("/") ? path : plugin.projectHome() + path
      statusLabel.step(qsTr("Zdjęcie gotowe: ") + FileUtils.fileName(plugin.selectedFile))
    }
  }

  ListModel {
    id: resultsModel
  }

  TextEdit {
    id: clipboardHelper
    visible: false
    function copyText(t) {
      text = t
      selectAll()
      copy()
    }
  }

  Dialog {
    id: dialog
    parent: mainWindow.contentItem
    modal: true
    title: "Pl@ntNet — rozpoznanie gatunku"
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 40, 500)
    height: Math.min(mainWindow.height - 80, 640)
    standardButtons: Dialog.Close

    ColumnLayout {
      anchors.fill: parent
      spacing: 8

      TextField {
        id: apiKeyField
        Layout.fillWidth: true
        placeholderText: qsTr("Klucz API Pl@ntNet")
        text: pluginSettings.apiKey
        echoMode: TextInput.PasswordEchoOnEdit
        onEditingFinished: pluginSettings.apiKey = text.trim()
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        ComboBox {
          id: organCombo
          Layout.preferredWidth: 130
          textRole: "label"
          valueRole: "value"
          model: [
            { label: qsTr("liść"), value: "leaf" },
            { label: qsTr("kwiat"), value: "flower" },
            { label: qsTr("owoc"), value: "fruit" },
            { label: qsTr("kora"), value: "bark" },
            { label: qsTr("pokrój"), value: "auto" }
          ]
          Component.onCompleted: {
            currentIndex = Math.max(0, indexOfValue(pluginSettings.organ))
          }
          onActivated: pluginSettings.organ = currentValue
        }

        Button {
          Layout.fillWidth: true
          text: qsTr("📷 Zrób zdjęcie")
          onClicked: plugin.acquire(true)
        }

        Button {
          Layout.fillWidth: true
          text: qsTr("🖼 Galeria")
          onClicked: plugin.acquire(false)
        }
      }

      Image {
        id: photoPreview
        Layout.fillWidth: true
        Layout.preferredHeight: visible ? 140 : 0
        visible: plugin.selectedFile !== "" && status !== Image.Error
        source: plugin.selectedFile !== "" ? "file://" + plugin.selectedFile : ""
        fillMode: Image.PreserveAspectFit
        asynchronous: true
        cache: false
        sourceSize.width: 800
      }

      Button {
        Layout.fillWidth: true
        enabled: !plugin.busy && plugin.selectedFile !== "" && apiKeyField.text.trim() !== ""
        text: plugin.busy ? qsTr("Rozpoznawanie…") : qsTr("Rozpoznaj gatunek")
        onClicked: plugin.identify()
      }

      Label {
        id: statusLabel
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        font.bold: true
        property bool isError: false
        color: "#39ff14"                        // neonowa zieleń
        visible: text !== ""
        function step(t) { isError = false; text = t }
        function error(t) { isError = true; text = "⚠ " + t; plugin.busy = false }
      }

      ListView {
        id: resultsView
        Layout.fillWidth: true
        Layout.fillHeight: true
        clip: true
        model: resultsModel
        spacing: 4

        delegate: Rectangle {
          width: resultsView.width
          height: rowCol.implicitHeight + 16
          radius: 6
          color: index === 0 ? "#e8f5e9" : "#f5f5f5"

          Column {
            id: rowCol
            anchors.verticalCenter: parent.verticalCenter
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.margins: 10
            spacing: 2

            Label {
              width: parent.width
              text: score + "%  —  " + scientificName
              font.bold: index === 0
              font.italic: true
              wrapMode: Text.WordWrap
              color: "#212121"
            }
            Label {
              width: parent.width
              visible: commonName !== ""
              text: commonName
              wrapMode: Text.WordWrap
              color: "#555555"
            }
          }

          MouseArea {
            anchors.fill: parent
            onClicked: {
              clipboardHelper.copyText(scientificName)
              mainWindow.displayToast(qsTr("Skopiowano: ") + scientificName)
            }
          }
        }
      }

      Label {
        Layout.fillWidth: true
        text: qsTr("Dotknij gatunku, aby skopiować nazwę. Dane: Pl@ntNet (my.plantnet.org).")
        wrapMode: Text.WordWrap
        font.pointSize: 9
        color: "#9e9e9e"
      }
    }
  }

  // ---------------------------------------------------------- logika

  function identify() {
    plugin.busy = true
    resultsModel.clear()
    var stage = "start"
    try {
      stage = "readFileContent: " + plugin.selectedFile
      statusLabel.step(qsTr("Czytam zdjęcie…"))
      var content = FileUtils.readFileContent(plugin.selectedFile)
      var blen = (content && content.byteLength !== undefined) ? content.byteLength : -1
      stage = "wynik czytania: byteLength=" + blen
      if (blen <= 0) {
        statusLabel.error(qsTr("Zdjęcie nieczytelne (0 bajtów) — plik: ")
                          + plugin.selectedFile)
        return
      }
      stage = "konwersja do Uint8Array"
      var fileBytes = new Uint8Array(content)
      statusLabel.step(qsTr("Zdjęcie wczytane (") + Math.round(fileBytes.length / 1024)
                       + qsTr(" KB). Wysyłam do Pl@ntNet…"))
      plugin.sendToPlantNet(fileBytes)
    } catch (e) {
      statusLabel.error(qsTr("Błąd: ") + e + qsTr(" [etap: ") + stage + "]")
    }
  }

  function str2bytes(s) {
    var u = unescape(encodeURIComponent(s))
    var arr = new Uint8Array(u.length)
    for (var i = 0; i < u.length; i++)
      arr[i] = u.charCodeAt(i)
    return arr
  }

  function sendToPlantNet(fileBytes) {
    var boundary = "----WorkFieldPlantNet" + Date.now()
    var fname = FileUtils.fileName(plugin.selectedFile)

    var head = "--" + boundary + "\r\n"
        + 'Content-Disposition: form-data; name="organs"\r\n\r\n'
        + pluginSettings.organ + "\r\n"
        + "--" + boundary + "\r\n"
        + 'Content-Disposition: form-data; name="images"; filename="' + fname + '"\r\n'
        + "Content-Type: image/jpeg\r\n\r\n"
    var tail = "\r\n--" + boundary + "--\r\n"

    var h = str2bytes(head)
    var t = str2bytes(tail)
    var body = new Uint8Array(h.length + fileBytes.length + t.length)
    body.set(h, 0)
    body.set(fileBytes, h.length)
    body.set(t, h.length + fileBytes.length)

    var url = "https://my-api.plantnet.org/v2/identify/all"
        + "?api-key=" + encodeURIComponent(pluginSettings.apiKey.trim())
        + "&lang=pl&nb-results=6"

    try {
      var xhr = new XMLHttpRequest()
      xhr.open("POST", url)
      xhr.timeout = 45000
      xhr.ontimeout = function () {
        statusLabel.error(qsTr("Serwer nie odpowiedział w 45 s. Sprawdź zasięg."))
      }
      xhr.setRequestHeader("Content-Type", "multipart/form-data; boundary=" + boundary)
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== XMLHttpRequest.DONE)
          return
        plugin.busy = false
        if (xhr.status === 200) {
          statusLabel.step("")
          plugin.showResults(xhr.responseText)
        } else if (xhr.status === 401) {
          statusLabel.error(qsTr("Błędny klucz API (401). Sprawdź klucz na my.plantnet.org."))
        } else if (xhr.status === 404) {
          statusLabel.error(qsTr("Pl@ntNet nie rozpoznał żadnego gatunku na tym zdjęciu (404)."))
        } else if (xhr.status === 429) {
          statusLabel.error(qsTr("Wyczerpany dzienny limit zapytań (429)."))
        } else if (xhr.status === 0) {
          statusLabel.error(qsTr("Brak odpowiedzi (status 0) — problem z siecią lub wysyłką."))
        } else {
          statusLabel.error(qsTr("Błąd serwera: ") + xhr.status + " "
                            + xhr.responseText.substring(0, 120))
        }
      }
      xhr.send(body.buffer)
    } catch (e) {
      statusLabel.error(qsTr("Błąd przy wysyłce: ") + e)
    }
  }

  function showResults(responseText) {
    try {
      var json = JSON.parse(responseText)
      var results = json.results || []
      if (results.length === 0) {
        statusLabel.error(qsTr("Brak wyników."))
        return
      }
      for (var i = 0; i < results.length; i++) {
        var r = results[i]
        var common = ""
        if (r.species.commonNames && r.species.commonNames.length > 0)
          common = r.species.commonNames.join(", ")
        resultsModel.append({
          score: Math.round(r.score * 100),
          scientificName: r.species.scientificNameWithoutAuthor,
          commonName: common
        })
      }
    } catch (e) {
      statusLabel.error(qsTr("Nie udało się odczytać odpowiedzi serwera: ") + e)
    }
  }
}
