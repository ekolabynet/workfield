import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import Theme

/**
 * WorkField Grzyby — rozpoznawanie grzybów ze zdjęć przez mushroom.id (Kindwise).
 * Bliźniak wtyczki Pl@ntNet: ten sam układ okna, te same nawyki.
 *
 * Wersja 0.3 (07.10.2026): BEZPIECZEŃSTWO — decyzja Piotra: „usuńmy całkowicie
 *   informację o jadalności” („nie chciałbym doprowadzić do czyjegoś zagrożenia”).
 *   - wtyczka NIE pyta API o jadalność ani działanie psychoaktywne i NIE pokazuje
 *     ich wcale. Same ostrzeżenia też odpadły: brak plakietki „trujący” byłby
 *     odczytywany jako „jadalny”;
 *   - przy pierwszym użyciu (i po każdej zmianie tekstu) okno zgody: trzeba
 *     zaznaczyć „Rozumiem”, inaczej rozpoznanie jest niedostępne;
 *   - czerwony pas ostrzeżenia STALE u góry okna;
 *   - alarm nad wynikami, gdy najlepszy wynik ma mniej niż 80%;
 *   - sobowtóry zostają — to wiedza o pomyłkach w rozpoznaniu, nie o jadalności;
 *   - stopka: w razie podejrzenia zatrucia — 112.
 * Wersja 0.2 (07.10.2026): data zapytania w formacie, który serwer przyjmuje
 *   (0.1 dostawała 400 „Datetime … is not in ISO format”).
 * Wersja 0.1 (07.10.2026):
 *  - do 5 zdjęć TEGO SAMEGO grzyba naraz (kapelusz z góry, blaszki/rurki od spodu,
 *    trzon z nasadą, przekrój) = jedno rozpoznanie = jeden kredyt;
 *  - pozycja i data idą razem ze zdjęciami (podpowiedź dla modelu);
 *  - przy każdej propozycji: nazwy polskie, JADALNOŚĆ (barwą), działanie
 *    psychoaktywne, SOBOWTÓRY, cechy (blaszki, kapelusz, wysyp zarodników…),
 *    zdjęcia podobnych okazów, odnośnik do opisu gatunku;
 *  - licznik pozostałych kredytów (usage_info).
 *
 * JADALNOŚĆ JEST TYLKO INFORMACJĄ. Okno mówi to wprost i stale — to samo pisze
 * Kindwise w dokumentacji: „never use them as a foraging decision".
 *
 * Klucz API w ustawieniach urządzenia (sekcja WorkFieldMushroom), nigdy w kodzie.
 *
 * API (sprawdzone w kliencie kindwise-api-client 0.8.1):
 *   POST https://mushroom.kindwise.com/api/v1/identification?details=…&language=pl
 *   nagłówek Api-Key; treść JSON {images:[base64…], latitude, longitude,
 *   similar_images, datetime}; odpowiedź: result.is_mushroom.{probability,binary},
 *   result.classification.suggestions[].{name, probability, details, similar_images}
 *   GET  https://mushroom.kindwise.com/api/v1/usage_info  -> remaining.{day,week,month,total}
 */
Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property bool busy: false
  property var __resourceSource
  property string kredyty: ""

  readonly property string host: "https://mushroom.kindwise.com/api/v1"
  // BEZ edibility i psychoactive — wtyczka celowo nie zna jadalności (v0.3).
  readonly property string szczegoly: "common_names,url,look_alike,characteristic,rank"

  Settings {
    id: pluginSettings
    category: "WorkFieldMushroom"
    property string apiKey: ""
    // Numer wersji TEKSTU zgody, którą użytkownik zaakceptował. Zmiana
    // treści ostrzeżenia = podbicie ZGODA_WERSJA = zgoda pytana od nowa.
    property int zgodaWersja: 0
  }

  readonly property int zgodaWersjaWymagana: 1
  readonly property bool zgodaJest: pluginSettings.zgodaWersja >= zgodaWersjaWymagana
  property string alarm: ""

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(pluginButton)
  }

  QfToolButton {
    id: pluginButton
    iconSource: 'icon.svg'
    iconColor: "#B0BEC5"
    bgcolor: Theme.darkGray
    round: true
    onClicked: {
      dialog.open()
      if (!plugin.zgodaJest)
        zgodaDialog.open()
      if (pluginSettings.apiKey.trim() !== "")
        plugin.sprawdzKredyty()
    }
  }

  function projectHome() {
    if (typeof qgisProject === "undefined" || !qgisProject || !qgisProject.homePath)
      return ""
    var p = qgisProject.homePath
    return p.endsWith("/") ? p : p + "/"
  }

  function newPhotoName() {
    var d = new Date()
    function p2(n) { return (n < 10 ? "0" : "") + n }
    return "DCIM/grzyb_" + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate())
        + "_" + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds()) + ".JPG"
  }

  function acquire(fromCamera) {
    if (photosModel.count >= 5) {
      statusLabel.error(qsTr("Maksymalnie 5 zdjęć jednego grzyba."))
      return
    }
    var home = projectHome()
    if (home === "") {
      statusLabel.error(qsTr("Najpierw otwórz projekt — zdjęcia lądują w jego katalogu."))
      return
    }
    platformUtilities.createDir(qgisProject.homePath, "DCIM")
    var filepath = newPhotoName()
    statusLabel.step(fromCamera ? qsTr("Uruchamiam aparat…") : qsTr("Otwieram galerię…"))
    if (fromCamera) {
      plugin.__resourceSource = platformUtilities.getCameraPicture(home, filepath, "JPG", plugin)
    } else {
      plugin.__resourceSource = platformUtilities.getGalleryPicture(home, filepath, plugin)
    }
  }

  Connections {
    target: plugin.__resourceSource ? plugin.__resourceSource : null
    ignoreUnknownSignals: true
    function onResourceReceived(path) {
      if (!path || path === "") {
        statusLabel.error(qsTr("Nie otrzymano zdjęcia (anulowano?)."))
        return
      }
      var full = path.startsWith("/") ? path : plugin.projectHome() + path
      photosModel.append({ path: full })
      statusLabel.step(qsTr("Zdjęć w komplecie: ") + photosModel.count + "/5")
    }
  }

  ListModel {
    id: photosModel
  }

  ListModel {
    id: resultsModel
  }

  TextEdit {
    id: clipboardHelper
    visible: false
    function copyText(t) {
      text = t
      selectAll()
      copy()
    }
  }

  Dialog {
    id: dialog
    parent: mainWindow.contentItem
    modal: true
    title: "Grzyby — rozpoznanie (mushroom.id)"
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 40, 520)
    height: Math.min(mainWindow.height - 80, 720)
    standardButtons: Dialog.Close

    ColumnLayout {
      anchors.fill: parent
      spacing: 8

      // STALE u góry — widoczne zanim cokolwiek się zrobi i przez cały czas.
      Rectangle {
        Layout.fillWidth: true
        implicitHeight: pasTxt.implicitHeight + 14
        radius: 6
        color: "#b71c1c"

        Label {
          id: pasTxt
          anchors.fill: parent
          anchors.margins: 7
          wrapMode: Text.WordWrap
          color: "#ffffff"
          font.bold: true
          text: qsTr("⚠ NIE JEDZ grzyba na podstawie tej aplikacji. Rozpoznanie ze zdjęcia bywa błędne, a pomyłka może kosztować życie. O jadalności rozstrzyga wyłącznie grzyboznawca.")
        }
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        TextField {
          id: apiKeyField
          Layout.fillWidth: true
          placeholderText: qsTr("Klucz API Kindwise (mushroom.id)")
          text: pluginSettings.apiKey
          echoMode: TextInput.PasswordEchoOnEdit
          onEditingFinished: {
            pluginSettings.apiKey = text.trim()
            plugin.sprawdzKredyty()
          }
        }

        Label {
          visible: plugin.kredyty !== ""
          text: plugin.kredyty
          color: "#9e9e9e"
          font.pointSize: 9
        }
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Button {
          Layout.fillWidth: true
          enabled: photosModel.count < 5
          text: qsTr("📷 Zrób zdjęcie")
          onClicked: plugin.acquire(true)
        }

        Button {
          Layout.fillWidth: true
          enabled: photosModel.count < 5
          text: qsTr("🖼 Galeria")
          onClicked: plugin.acquire(false)
        }

        Button {
          visible: photosModel.count > 0
          text: qsTr("Wyczyść")
          onClicked: {
            photosModel.clear()
            resultsModel.clear()
            plugin.alarm = ""
            statusLabel.text = ""
          }
        }
      }

      ListView {
        id: photoStrip
        Layout.fillWidth: true
        Layout.preferredHeight: photosModel.count > 0 ? 80 : 0
        visible: photosModel.count > 0
        orientation: ListView.Horizontal
        spacing: 6
        clip: true
        model: photosModel

        delegate: Rectangle {
          width: 78
          height: 78
          radius: 6
          color: "#263238"

          Image {
            anchors.fill: parent
            anchors.margins: 1
            source: "file://" + path
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
            cache: false
            sourceSize.width: 300
          }

          Rectangle {
            width: 26
            height: 26
            radius: 13
            color: "#c62828"
            anchors.top: parent.top
            anchors.right: parent.right
            anchors.margins: 2

            Label {
              anchors.centerIn: parent
              text: "✕"
              color: "#ffffff"
              font.bold: true
            }

            MouseArea {
              anchors.fill: parent
              onClicked: photosModel.remove(index)
            }
          }
        }
      }

      Button {
        Layout.fillWidth: true
        enabled: plugin.zgodaJest && !plugin.busy && photosModel.count > 0 && apiKeyField.text.trim() !== ""
        text: plugin.busy ? qsTr("Rozpoznawanie…")
                          : qsTr("Rozpoznaj grzyba (zdjęć: ") + photosModel.count + ")"
        onClicked: plugin.identify()
      }

      Label {
        id: statusLabel
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        font.bold: true
        property bool isError: false
        color: isError ? "#ff8a65" : "#39ff14"
        visible: text !== ""
        function step(t) { isError = false; text = t }
        function error(t) { isError = true; text = "⚠ " + t; plugin.busy = false }
      }

      // Alarm wyników: trujący kandydat w zestawie albo niska pewność.
      Rectangle {
        Layout.fillWidth: true
        visible: plugin.alarm !== ""
        implicitHeight: alarmTxt.implicitHeight + 16
        radius: 6
        color: "#7f0000"
        border.color: "#ffeb3b"
        border.width: 3

        Label {
          id: alarmTxt
          anchors.fill: parent
          anchors.margins: 8
          wrapMode: Text.WordWrap
          color: "#ffffff"
          font.bold: true
          text: plugin.alarm
        }
      }

      ListView {
        id: resultsView
        Layout.fillWidth: true
        Layout.fillHeight: true
        clip: true
        model: resultsModel
        spacing: 6

        delegate: Rectangle {
          width: resultsView.width
          height: rowCol.implicitHeight + 16
          radius: 6
          color: index === 0 ? "#efebe9" : "#f5f5f5"

          Column {
            id: rowCol
            anchors.verticalCenter: parent.verticalCenter
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.margins: 10
            spacing: 3

            RowLayout {
              width: parent.width
              spacing: 6

              Label {
                Layout.fillWidth: true
                text: score + "%  —  " + scientificName
                font.bold: index === 0
                font.italic: true
                wrapMode: Text.WordWrap
                color: "#212121"
              }

              Button {
                visible: link !== ""
                text: "🌐"
                implicitWidth: 40
                implicitHeight: 32
                onClicked: Qt.openUrlExternally(link)
              }
            }

            Label {
              width: parent.width
              visible: commonName !== ""
              text: commonName
              wrapMode: Text.WordWrap
              color: "#555555"
            }

            Label {
              width: parent.width
              visible: sobowtory !== ""
              text: qsTr("Mylony z: ") + sobowtory
              wrapMode: Text.WordWrap
              color: "#bf360c"
              font.pointSize: 9
            }

            Label {
              width: parent.width
              visible: cechy !== ""
              text: cechy
              wrapMode: Text.WordWrap
              color: "#616161"
              font.pointSize: 9
            }

            Row {
              spacing: 4
              visible: zdjecia !== ""

              Repeater {
                model: zdjecia !== "" ? zdjecia.split("|") : []

                Image {
                  width: 64
                  height: 64
                  source: modelData
                  fillMode: Image.PreserveAspectCrop
                  asynchronous: true
                }
              }
            }
          }

          MouseArea {
            // pod przyciskiem 🌐 — on dostaje dotyk pierwszy
            anchors.fill: parent
            z: -1
            onClicked: {
              clipboardHelper.copyText(scientificName)
              mainWindow.displayToast(qsTr("Skopiowano: ") + scientificName)
            }
          }
        }
      }

      Label {
        Layout.fillWidth: true
        text: qsTr("Do 5 zdjęć tego samego grzyba: kapelusz z góry, spód (blaszki/rurki), trzon z nasadą, przekrój. Dotknij wyniku, aby skopiować nazwę. Dane: mushroom.id (Kindwise). Podejrzenie zatrucia: dzwoń 112.")
        wrapMode: Text.WordWrap
        font.pointSize: 9
        color: "#9e9e9e"
      }
    }
  }

  // ---------------------------------------------------------- logika


  readonly property var cechyPL: ({
    "hymenium attachment": "przyrost blaszek",
    "hymenium type": "hymenofor",
    "mushroom cap shape": "kapelusz",
    "mushroom ecological type": "tryb życia",
    "spore print color": "wysyp zarodników",
    "stipe character": "trzon"
  })

  // Wartości cech przychodzą po angielsku (pole nie jest tłumaczone przez API).
  readonly property var wartosciPL: ({
    "gills": "blaszki", "pores": "rurki", "teeth": "kolce", "ridges": "listewki", "smooth": "gładki",
    "free": "wolne", "adnate": "przyrośnięte", "adnexed": "wykrojone", "decurrent": "zbiegające",
    "sinuate": "zatokowato wycięte", "seceding": "odstające", "none": "brak",
    "ring": "pierścień", "volva": "pochwa", "ring and volva": "pierścień i pochwa", "bare": "nagi",
    "mycorrhizal": "mikoryzowy", "saprotrophic": "saprotrof", "parasitic": "pasożyt",
    "convex": "wypukły", "flat": "płaski", "conical": "stożkowaty", "campanulate": "dzwonkowaty",
    "infundibuliform": "lejkowaty", "umbonate": "z garbkiem", "depressed": "wklęsły",
    "offset": "boczny", "ovate": "jajowaty",
    "white": "biały", "cream": "kremowy", "yellow": "żółty", "ochre": "ochrowy", "pink": "różowy",
    "salmon": "łososiowy", "tan": "płowy", "brown": "brązowy", "reddish brown": "rdzawobrązowy",
    "purple": "fioletowy", "purple-brown": "purpurowobrązowy", "purple-black": "purpurowoczarny",
    "black": "czarny", "olive": "oliwkowy", "green": "zielony", "buff": "płowożółty"
  })

  function poPolsku(v) {
    var t = String(v).trim()
    return wartosciPL[t.toLowerCase()] || t
  }

  function currentLatLon() {
    try {
      var ms = iface.mapCanvas().mapSettings
      var wgs = GeometryUtils.reprojectPointToWgs84(ms.center, ms.destinationCrs)
      if (Math.abs(wgs.y) <= 90 && Math.abs(wgs.x) <= 180)
        return { lat: wgs.y, lon: wgs.x }
    } catch (e) {
    }
    return null
  }

  // Base64 z bajtów — własny, bo Qt.btoa przyjmuje TEKST i psuje bajty > 127.
  function base64(u8) {
    var T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    var kaw = [], wynik = [], n = u8.length, i = 0, v
    for (; i + 2 < n; i += 3) {
      v = (u8[i] << 16) | (u8[i + 1] << 8) | u8[i + 2]
      kaw.push(T[(v >> 18) & 63] + T[(v >> 12) & 63] + T[(v >> 6) & 63] + T[v & 63])
      if (kaw.length >= 16384) {
        wynik.push(kaw.join(""))
        kaw = []
      }
    }
    if (i < n) {
      v = u8[i] << 16
      if (i + 1 < n)
        v |= u8[i + 1] << 8
      kaw.push(T[(v >> 18) & 63] + T[(v >> 12) & 63]
               + (i + 1 < n ? T[(v >> 6) & 63] : "=") + "=")
    }
    wynik.push(kaw.join(""))
    return wynik.join("")
  }

  function sprawdzKredyty() {
    var klucz = pluginSettings.apiKey.trim()
    if (klucz === "") {
      kredyty = ""
      return
    }
    var xhr = new XMLHttpRequest()
    xhr.open("GET", host + "/usage_info")
    xhr.setRequestHeader("Api-Key", klucz)
    xhr.timeout = 15000
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== XMLHttpRequest.DONE)
        return
      if (xhr.status === 200) {
        try {
          var u = JSON.parse(xhr.responseText)
          var r = u.remaining || {}
          var ile = r.total !== null && r.total !== undefined ? r.total
                  : r.month !== null && r.month !== undefined ? r.month
                  : r.day
          kredyty = (ile === null || ile === undefined) ? "" : qsTr("kredyty: ") + ile
        } catch (e) {
          kredyty = ""
        }
      } else if (xhr.status === 401) {
        kredyty = qsTr("zły klucz")
      } else {
        kredyty = ""
      }
    }
    xhr.send()
  }

  function identify() {
    plugin.busy = true
    resultsModel.clear()
    plugin.alarm = ""
    var stage = "start"
    try {
      var obrazy = []
      var totalKB = 0
      for (var i = 0; i < photosModel.count; i++) {
        var ph = photosModel.get(i)
        stage = "czytanie " + (i + 1) + "/" + photosModel.count + ": " + ph.path
        statusLabel.step(qsTr("Czytam zdjęcie ") + (i + 1) + "/" + photosModel.count + "…")
        var content = FileUtils.readFileContent(ph.path)
        // pusty ArrayBuffer wysadza new Uint8Array — sprawdzamy PRZED
        var blen = (content && content.byteLength !== undefined) ? content.byteLength : -1
        if (blen <= 0) {
          statusLabel.error(qsTr("Zdjęcie ") + (i + 1) + qsTr(" nieczytelne (0 bajtów): ") + ph.path)
          return
        }
        totalKB += Math.round(blen / 1024)
        stage = "kodowanie " + (i + 1)
        obrazy.push(base64(new Uint8Array(content)))
      }

      // Data BEZ milisekund i z „+00:00” zamiast „Z”: serwer czyta ją jak Python
      // sprzed 3.11 (datetime.fromisoformat) i „…T17:28:08.440Z” odrzucał
      // błędem 400 „not in ISO format” (próba Piotra 07.10.2026, v0.1).
      var teraz = new Date().toISOString().replace(/\.\d+Z$/, "+00:00")
      var tresc = { images: obrazy, similar_images: true, datetime: teraz }
      var pos = currentLatLon()
      if (pos) {
        tresc.latitude = Number(pos.lat.toFixed(5))
        tresc.longitude = Number(pos.lon.toFixed(5))
      }
      stage = "wysyłka"
      statusLabel.step(qsTr("Wysyłam ") + photosModel.count + qsTr(" zdj. (") + totalKB
                       + qsTr(" KB) do mushroom.id…"))

      var xhr = new XMLHttpRequest()
      xhr.open("POST", host + "/identification?details=" + szczegoly + "&language=pl")
      xhr.setRequestHeader("Api-Key", pluginSettings.apiKey.trim())
      xhr.setRequestHeader("Content-Type", "application/json")
      xhr.timeout = 90000
      xhr.ontimeout = function () {
        statusLabel.error(qsTr("Serwer nie odpowiedział w 90 s. Sprawdź zasięg."))
      }
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== XMLHttpRequest.DONE)
          return
        plugin.busy = false
        if (xhr.status === 200 || xhr.status === 201) {
          statusLabel.step("")
          plugin.showResults(xhr.responseText)
          plugin.sprawdzKredyty()
        } else if (xhr.status === 401) {
          statusLabel.error(qsTr("Błędny klucz API (401). Sprawdź klucz na admin.kindwise.com."))
        } else if (xhr.status === 413) {
          statusLabel.error(qsTr("Zdjęcia łącznie za duże (413) — usuń któreś i spróbuj ponownie."))
        } else if (xhr.status === 429 || xhr.status === 402) {
          statusLabel.error(qsTr("Wyczerpane kredyty albo limit zapytań (") + xhr.status + ").")
        } else if (xhr.status === 0) {
          statusLabel.error(qsTr("Brak odpowiedzi (status 0) — problem z siecią lub wysyłką."))
        } else {
          statusLabel.error(qsTr("Błąd serwera: ") + xhr.status + " "
                            + xhr.responseText.substring(0, 160))
        }
      }
      xhr.send(JSON.stringify(tresc))
    } catch (e) {
      statusLabel.error(qsTr("Błąd: ") + e + qsTr(" [etap: ") + stage + "]")
    }
  }

  function showResults(responseText) {
    try {
      var json = JSON.parse(responseText)
      var wynik = json.result || {}
      var sug = (wynik.classification && wynik.classification.suggestions) || []
      if (sug.length === 0) {
        statusLabel.error(qsTr("Brak wyników."))
        return
      }
      var grzyb = wynik.is_mushroom
      if (grzyb && grzyb.binary === false) {
        statusLabel.error(qsTr("Na zdjęciu raczej nie ma grzyba (szansa, że to grzyb: ")
                          + Math.round((grzyb.probability || 0) * 100) + qsTr("%). Wyniki niżej są mało wiarygodne."))
      }
      for (var i = 0; i < sug.length && i < 6; i++) {
        var s = sug[i]
        var d = s.details || {}
        var sob = (d.look_alike || []).map(function (x) { return x.name }).filter(function (x) { return !!x })
        var ch = d.characteristic || {}
        var cz = []
        for (var k in ch) {
          if (ch[k] !== null && ch[k] !== undefined && String(ch[k]) !== "")
            cz.push((cechyPL[k] || k) + ": "
                    + (Array.isArray(ch[k]) ? ch[k].map(poPolsku).join(", ") : poPolsku(ch[k])))
        }
        var zdj = (s.similar_images || []).slice(0, 3)
                  .map(function (x) { return x.url_small || x.url || "" })
                  .filter(function (x) { return x !== "" })
        resultsModel.append({
          score: Math.round((s.probability || 0) * 100),
          scientificName: s.name || "?",
          commonName: (d.common_names || []).join(", "),
          link: d.url || "",
          sobowtory: sob.join(", "),
          cechy: cz.join(" · "),
          zdjecia: zdj.join("|")
        })
      }
      var al = []
      var najlepszy = Math.round(((sug[0] && sug[0].probability) || 0) * 100)
      if (najlepszy < 80)
        al.push(qsTr("Rozpoznanie NIEPEWNE (najlepszy wynik ") + najlepszy + "%).")
      plugin.alarm = al.join("\n")
    } catch (e) {
      statusLabel.error(qsTr("Nie udało się odczytać odpowiedzi serwera: ") + e)
    }
  }

  // ---------------------------------------------------------- zgoda
  Dialog {
    id: zgodaDialog
    parent: mainWindow.contentItem
    modal: true
    closePolicy: Popup.NoAutoClose
    title: qsTr("Zanim zaczniesz — przeczytaj")
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 40, 480)

    ColumnLayout {
      anchors.fill: parent
      spacing: 10

      Label {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        color: "#c62828"
        font.bold: true
        text: qsTr("Ta wtyczka NIE służy do oceny, czy grzyb jest jadalny.")
      }

      Label {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        text: qsTr("• Rozpoznanie ze zdjęcia bywa błędne — także przy wysokiej pewności.\n"
                   + "• Śmiertelnie trujące grzyby (np. muchomor zielonawy) mają jadalnych sobowtórów.\n"
                   + "• Wtyczka CELOWO nie podaje, czy grzyb jest jadalny czy trujący — tylko nazwę i podobne gatunki.\n"
                   + "• O jadalności rozstrzyga wyłącznie grzyboznawca (punkt sanepidu), na żywym okazie.\n"
                   + "• Podejrzenie zatrucia: natychmiast 112.")
      }

      CheckBox {
        id: zgodaCheck
        Layout.fillWidth: true
        text: qsTr("Rozumiem. Nie będę zbierać ani jeść grzybów na podstawie tej aplikacji.")
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Button {
          Layout.fillWidth: true
          text: qsTr("Anuluj")
          onClicked: {
            zgodaDialog.close()
            dialog.close()
          }
        }

        Button {
          Layout.fillWidth: true
          enabled: zgodaCheck.checked
          text: qsTr("Dalej")
          onClicked: {
            pluginSettings.zgodaWersja = plugin.zgodaWersjaWymagana
            zgodaDialog.close()
          }
        }
      }
    }
  }
}
