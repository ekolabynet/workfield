import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import Theme

/**
 * WorkField Konsola — naprawa bazy z telefonu.
 *
 *   tapnięcie w ikonę → okno konsoli,
 *   przyciski u góry  → gotowe naprawy jednym tapnięciem,
 *   pole na dole      → własne polecenie SQL.
 *
 * ==========================================================================
 * PO CO
 * ==========================================================================
 * 07.09.2026 trzy razy w ciągu dnia trzeba było wracać do komputera po
 * rzeczy, które dały się zrobić na miejscu:
 *
 *   * **indeks przestrzenny miał 78 wpisów przy 203 obiektach** — warstwa
 *     się wczytywała, „Przybliż do warstwy" działało, a na mapie było
 *     pusto. Szukanie przyczyny zajęło godzinę.
 *   * **tabele ZAL_ nie były zarejestrowane** w `gpkg_contents`, więc QGIS
 *     ich nie widział mimo że istniały.
 *   * **sprawdzenie, czy wiersz naprawdę się zapisał** — po tym, jak pole
 *     FOTO okazało się puste przy istniejących plikach.
 *
 * Wszystkie trzy to jedna linijka SQL. Bez konsoli znaczyły przerwaną pracę
 * i powrót do biura.
 *
 * ==========================================================================
 * DLACZEGO TO NARZĘDZIE OSTRE
 * ==========================================================================
 * Pozwala wykonać dowolne polecenie na bazie, w tym `DELETE` i `DROP TABLE`.
 * W terenie, po ośmiu godzinach, przy zmęczeniu.
 *
 * Stąd trzy zabezpieczenia, z których żadne nie zależy od uwagi człowieka:
 *
 *   1. **Kopia bazy przed każdym poleceniem zmieniającym** — robi ją sam
 *      czasownik `zapytanieSql`, przez mechanizm z 07.09. Kopia z tej samej
 *      minuty się nie powtarza, więc seria poleceń kosztuje jedną.
 *   2. **`ATTACH` odrzucane** — dołączenie innej bazy pozwoliłoby pisać poza
 *      projektem.
 *   3. **Polecenia zmieniające wymagają potwierdzenia** — osobne tapnięcie,
 *      z pokazaniem, co się wykona.
 *
 * Zasada z `docs/KOMITET.md`, wpisana po utracie danych 20.08:
 * *operacje hurtowe na danych nie powstają po ośmiu godzinach*. Konsola tej
 * zasady nie łamie — ona ją egzekwuje, robiąc kopię za człowieka.
 *
 * Diagnostyka: prefiks "KONSOLA:" (grep "KONSOLA:").
 */
Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property string wynik: ""
  property string doPotwierdzenia: ""
  property var historia: []

  //! Ścieżka do bazy projektu — wyciągana z pierwszej warstwy wektorowej.
  //! Projekt może mieć kilka źródeł; bierzemy `dane.gpkg`, bo taka jest
  //! konwencja WorkField (patrz docs/MAGAZYN.md).
  function sciezkaBazy() {
    // `qgisProject.mapLayers()` NIE JEST funkcja w QML — to wlasciwosc
    // mapowa po stronie C++, niedostepna stad. Zamiast tego bierzemy
    // sciezke z KATALOGU PROJEKTU: w WorkField baza zawsze nazywa sie
    // `dane.gpkg` i lezy obok `projekt.qgs` (docs/MAGAZYN.md).
    const dom = qgisProject && qgisProject.homePath ? String(qgisProject.homePath) : "";
    if (dom !== "") {
      const kandydat = dom + "/dane.gpkg";
      if (FileUtils.fileExists(kandydat))
        return kandydat;
    }
    // Zapasowo: sciezka warstwy, w ktorej stoi kursor.
    const w = iface.activeLayer ? iface.activeLayer() : null;
    if (w && w.source) {
      const s = String(w.source).split("|")[0];
      if (s.toLowerCase().endsWith(".gpkg"))
        return s;
    }
    return "";
  }

  function log(t) {
    iface.logMessage("KONSOLA: " + t);
  }

  /**
   * Wykonuje polecenie i wypisuje wynik.
   *
   * Polecenia zmieniające przechodzą przez potwierdzenie — nie dlatego, że
   * człowiek może się rozmyślić, tylko dlatego, że w terenie łatwo tapnąć
   * nie w to miejsce.
   */
  function wykonaj(sql, odRazu) {
    // Diagnostyka w OKNIE, nie w logu: `iface.logMessage` z wtyczki nie
    // trafia do wyjscia aplikacji, wiec log nic nie mowil.
    let diag = "qgisProject: " + (typeof qgisProject) +
               " | FileUtils: " + (typeof FileUtils) +
               " | zapytanieSql: " + (typeof FileUtils !== 'undefined' ? typeof FileUtils.zapytanieSql : "-");
    let baza = "";
    try {
      baza = sciezkaBazy();
    } catch (e) {
      wynik = diag + "\n\nBLAD w sciezkaBazy(): " + e;
      return;
    }
    diag += "\nbaza: " + (baza === "" ? "(nie znaleziona)" : baza);
    if (baza === "") {
      wynik = diag;
      return;
    }

    const zmienia = /^\s*(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|REPLACE|VACUUM)/i.test(sql);
    if (zmienia && !odRazu) {
      doPotwierdzenia = sql;
      wynik = "TO ZMIENI DANE:\n\n" + sql + "\n\nTapnij „Wykonaj mimo to”.\n" +
              "Kopia bazy zrobi się automatycznie.";
      return;
    }
    doPotwierdzenia = "";

    log("wykonuję: " + sql.substring(0, 120));
    const r = FileUtils.zapytanieSql(baza, sql);

    if (historia.indexOf(sql) < 0) {
      const h = historia.slice();
      h.unshift(sql);
      historia = h.slice(0, 20);
    }

    if (!r || r.length === 0) {
      wynik = "(brak wyniku)";
      return;
    }
    if (r[0]["blad"] !== undefined) {
      wynik = "BŁĄD: " + r[0]["blad"];
      log("błąd: " + r[0]["blad"]);
      return;
    }

    // Wypisanie: nagłówek z nazwami kolumn, potem wiersze. Przy jednej
    // kolumnie bez nagłówka — zwykle to licznik i nagłówek tylko zaśmieca.
    let t = "";
    const kolumny = Object.keys(r[0]);
    if (kolumny.length > 1)
      t += kolumny.join("  |  ") + "\n" + "—".repeat(40) + "\n";
    for (var i = 0; i < r.length; i++) {
      const w = r[i];
      let linia = [];
      for (var j = 0; j < kolumny.length; j++)
        linia.push(String(w[kolumny[j]] === undefined ? "" : w[kolumny[j]]));
      t += linia.join("  |  ") + "\n";
    }
    t += "\n(" + r.length + " " + (r.length === 1 ? "wiersz" : "wierszy") + ")";
    wynik = t;
  }

  // ------------------------------------------------------------ NAPRAWY
  //
  // Cztery rzeczy, po które 07.09 trzeba było wracać do komputera.
  // Każda jest jednym poleceniem — konsola tylko je pamięta.

  function stanIndeksow() {
    wykonaj(
      "SELECT c.table_name AS warstwa, " +
      "  (SELECT count(*) FROM gpkg_contents x WHERE x.table_name=c.table_name) AS jest " +
      "FROM gpkg_geometry_columns c", true);
    // Pełne porównanie wymaga zapytania per warstwa — robi to `sprawdzWarstwe`.
  }

  function stanBazy() {
    wykonaj(
      "SELECT table_name AS tabela, data_type AS rodzaj FROM gpkg_contents " +
      "ORDER BY data_type, table_name", true);
  }

  /**
   * Porównuje liczbę obiektów z liczbą wpisów w indeksie.
   *
   * Rozjazd o kilka bywa normalny — indeks pomija geometrie puste. Ale
   * **zero przy niezerowej liczbie obiektów znaczy, że warstwa się nie
   * narysuje**, choć dane są. To był objaw z 07.09.
   */
  function sprawdzWarstwe(nazwa) {
    wykonaj(
      "SELECT (SELECT count(geom) FROM \"" + nazwa + "\") AS obiektow, " +
      "       (SELECT count(*) FROM \"rtree_" + nazwa + "_geom\") AS w_indeksie", true);
  }

  /**
   * Zdejmuje wpis blokujący założenie indeksu.
   *
   * `gpkg_extensions` zostaje po usuniętej tabeli i przy ponownym
   * `CreateSpatialIndex` GDAL trafia na klucz unikalny — przerywa CAŁE
   * tworzenie wyzwalaczy i zostawia tabelę bez indeksu.
   *
   * Samego indeksu wtyczka nie odbuduje: to wymaga funkcji SpatiaLite
   * (`ST_MinX`), których zwykły sqlite nie zna. Ale po tym poleceniu
   * odbudowa w QGIS albo przez `ogrinfo` przechodzi.
   */
  function odblokujIndeks(nazwa) {
    wykonaj("DELETE FROM gpkg_extensions WHERE table_name='" + nazwa + "'");
  }

  /**
   * Rejestruje tabelę bez geometrii, żeby QGIS ją zobaczył.
   *
   * Samo `CREATE TABLE` nie wystarcza — GeoPackage wymaga wpisu
   * w `gpkg_contents` jako `attributes`. 07.09 trzy tabele ZAL_ istniały
   * fizycznie i były niewidoczne.
   */
  function zarejestruj(nazwa) {
    wykonaj("INSERT OR REPLACE INTO gpkg_contents " +
            "(table_name, data_type, identifier, description, last_change, srs_id) " +
            "VALUES ('" + nazwa + "', 'attributes', '" + nazwa + "', '', datetime('now'), NULL)");
  }

  //! Ktora zakladka: 0 = SQL (baza), 1 = QML (aplikacja).
  property int zakladka: 0

  /**
   * Kopia projektu przed wykonaniem kodu.
   *
   * Kod QML siega DALEJ niz SQL: moze zmienic stylizacje, zamknac projekt,
   * usunac warstwe. Kopia bazy przed tym nie chroni, bo stylizacja siedzi
   * w `projekt.qgs`, nie w `dane.gpkg`.
   */
  function kopiaProjektu() {
    const dom = qgisProject && qgisProject.homePath ? String(qgisProject.homePath) : "";
    if (dom === "")
      return "";
    const zrodlo = dom + "/projekt.qgs";
    if (!FileUtils.fileExists(zrodlo))
      return "";
    const d = new Date();
    const znacznik = d.getFullYear() +
      ("0" + (d.getMonth() + 1)).slice(-2) + ("0" + d.getDate()).slice(-2) + "_" +
      ("0" + d.getHours()).slice(-2) + ("0" + d.getMinutes()).slice(-2);
    const cel = dom + "/kopie/projekt_" + znacznik + ".qgs";
    if (FileUtils.fileExists(cel))
      return cel;
    const tresc = FileUtils.readFileContent(zrodlo);
    if (!tresc || tresc.byteLength === 0)
      return "";
    return FileUtils.writeFileContent(cel, tresc) ? cel : "";
  }

  /**
   * Wykonuje kod JavaScript w kontekscie aplikacji.
   *
   * Zamysl Piotra: *„gdybys mogl mi w terenie przeslac kod do wklejenia,
   * to ja moglbym nanosic zmiany prosto w terenie"*. Interfejs ma
   * ograniczona liczbe opcji; kod siega tam, gdzie ekrany nie siegaja.
   */
  function wykonajQml(kod) {
    if (kod.trim() === "")
      return;
    const k = kopiaProjektu();
    const naglowek = k !== "" ? "kopia: " + k.split("/").pop() + "\n\n"
                              : "UWAGA: bez kopii projektu\n\n";
    try {
      const r = eval(kod);
      wynik = naglowek + (r === undefined ? "(wykonane, bez wyniku)" : String(r));
    } catch (e) {
      wynik = naglowek + "BLAD: " + e;
    }
    if (historia.indexOf(kod) < 0) {
      const h = historia.slice();
      h.unshift(kod);
      historia = h.slice(0, 20);
    }
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(przyciskWtyczki);
    log("wtyczka wczytana");
  }

  QfToolButton {
    id: przyciskWtyczki
    iconSource: 'icon.svg'
    iconColor: Theme.mainColor
    bgcolor: Theme.darkGray
    round: true
    onClicked: {
      if (!ustawienia.wlaczona) {
        mainWindow.displayToast(
          "Konsola wyłączona — włącz w ustawieniach wtyczki (przytrzymaj ikonę)", "warning");
        return;
      }
      wynik = "";
      doPotwierdzenia = "";
      okno.open();
    }
    onPressAndHold: oknoUstawien.open()
  }

  Settings {
    id: ustawienia
    category: "WorkFieldKonsola"
    //! Domyślnie WYŁĄCZONA. Narzędzie, którym da się zepsuć dane, nie
    //! powinno czekać pod ręką na przypadkowe tapnięcie.
    property bool wlaczona: false
  }

  // -------------------------------------------------------------- OKNO
  Popup {
    id: okno
    parent: mainWindow.contentItem
    width: Math.min(parent.width * 0.95, 700)
    height: parent.height * 0.85
    x: (parent.width - width) / 2
    y: (parent.height - height) / 2
    modal: true
    padding: 0

    background: Rectangle {
      color: Theme.mainBackgroundColor
      radius: 6
      border.width: 1
      border.color: Theme.mainColor
    }

    ColumnLayout {
      anchors.fill: parent
      anchors.margins: 10
      spacing: 8

      RowLayout {
        Layout.fillWidth: true
        Text {
          Layout.fillWidth: true
          text: "Konsola — naprawa bazy"
          color: Theme.mainTextColor
          font.bold: true
          font.pointSize: Theme.defaultFont.pointSize
        }
        QfToolButton {
          iconSource: Theme.getThemeVectorIcon("ic_close_white_24dp")
          iconColor: Theme.mainTextColor
          bgcolor: "transparent"
          onClicked: okno.close()
        }
      }

      Text {
        Layout.fillWidth: true
        text: plugin.sciezkaBazy() === "" ? "brak bazy projektu"
              : plugin.sciezkaBazy().split("/").slice(-2).join("/")
        color: Theme.secondaryTextColor
        font.pointSize: Theme.tinyFont.pointSize
        elide: Text.ElideMiddle
      }

      // Dwie zakladki, bo to dwa rozne swiaty: SQL siega do bazy,
      // kod QML do aplikacji. Mylenie ich konczy sie bledem skladni
      // i minuta zastanawiania sie, czemu nie dziala.
      RowLayout {
        Layout.fillWidth: true
        spacing: 0
        Repeater {
          model: ["Baza (SQL)", "Aplikacja (kod)"]
          Button {
            required property int index
            required property var modelData
            Layout.fillWidth: true
            text: modelData
            font.pointSize: Theme.tinyFont.pointSize
            checkable: true
            checked: plugin.zakladka === index
            onClicked: {
              plugin.zakladka = index;
              plugin.wynik = "";
              plugin.doPotwierdzenia = "";
            }
          }
        }
      }

      // --- gotowe naprawy
      Flow {
        visible: plugin.zakladka === 0
        Layout.fillWidth: true
        spacing: 6

        Repeater {
          model: [
            { "t": "Stan bazy", "f": "stanBazy" },
            { "t": "Płaty: indeks", "f": "platyIndeks" },
            { "t": "Spis: indeks", "f": "spisIndeks" },
            { "t": "Miejsce", "f": "miejsce" }
          ]
          Button {
            required property var modelData
            text: modelData.t
            font.pointSize: Theme.tinyFont.pointSize
            padding: 6
            onClicked: {
              if (modelData.f === "stanBazy")
                plugin.stanBazy();
              else if (modelData.f === "platyIndeks")
                plugin.sprawdzWarstwe("FITO_PLATY");
              else if (modelData.f === "spisIndeks")
                plugin.sprawdzWarstwe("FITO_SPIS_GATUNKOWY");
              else if (modelData.f === "miejsce")
                plugin.wykonaj("SELECT page_count*page_size/1024/1024 AS baza_MB " +
                               "FROM pragma_page_count(), pragma_page_size()", true);
            }
          }
        }
      }

      // --- wynik
      ScrollView {
        Layout.fillWidth: true
        Layout.fillHeight: true
        clip: true

        TextArea {
          text: plugin.wynik
          readOnly: true
          wrapMode: TextEdit.Wrap
          selectByMouse: true
          font.family: "monospace"
          font.pointSize: Theme.tinyFont.pointSize
          color: plugin.wynik.indexOf("BŁĄD") === 0 ? "#ff6b6b"
                 : (plugin.doPotwierdzenia !== "" ? "#ffa726" : Theme.mainTextColor)
          background: Rectangle {
            color: Theme.controlBackgroundColor
            radius: 4
          }
        }
      }

      // --- potwierdzenie, gdy polecenie zmienia dane
      Button {
        Layout.fillWidth: true
        visible: plugin.doPotwierdzenia !== ""
        text: "Wykonaj mimo to (kopia zrobi się sama)"
        palette.button: "#ffa726"
        onClicked: plugin.wykonaj(plugin.doPotwierdzenia, true)
      }

      // --- pole polecenia
      RowLayout {
        Layout.fillWidth: true
        visible: plugin.zakladka === 0
        spacing: 6

        TextField {
          id: polePolecenia
          Layout.fillWidth: true
          placeholderText: "SELECT count(*) FROM FITO_PLATY"
          font.family: "monospace"
          font.pointSize: Theme.tinyFont.pointSize
          onAccepted: if (text.trim() !== "") plugin.wykonaj(text, false)
        }
        Button {
          text: "Wykonaj"
          enabled: polePolecenia.text.trim() !== ""
          onClicked: plugin.wykonaj(polePolecenia.text, false)
        }
      }

      // Kod bywa wieloliniowy — pole jednoliniowe zmusza do sklejania
      // wszystkiego srednikami, a wtedy blad trudno znalezc.
      ColumnLayout {
        Layout.fillWidth: true
        visible: plugin.zakladka === 1
        spacing: 6

        RowLayout {
          Layout.fillWidth: true
          spacing: 4
          Text {
            Layout.alignment: Qt.AlignTop
            Layout.topMargin: 8
            text: "QML>"
            color: Theme.mainColor
            font.family: "monospace"
            font.bold: true
            font.pointSize: Theme.tinyFont.pointSize
          }
        ScrollView {
          Layout.fillWidth: true
          Layout.preferredHeight: 90
          TextArea {
            id: poleKodu
            placeholderText: "var w = iface.activeLayer();\nw.renderer().symbol().setColor('#c0ca33');\nw.triggerRepaint();"
            wrapMode: TextEdit.Wrap
            font.family: "monospace"
            font.pointSize: Theme.tinyFont.pointSize
            // Bez tego tekst jest ciemny na ciemnym — TextArea nie
            // dziedziczy koloru z motywu tak jak TextField.
            color: Theme.mainTextColor
            placeholderTextColor: Theme.secondaryTextColor
            background: Rectangle {
              color: Theme.controlBackgroundColor
              radius: 4
            }
          }
        }
        }
        Button {
          Layout.fillWidth: true
          text: "Wykonaj kod"
          enabled: poleKodu.text.trim() !== ""
          onClicked: {
            plugin.wykonajQml(poleKodu.text);
            // Czyscimy po wykonaniu: kod zostaje w historii, a puste pole
            // jest wyrazniejsze niz stary tekst, ktory latwo wykonac drugi raz.
            poleKodu.text = "";
          }
        }
      }

      // --- historia: w terenie w rękawicach nie przepisuje się SQL-a
      ComboBox {
        Layout.fillWidth: true
        visible: plugin.historia.length > 0
        model: plugin.historia
        displayText: "historia (" + plugin.historia.length + ")"
        font.pointSize: Theme.tinyFont.pointSize
        onActivated: {
          if (plugin.zakladka === 0)
            polePolecenia.text = plugin.historia[currentIndex];
          else
            poleKodu.text = plugin.historia[currentIndex];
          displayText = "historia (" + plugin.historia.length + ")";
        }
      }
    }
  }

  // --------------------------------------------------------- USTAWIENIA
  Popup {
    id: oknoUstawien
    parent: mainWindow.contentItem
    width: Math.min(parent.width * 0.9, 420)
    x: (parent.width - width) / 2
    y: (parent.height - height) / 2
    modal: true
    padding: 14

    background: Rectangle {
      color: Theme.mainBackgroundColor
      radius: 6
      border.width: 1
      border.color: Theme.mainColor
    }

    ColumnLayout {
      anchors.fill: parent
      spacing: 10

      Text {
        text: "Konsola naprawcza"
        color: Theme.mainTextColor
        font.bold: true
      }
      Text {
        Layout.fillWidth: true
        text: "Pozwala wykonać dowolne polecenie na bazie projektu.\n\n" +
              "Kopia bazy robi się automatycznie przed każdą zmianą — " +
              "znajdziesz ją w katalogu kopie/ obok dane.gpkg.\n\n" +
              "Domyślnie wyłączona, bo w terenie łatwo tapnąć nie w to miejsce."
        wrapMode: Text.Wrap
        color: Theme.secondaryTextColor
        font.pointSize: Theme.tinyFont.pointSize
      }
      Switch {
        text: "Włączona"
        checked: ustawienia.wlaczona
        onCheckedChanged: ustawienia.wlaczona = checked
      }
      Button {
        Layout.fillWidth: true
        text: "Zamknij"
        onClicked: oknoUstawien.close()
      }
    }
  }
}
