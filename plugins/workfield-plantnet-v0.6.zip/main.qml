import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import Theme

/**
 * WorkField Pl@ntNet — rozpoznawanie gatunków roślin ze zdjęć.
 * Wersja 0.6:
 *  - do 5 zdjęć TEJ SAMEJ rośliny naraz (kwiat + liść + pokrój = wyższa pewność);
 *  - pasek miniatur: ✕ usuwa zdjęcie, przycisk pod miniaturą przełącza organ
 *    (liść → kwiat → owoc → kora → pokrój) — duże cele, pod rękawice;
 *  - „Wyczyść" przygotowuje okno pod następną roślinę.
 * Klucz API przechowywany lokalnie w ustawieniach (nigdy w kodzie!).
 */
Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property bool busy: false
  property var __resourceSource

  readonly property var organy: [
    { v: "leaf", l: "liść" },
    { v: "flower", l: "kwiat" },
    { v: "fruit", l: "owoc" },
    { v: "bark", l: "kora" },
    { v: "auto", l: "pokrój" }
  ]

  function organLabel(v) {
    for (var i = 0; i < organy.length; i++)
      if (organy[i].v === v)
        return organy[i].l
    return v
  }

  function nextOrgan(v) {
    for (var i = 0; i < organy.length; i++)
      if (organy[i].v === v)
        return organy[(i + 1) % organy.length].v
    return organy[0].v
  }

  Settings {
    id: pluginSettings
    category: "WorkFieldPlantNet"
    property string apiKey: ""
    property string organ: "leaf"
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(pluginButton)
  }

  QfToolButton {
    id: pluginButton
    iconSource: 'icon.svg'
    iconColor: Theme.mainColor
    bgcolor: Theme.darkGray
    round: true
    onClicked: dialog.open()
  }

  function projectHome() {
    if (typeof qgisProject === "undefined" || !qgisProject || !qgisProject.homePath)
      return ""
    var p = qgisProject.homePath
    return p.endsWith("/") ? p : p + "/"
  }

  function newPhotoName() {
    var d = new Date()
    function p2(n) { return (n < 10 ? "0" : "") + n }
    return "DCIM/plantnet_" + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate())
        + "_" + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds()) + ".JPG"
  }

  function acquire(fromCamera) {
    if (photosModel.count >= 5) {
      statusLabel.error(qsTr("Maksymalnie 5 zdjęć jednej rośliny."))
      return
    }
    var home = projectHome()
    if (home === "") {
      statusLabel.error(qsTr("Najpierw otwórz projekt — zdjęcia lądują w jego katalogu."))
      return
    }
    platformUtilities.createDir(qgisProject.homePath, "DCIM")
    var filepath = newPhotoName()
    statusLabel.step(fromCamera ? qsTr("Uruchamiam aparat…") : qsTr("Otwieram galerię…"))
    if (fromCamera) {
      plugin.__resourceSource = platformUtilities.getCameraPicture(home, filepath, "JPG", plugin)
    } else {
      plugin.__resourceSource = platformUtilities.getGalleryPicture(home, filepath, plugin)
    }
  }

  Connections {
    target: plugin.__resourceSource ? plugin.__resourceSource : null
    ignoreUnknownSignals: true
    function onResourceReceived(path) {
      if (!path || path === "") {
        statusLabel.error(qsTr("Nie otrzymano zdjęcia (anulowano?)."))
        return
      }
      var full = path.startsWith("/") ? path : plugin.projectHome() + path
      photosModel.append({ path: full, organ: pluginSettings.organ })
      statusLabel.step(qsTr("Zdjęć w komplecie: ") + photosModel.count + "/5")
    }
  }

  ListModel {
    id: photosModel
  }

  ListModel {
    id: resultsModel
  }

  TextEdit {
    id: clipboardHelper
    visible: false
    function copyText(t) {
      text = t
      selectAll()
      copy()
    }
  }

  Dialog {
    id: dialog
    parent: mainWindow.contentItem
    modal: true
    title: "Pl@ntNet — rozpoznanie gatunku"
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 40, 500)
    height: Math.min(mainWindow.height - 80, 680)
    standardButtons: Dialog.Close

    ColumnLayout {
      anchors.fill: parent
      spacing: 8

      TextField {
        id: apiKeyField
        Layout.fillWidth: true
        placeholderText: qsTr("Klucz API Pl@ntNet")
        text: pluginSettings.apiKey
        echoMode: TextInput.PasswordEchoOnEdit
        onEditingFinished: pluginSettings.apiKey = text.trim()
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Button {
          Layout.fillWidth: true
          enabled: photosModel.count < 5
          text: qsTr("📷 Zrób zdjęcie")
          onClicked: plugin.acquire(true)
        }

        Button {
          Layout.fillWidth: true
          enabled: photosModel.count < 5
          text: qsTr("🖼 Galeria")
          onClicked: plugin.acquire(false)
        }

        Button {
          visible: photosModel.count > 0
          text: qsTr("Wyczyść")
          onClicked: {
            photosModel.clear()
            resultsModel.clear()
            statusLabel.text = ""
          }
        }
      }

      ListView {
        id: photoStrip
        Layout.fillWidth: true
        Layout.preferredHeight: photosModel.count > 0 ? 116 : 0
        visible: photosModel.count > 0
        orientation: ListView.Horizontal
        spacing: 6
        clip: true
        model: photosModel

        delegate: Column {
          spacing: 3

          Rectangle {
            width: 78
            height: 78
            radius: 6
            color: "#263238"

            Image {
              anchors.fill: parent
              anchors.margins: 1
              source: "file://" + path
              fillMode: Image.PreserveAspectCrop
              asynchronous: true
              cache: false
              sourceSize.width: 300
            }

            Rectangle {
              width: 26
              height: 26
              radius: 13
              color: "#c62828"
              anchors.top: parent.top
              anchors.right: parent.right
              anchors.margins: 2

              Label {
                anchors.centerIn: parent
                text: "✕"
                color: "#ffffff"
                font.bold: true
              }

              MouseArea {
                anchors.fill: parent
                onClicked: photosModel.remove(index)
              }
            }
          }

          Button {
            width: 78
            height: 32
            text: plugin.organLabel(organ)
            onClicked: {
              var n = plugin.nextOrgan(organ)
              photosModel.setProperty(index, "organ", n)
              pluginSettings.organ = n
            }
          }
        }
      }

      Button {
        Layout.fillWidth: true
        enabled: !plugin.busy && photosModel.count > 0 && apiKeyField.text.trim() !== ""
        text: plugin.busy ? qsTr("Rozpoznawanie…")
                          : qsTr("Rozpoznaj gatunek (zdjęć: ") + photosModel.count + ")"
        onClicked: plugin.identify()
      }

      Label {
        id: statusLabel
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        font.bold: true
        property bool isError: false
        color: "#39ff14"
        visible: text !== ""
        function step(t) { isError = false; text = t }
        function error(t) { isError = true; text = "⚠ " + t; plugin.busy = false }
      }

      ListView {
        id: resultsView
        Layout.fillWidth: true
        Layout.fillHeight: true
        clip: true
        model: resultsModel
        spacing: 4

        delegate: Rectangle {
          width: resultsView.width
          height: rowCol.implicitHeight + 16
          radius: 6
          color: index === 0 ? "#e8f5e9" : "#f5f5f5"

          Column {
            id: rowCol
            anchors.verticalCenter: parent.verticalCenter
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.margins: 10
            spacing: 2

            Label {
              width: parent.width
              text: score + "%  —  " + scientificName
              font.bold: index === 0
              font.italic: true
              wrapMode: Text.WordWrap
              color: "#212121"
            }
            Label {
              width: parent.width
              visible: commonName !== ""
              text: commonName
              wrapMode: Text.WordWrap
              color: "#555555"
            }
          }

          MouseArea {
            anchors.fill: parent
            onClicked: {
              clipboardHelper.copyText(scientificName)
              mainWindow.displayToast(qsTr("Skopiowano: ") + scientificName)
            }
          }
        }
      }

      Label {
        Layout.fillWidth: true
        text: qsTr("Do 5 zdjęć tej samej rośliny — przycisk pod miniaturą przełącza, co widać. Dotknij wyniku, aby skopiować nazwę. Dane: Pl@ntNet (my.plantnet.org).")
        wrapMode: Text.WordWrap
        font.pointSize: 9
        color: "#9e9e9e"
      }
    }
  }

  // ---------------------------------------------------------- logika

  function str2bytes(s) {
    var u = unescape(encodeURIComponent(s))
    var arr = new Uint8Array(u.length)
    for (var i = 0; i < u.length; i++)
      arr[i] = u.charCodeAt(i)
    return arr
  }

  function identify() {
    plugin.busy = true
    resultsModel.clear()
    var stage = "start"
    try {
      var boundary = "----WorkFieldPlantNet" + Date.now()
      var parts = []
      var totalKB = 0

      for (var i = 0; i < photosModel.count; i++) {
        var ph = photosModel.get(i)
        stage = "czytanie " + (i + 1) + "/" + photosModel.count + ": " + ph.path
        statusLabel.step(qsTr("Czytam zdjęcie ") + (i + 1) + "/" + photosModel.count + "…")
        var content = FileUtils.readFileContent(ph.path)
        var blen = (content && content.byteLength !== undefined) ? content.byteLength : -1
        if (blen <= 0) {
          statusLabel.error(qsTr("Zdjęcie ") + (i + 1) + qsTr(" nieczytelne (0 bajtów): ") + ph.path)
          return
        }
        totalKB += Math.round(blen / 1024)
        var fname = FileUtils.fileName(ph.path)
        parts.push(str2bytes("--" + boundary + "\r\n"
            + 'Content-Disposition: form-data; name="organs"\r\n\r\n'
            + ph.organ + "\r\n"
            + "--" + boundary + "\r\n"
            + 'Content-Disposition: form-data; name="images"; filename="' + fname + '"\r\n'
            + "Content-Type: image/jpeg\r\n\r\n"))
        parts.push(new Uint8Array(content))
        parts.push(str2bytes("\r\n"))
      }
      parts.push(str2bytes("--" + boundary + "--\r\n"))

      stage = "sklejanie treści zapytania"
      var total = 0
      for (var j = 0; j < parts.length; j++)
        total += parts[j].length
      var body = new Uint8Array(total)
      var off = 0
      for (var k = 0; k < parts.length; k++) {
        body.set(parts[k], off)
        off += parts[k].length
      }

      statusLabel.step(qsTr("Wysyłam ") + photosModel.count + qsTr(" zdj. (")
                       + totalKB + qsTr(" KB) do Pl@ntNet…"))
      plugin.sendToPlantNet(body, boundary)
    } catch (e) {
      statusLabel.error(qsTr("Błąd: ") + e + qsTr(" [etap: ") + stage + "]")
    }
  }

  function sendToPlantNet(body, boundary) {
    var url = "https://my-api.plantnet.org/v2/identify/all"
        + "?api-key=" + encodeURIComponent(pluginSettings.apiKey.trim())
        + "&lang=pl&nb-results=6"

    try {
      var xhr = new XMLHttpRequest()
      xhr.open("POST", url)
      xhr.timeout = 60000
      xhr.ontimeout = function () {
        statusLabel.error(qsTr("Serwer nie odpowiedział w 60 s. Sprawdź zasięg."))
      }
      xhr.setRequestHeader("Content-Type", "multipart/form-data; boundary=" + boundary)
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== XMLHttpRequest.DONE)
          return
        plugin.busy = false
        if (xhr.status === 200) {
          statusLabel.step("")
          plugin.showResults(xhr.responseText)
        } else if (xhr.status === 401) {
          statusLabel.error(qsTr("Błędny klucz API (401). Sprawdź klucz na my.plantnet.org."))
        } else if (xhr.status === 404) {
          statusLabel.error(qsTr("Pl@ntNet nie rozpoznał żadnego gatunku na tych zdjęciach (404)."))
        } else if (xhr.status === 413) {
          statusLabel.error(qsTr("Zdjęcia łącznie za duże (413) — usuń któreś i spróbuj ponownie."))
        } else if (xhr.status === 429) {
          statusLabel.error(qsTr("Wyczerpany dzienny limit zapytań (429)."))
        } else if (xhr.status === 0) {
          statusLabel.error(qsTr("Brak odpowiedzi (status 0) — problem z siecią lub wysyłką."))
        } else {
          statusLabel.error(qsTr("Błąd serwera: ") + xhr.status + " "
                            + xhr.responseText.substring(0, 120))
        }
      }
      xhr.send(body.buffer)
    } catch (e) {
      statusLabel.error(qsTr("Błąd przy wysyłce: ") + e)
    }
  }

  function showResults(responseText) {
    try {
      var json = JSON.parse(responseText)
      var results = json.results || []
      if (results.length === 0) {
        statusLabel.error(qsTr("Brak wyników."))
        return
      }
      for (var i = 0; i < results.length; i++) {
        var r = results[i]
        var common = ""
        if (r.species.commonNames && r.species.commonNames.length > 0)
          common = r.species.commonNames.join(", ")
        resultsModel.append({
          score: Math.round(r.score * 100),
          scientificName: r.species.scientificNameWithoutAuthor,
          commonName: common
        })
      }
    } catch (e) {
      statusLabel.error(qsTr("Nie udało się odczytać odpowiedzi serwera: ") + e)
    }
  }
}
