import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import Theme

/**
 * WorkField Zrobione — odhaczanie poligonów tapnięciem.
 *
 *   tapnięcie w ikonę    → włącza/wyłącza tryb (ikona świeci na zielono),
 *   tapnięcie w poligon  → przestawia stan NIE → CZĘŚCIOWO → KOMPLET → NIE,
 *   przytrzymanie ikony  → ustawienia (warstwa, pole, zakładanie pola).
 *
 * Po co: przy kilkudziesięciu płatach trzeba wiedzieć, które są obrobione.
 * Otwieranie formularza po to, żeby przestawić jedno pole, kosztuje w terenie
 * więcej niż sama praca. Tu jest jedno tapnięcie i haptyka.
 *
 * TRZY STANY (decyzja Piotra 19.08): NIE / CZĘŚCIOWO / KOMPLET. Pole jest
 * TEKSTOWE, nie logiczne — trzeci stan dokładany później do pola bool byłby
 * zmianą schematu, czyli major wg docs/WERSJONOWANIE.md.
 *
 * PUSTE POLE TO NIE STAN. Obiekt bez wartości czyta się jak NIE, ale przy
 * zakładaniu pola wtyczka WYPEŁNIA wszystkie istniejące obiekty wartością
 * NIE. Powód z doświadczenia Piotra: świeżo dodane pole ma NULL, reguła
 * stylizacji „= 0" NULL-a nie łapie, a obiekt bez pasującej reguły NIE JEST
 * RYSOWANY. Połowa poligonów zniknęła z mapy i wyglądało to jak utrata
 * danych. Poligon niewidoczny wygląda jak nieistniejący — w terenie znaczy
 * „ten fragment nie jest zrobiony".
 *
 * Diagnostyka: prefiks "ZROB:" w obu kanałach (grep "ZROB:").
 */
Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property var pointHandler: iface.findItemByObjectName("pointHandler")
  // Tapnięcia w te elementy nie są nasze — qgismobileapp.qml woła
  // pointHandler.clicked() PRZED sprawdzeniem pasków, więc bez tego przy
  // włączonym trybie nie da się dotknąć własnej ikony, żeby go wyłączyć.
  property var pasekWtyczek: iface.findItemByObjectName("pluginsToolbar")
  property var wyszukiwarka: iface.findItemByObjectName("locatorItem")

  readonly property string nazwaObslugi: "workfield_zrobione"
  readonly property int priorytetWysoki: 100

  readonly property var stany: ["NIE", "CZĘŚCIOWO", "KOMPLET"]
  readonly property var kolorStanu: ({
      "NIE": "#ef5350",
      "CZĘŚCIOWO": "#ffa726",
      "KOMPLET": "#66bb6a"
    })

  property bool uzbrojony: false
  property bool zajety: false

  Settings {
    id: ustawienia
    category: "WorkFieldZrobione"
    property string warstwa: ""
    property string pole: "ZROBIONE"
    //! Promień trafienia w pikselach ekranu — palec w rękawicy nie celuje.
    property int promienPx: 12
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(przyciskWtyczki);
    log("wtyczka wczytana, obsługa tapnięć: " + (pointHandler ? "znaleziona" : "BRAK"));
  }

  Component.onDestruction: {
    if (uzbrojony)
      rozbroj();
  }

  QfToolButton {
    id: przyciskWtyczki
    iconSource: 'icon.svg'
    iconColor: plugin.uzbrojony ? "#39ff14" : Theme.mainColor
    bgcolor: plugin.uzbrojony ? "#1b5e20" : Theme.darkGray
    round: true
    onClicked: {
      if (plugin.uzbrojony)
        plugin.rozbroj();
      else
        plugin.uzbroj();
    }
    onPressAndHold: okno.open()
  }

  // ------------------------------------------------------------ tryb tapnięć

  function uzbroj() {
    if (!pointHandler) {
      toast(qsTr("Nie mam dostępu do tapnięć w mapę."));
      return;
    }

    var w = warstwaDocelowa();
    if (!w) {
      toast(qsTr("Nie widzę warstwy poligonowej — wskaż ją w ustawieniach (przytrzymaj ikonę)."));
      okno.open();
      return;
    }

    if (indeksPola(w) < 0) {
      // Nie zakładamy pola po cichu: to zmiana struktury danych.
      okno.open();
      toast(qsTr("Warstwa %1 nie ma pola %2 — załóż je w ustawieniach.").arg(w.name).arg(ustawienia.pole));
      return;
    }

    var ok = pointHandler.registerHandler(nazwaObslugi, function (point, type, interactionType) {
      if (interactionType !== "clicked")
        return false;
      if (plugin.wInterfejsie(point))
        return false;
      if (plugin.zajety)
        return true;
      plugin.przestawDlaPunktuEkranu(point);
      return true;
    }, priorytetWysoki);

    if (!ok) {
      pointHandler.deregisterHandler(nazwaObslugi);
      toast(qsTr("Tryb był już włączony — wyłączam. Dotknij ikonę ponownie."));
      return;
    }

    uzbrojony = true;
    log("tryb WŁĄCZONY, warstwa: " + w.name + ", pole: " + ustawienia.pole);
    toast(qsTr("Zrobione: dotknij poligonu, aby przestawić stan."));
  }

  function rozbroj() {
    if (pointHandler)
      pointHandler.deregisterHandler(nazwaObslugi);
    uzbrojony = false;
    log("tryb wyłączony");
  }

  function wInterfejsie(point) {
    if (!pointHandler)
      return false;
    if (pasekWtyczek && pointHandler.pointInItem(point, pasekWtyczek))
      return true;
    if (wyszukiwarka && pointHandler.pointInItem(point, wyszukiwarka))
      return true;
    return false;
  }

  // --------------------------------------------------------------- warstwa

  //! Warstwy poligonowe projektu — do wyboru w ustawieniach.
  //
  // PUŁAPKA (v0.1 miała tu błąd): `qgisProject.mapLayers()` NIE jest wołalne
  // z QML — QgsProject wystawia tylko mapLayer(id) i mapLayersByName().
  // Wyliczenie idzie przez pomocnik forka: ProjectUtils.mapLayers(projekt).
  // Tak samo `geometryType` to METODA (Q_INVOKABLE), nie właściwość —
  // `w.geometryType === 2` jest zawsze fałszem, bo porównuje funkcję z liczbą.
  function warstwyPoligonowe() {
    var lista = [];
    if (typeof qgisProject === "undefined" || !qgisProject)
      return lista;
    var mapa = ProjectUtils.mapLayers(qgisProject);
    for (var klucz in mapa) {
      var w = mapa[klucz];
      if (!w || !w.isValid)
        continue;
      if (!poligonowa(w))
        continue;
      lista.push(w.name);
    }
    lista.sort();
    return lista;
  }

  //! 2 == Qgis::GeometryType::Polygon (enum niedostępny z wtyczki)
  function poligonowa(warstwa) {
    if (!warstwa || typeof warstwa.geometryType !== "function")
      return false;
    return warstwa.geometryType() === 2;
  }

  /**
   * Warstwa, na której człowiek właśnie pracuje.
   *
   * `QgsVectorLayer::isEditable()` NIE jest wystawione do QML, więc „warstwa
   * w trybie edycji" jest z wtyczki nierozpoznawalna. Najbliższym sensownym
   * odpowiednikiem jest warstwa AKTYWNA — ta podświetlona w panelu Warstwy,
   * do której pisze pasek szybkiego przechwytu. Legenda ma objectName
   * "legend" i właściwość activeLayer, więc da się po nią sięgnąć.
   */
  function warstwaAktywna() {
    var legenda = iface.findItemByObjectName("legend");
    if (!legenda)
      return null;
    var w = legenda.activeLayer;
    return (w && w.isValid) ? w : null;
  }

  function warstwaDocelowa() {
    if (typeof qgisProject === "undefined" || !qgisProject)
      return null;

    if (ustawienia.warstwa !== "") {
      var w = LayerUtils.vectorLayerByName(qgisProject, ustawienia.warstwa);
      if (w)
        return w;
    }

    // Bez wskazania — po kolei, od najbardziej prawdopodobnej:
    // 1. warstwa AKTYWNA, jeśli poligonowa (decyzja Piotra 19.08: „ta,
    //    na której pracuję"). Toast przy każdym tapnięciu mówi, dokąd
    //    poszedł zapis, więc zmiana aktywnej nie jest cicha.
    var aktywna = warstwaAktywna();
    if (aktywna && poligonowa(aktywna))
      return aktywna;

    var poligonowe = warstwyPoligonowe();
    if (poligonowe.length === 0)
      return null;

    // 2. pierwsza poligonowa, która MA pole — przygotowana warstwa jest
    //    lepszym domysłem niż pierwsza alfabetycznie.
    for (var i = 0; i < poligonowe.length; ++i) {
      var kandydat = LayerUtils.vectorLayerByName(qgisProject, poligonowe[i]);
      if (kandydat && indeksPola(kandydat) >= 0)
        return kandydat;
    }

    // 3. pierwsza poligonowa
    return LayerUtils.vectorLayerByName(qgisProject, poligonowe[0]);
  }

  function indeksPola(warstwa) {
    if (!warstwa)
      return -1;
    var pola = LayerUtils.layerFields(warstwa);
    for (var i = 0; i < pola.length; ++i) {
      if (pola[i].name === ustawienia.pole)
        return i;
    }
    return -1;
  }

  /**
   * Zakłada pole i WYPEŁNIA wszystkie istniejące obiekty wartością NIE.
   * Drugi krok jest tu ważniejszy od pierwszego — patrz komentarz na górze.
   */
  function zalozPole() {
    var w = warstwaDocelowa();
    if (!w) {
      toast(qsTr("Nie ma warstwy, na której miałbym założyć pole."));
      return;
    }
    if (indeksPola(w) >= 0) {
      toast(qsTr("Pole %1 już jest.").arg(ustawienia.pole));
      return;
    }

    var blad = LayerUtils.addLayerField(w, ustawienia.pole, "text");
    if (blad !== "") {
      log("addLayerField: " + blad);
      toast(qsTr("Nie udało się założyć pola: %1").arg(blad));
      return;
    }

    var idx = indeksPola(w);
    if (idx < 0) {
      toast(qsTr("Pole założone, ale go nie widzę — otwórz projekt ponownie."));
      return;
    }

    // Wypełnienie: bez tego NULL-e wypadają z reguł stylizacji i obiekty
    // przestają być rysowane.
    if (!w.startEditing()) {
      toast(qsTr("Pole założone, ale nie mogę wpisać wartości początkowych."));
      return;
    }

    var ile = 0;
    var it = LayerUtils.createFeatureIterator(w);
    while (it.hasNext()) {
      var f = it.next();
      if (w.changeAttributeValue(f.id, idx, stany[0]))
        ile += 1;
    }
    it.close();

    if (!w.commitChanges()) {
      w.rollBack();
      toast(qsTr("Nie udało się zapisać wartości początkowych."));
      return;
    }

    log("pole " + ustawienia.pole + " założone, wypełnione obiektów: " + ile);
    toast(qsTr("Pole %1 założone; %2 obiektom wpisano NIE.").arg(ustawienia.pole).arg(ile));
  }

  // ------------------------------------------------------------ przestawianie

  function przestawDlaPunktuEkranu(point) {
    var ms = null;
    try {
      ms = iface.mapCanvas().mapSettings;
    } catch (e) {
    }
    if (!ms) {
      toast(qsTr("Nie mam dostępu do mapy."));
      return;
    }

    var w = warstwaDocelowa();
    var idx = indeksPola(w);
    if (!w || idx < 0) {
      toast(qsTr("Brak warstwy albo pola %1.").arg(ustawienia.pole));
      return;
    }

    // Promień trafienia liczony w jednostkach mapy z promienia ekranowego —
    // przy każdym powiększeniu znaczy to samo dla palca.
    var srodek = ms.screenToCoordinate(point);
    var obok = ms.screenToCoordinate(Qt.point(point.x + ustawienia.promienPx, point.y));
    var promien = Math.abs(obok.x - srodek.x);

    var wWarstwie = GeometryUtils.reprojectPoint(srodek, ms.destinationCrs, w.crs);
    var promienWarstwy = promien;
    if (String(ms.destinationCrs.authid) !== String(w.crs.authid)) {
      var obokWarstwy = GeometryUtils.reprojectPoint(obok, ms.destinationCrs, w.crs);
      promienWarstwy = Math.abs(obokWarstwy.x - wWarstwie.x);
    }

    var p1 = GeometryUtils.point(wWarstwie.x - promienWarstwy, wWarstwie.y - promienWarstwy);
    var p2 = GeometryUtils.point(wWarstwie.x + promienWarstwy, wWarstwie.y + promienWarstwy);
    var prostokat = GeometryUtils.createRectangleFromPoints(p1, p2);

    var punkt = GeometryUtils.createGeometryFromWkt("POINT(" + wWarstwie.x + " " + wWarstwie.y + ")");

    // Prostokąt to zgrubny przesiew po indeksie; o trafieniu rozstrzyga
    // dopiero punkt-w-poligonie, inaczej tapnięcie obok obiektu też liczy.
    var trafiony = null;
    var trafionyWProstokacie = null;
    var it = LayerUtils.createFeatureIteratorFromRectangle(w, prostokat);
    while (it.hasNext()) {
      var f = it.next();
      if (trafionyWProstokacie === null)
        trafionyWProstokacie = f;
      if (GeometryUtils.geometryWithin(punkt, f.geometry)) {
        trafiony = f;
        break;
      }
    }
    it.close();

    // Tapnięcie w granicę albo tuż obok: bierzemy obiekt z przesiewu.
    if (trafiony === null)
      trafiony = trafionyWProstokacie;

    if (trafiony === null) {
      toast(qsTr("Nic tu nie ma."));
      return;
    }

    var teraz = String(trafiony.attribute(ustawienia.pole));
    var nastepny = stanPo(teraz);

    zajety = true;
    // `isEditable()` i `editBuffer` nie są wystawione do QML, więc nie da się
    // sprawdzić, czy warstwa jest już w edycji. startEditing() na otwartej
    // sesji zwraca false, ale jej nie psuje; commitChanges() zapisze wtedy
    // także cudze zmiany. Do obserwacji w terenie.
    w.startEditing();

    w.changeAttributeValue(trafiony.id, idx, nastepny);

    if (!w.commitChanges()) {
      w.rollBack();
      zajety = false;
      toast(qsTr("Zapis się nie powiódł."));
      return;
    }

    // Stan sprawdzamy PO fakcie: QgsFeature jest w QML typem wartościowym,
    // a wynik changeAttributeValue bywa bezużyteczny (notatka z 16.08).
    var poZapisie = String(w.getFeature(trafiony.id).attribute(ustawienia.pole));
    zajety = false;

    if (poZapisie !== nastepny) {
      log("ROZJAZD: chciałem " + nastepny + ", w danych jest " + poZapisie);
      toast(qsTr("Nie zapisało się — w danych jest nadal %1.").arg(poZapisie));
      return;
    }

    w.triggerRepaint();
    if (typeof platformUtilities !== "undefined" && platformUtilities.vibrate)
      platformUtilities.vibrate(nastepny === "KOMPLET" ? 60 : 25);

    log("fid " + trafiony.id + " w " + w.name + ": " + teraz + " → " + poZapisie);
    toast(poZapisie + "  ·  " + w.name);
  }

  function stanPo(obecny) {
    for (var i = 0; i < stany.length; ++i) {
      if (stany[i] === obecny)
        return stany[(i + 1) % stany.length];
    }
    // puste, NULL, albo cokolwiek nieznanego czyta się jak NIE
    return stany[1];
  }

  // --------------------------------------------------------------- pomocnicze

  function toast(t) {
    if (mainWindow && mainWindow.displayToast)
      mainWindow.displayToast(t);
    log("toast: " + t);
  }

  // Dwa kanały świadomie: console.log wychodzi na stdout (na desktopie
  // `grep "ZROB:"`), a logMessage ląduje w logu aplikacji — jedynym, który
  // da się odczytać na telefonie.
  function log(t) {
    console.log("ZROB: " + t);
    iface.logMessage("ZROB: " + t);
  }

  // ---------------------------------------------------------------- ustawienia

  Dialog {
    id: okno
    parent: mainWindow.contentItem
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 32, 420)
    modal: true
    title: qsTr("Zrobione — ustawienia")
    standardButtons: Dialog.Close

    onAboutToShow: {
      wyborWarstwy.model = plugin.warstwyPoligonowe();
      wyborWarstwy.currentIndex = wyborWarstwy.model.indexOf(ustawienia.warstwa);
    }

    ColumnLayout {
      width: parent.width
      spacing: 10

      Label {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        color: Theme.mainTextColor
        text: qsTr("Tapnięcie w poligon przestawia stan: NIE → CZĘŚCIOWO → KOMPLET → NIE.")
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Label {
          text: qsTr("Warstwa")
          color: Theme.mainTextColor
        }

        ComboBox {
          id: wyborWarstwy
          Layout.fillWidth: true
          displayText: currentIndex < 0 ? qsTr("pierwsza poligonowa") : currentText
          onActivated: {
            ustawienia.warstwa = currentText;
            plugin.log("warstwa docelowa: " + currentText);
          }
        }
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Label {
          text: qsTr("Pole")
          color: Theme.mainTextColor
        }

        TextField {
          Layout.fillWidth: true
          text: ustawienia.pole
          onEditingFinished: ustawienia.pole = text.trim() === "" ? "ZROBIONE" : text.trim()
        }
      }

      Label {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        font: Theme.tipFont
        color: Theme.secondaryTextColor
        text: {
          const w = plugin.warstwaDocelowa();
          if (!w)
            return qsTr("Nie widzę warstwy poligonowej w tym projekcie.");
          return plugin.indeksPola(w) >= 0
            ? qsTr("Warstwa %1 ma pole %2 — można pracować.").arg(w.name).arg(ustawienia.pole)
            : qsTr("Warstwa %1 NIE ma pola %2.").arg(w.name).arg(ustawienia.pole);
        }
      }

      Button {
        Layout.fillWidth: true
        text: qsTr("Załóż pole i wpisz wszystkim NIE")
        onClicked: plugin.zalozPole()
      }

      Label {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        font: Theme.tipFont
        color: Theme.secondaryTextColor
        text: qsTr("Wartości początkowe są wpisywane celowo: obiekt z pustym polem wypada z reguł stylizacji i przestaje być rysowany na mapie.")
      }
    }
  }
}
