import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import Theme

/**
 * WorkField Próbka — odczyt wartości z warstw pod palcem.
 *
 * Wersja 0.1: RASTRY (NMT, NMPT, CHM, nachylenie, TWI, ortofoto…).
 *   tapnięcie w ikonę   → uzbraja narzędzie (ikona świeci),
 *   przytrzymanie ikony → ustawienia: warstwa, tryb, statystyka,
 *   praca na mapie      → zależnie od trybu:
 *     • Punkt — tapnięcie, wartość piksela,
 *     • Koło  — przyciśnięcie w środku, przeciągnięcie ustawia promień,
 *               puszczenie liczy średnią (albo medianę) z koła,
 *     • Linia — kolejne tapnięcia stawiają wierzchołki, „Policz” daje
 *               średnią wzdłuż łamanej.
 *   Wynik ląduje w schowku (samą liczbą, z kropką) i w pasku u dołu.
 *
 * Silnik jest w aplikacji i to on liczy: iface.sampleRasterAt (punkt),
 * iface.sampleRasterBuffered (koło — pętla po pikselach w C++). Wtyczka
 * dokłada tylko obsługę mapy, rysowanie i schowek.
 *
 * Czego jeszcze NIE ma (0.1): warstw wektorowych — „średnia pola z obiektów
 * pod punktem / przeciętych linią / w kole”. Na to nie ma czasownika
 * w silniku; QML nie dostanie iteratora obiektów z filtrem przestrzennym.
 * Interfejs jest już pod to przygotowany (wybór warstwy nie zakłada rastra),
 * dojdzie pole i statystyka, gdy silnik dostanie jeden czasownik.
 *
 * Diagnostyka: log z prefiksem "PROBKA:" (grep "PROBKA:").
 */
Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property var pointHandler: iface.findItemByObjectName("pointHandler")
  property var pasekWtyczek: iface.findItemByObjectName("pluginsToolbar")
  property var kontenerMapy: iface.findItemByObjectName("mapCanvasContainer")

  //! Uzbrojone = nakładka łapie zdarzenia mapy.
  property bool uzbrojony: false

  // ── stan bieżącego pomiaru ─────────────────────────────────────────
  //! Środek koła we współrzędnych MAPY (układ projektu).
  property real srodekX: 0
  property real srodekY: 0
  property real promien: 0
  property bool rysujKolo: false
  //! Wierzchołki łamanej, [{x, y}] we współrzędnych mapy.
  property var wierzcholki: []

  // ── wynik ──────────────────────────────────────────────────────────
  property string wynikTekst: ""
  property string wynikOpis: ""

  readonly property string wersja: "0.1"

  Settings {
    id: ustawienia
    category: "WorkFieldProbka"
    //! Nazwa warstwy; pusta = pierwszy raster w projekcie.
    property string warstwa: ""
    //! "punkt" | "kolo" | "linia"
    property string tryb: "punkt"
    //! "mean" | "median" — dotyczy koła i linii.
    property string statystyka: "mean"
    property bool doSchowka: true
    property int miejsca: 2
  }

  //! Tryb i statystyka na wierzchu — czytelne z zewnątrz i z piaskownicy.
  property alias tryb: ustawienia.tryb
  property alias statystyka: ustawienia.statystyka

  // ══════════════════════════════════════════════════════ warstwy
  // Warstwy bierzemy z MapLayerModel, a nie z qgisProject: QgsProject::mapLayers()
  // nie jest Q_INVOKABLE i z QML go nie ma. Model daje role Name i LayerPointer.
  MapLayerModel {
    id: modelWarstw
    project: qgisProject
  }

  //! Wszystkie rastry projektu jako [{warstwa, nazwa}].
  function rastry() {
    var lista = [];
    try {
      var n = modelWarstw.rowCount();
      for (var i = 0; i < n; i++) {
        var wiersz = modelWarstw.get(i);
        var w = wiersz.LayerPointer;
        if (!w)
          continue;
        // layerKind: "raster" to pobrany plik, "podklad" to usługa sieciowa
        // (WMS, XYZ) — z tej próbki się nie da, provider nie umie sample().
        if (iface.layerKind(w) === "raster")
          lista.push({
            "warstwa": w,
            "nazwa": wiersz.Name
          });
      }
    } catch (e) {
      log("nie umiem przejrzeć warstw: " + e);
    }
    return lista;
  }

  //! Wybrana warstwa albo null.
  function warstwaBiezaca() {
    var lista = rastry();
    if (lista.length === 0)
      return null;
    for (var i = 0; i < lista.length; i++) {
      if (lista[i].nazwa === ustawienia.warstwa)
        return lista[i].warstwa;
    }
    return lista[0].warstwa;
  }

  /**
   * Czy nazwa warstwy wskazuje w projekcie dokładnie jeden raster?
   *
   * sampleRasterBuffered() szuka warstwy PO FRAGMENCIE NAZWY i bierze
   * pierwszą trafioną. Przy „Bruzdowa NMT” i „Bruzdowa NMT (2019)” trafiłaby
   * nie w tę, co trzeba — wtedy liczymy siatkę sami, wolniej, ale pewnie.
   */
  function nazwaJednoznaczna(nazwa) {
    var lista = rastry();
    var ile = 0;
    for (var i = 0; i < lista.length; i++)
      if (lista[i].nazwa.toLowerCase().indexOf(nazwa.toLowerCase()) >= 0)
        ile++;
    return ile === 1;
  }

  //! Układ projektu w metrach? Promień i krok liczymy w jednostkach mapy.
  function ukladMetryczny() {
    var authid = "";
    try {
      authid = iface.projectCrsAuthid();
    } catch (e) {
    }
    // EPSG:4326 i pokrewne stopniowe — promień „5” znaczyłby 5 stopni.
    return authid !== "EPSG:4326" && authid !== "EPSG:4258" && authid !== "OGC:CRS84";
  }

  // ══════════════════════════════════════════════════════ próbkowanie
  function probkaPunkt(x, y) {
    var w = warstwaBiezaca();
    if (!w) {
      toast(qsTr("Nie ma w projekcie żadnego rastra do próbkowania."));
      return;
    }
    var v = iface.sampleRasterAt(w, x, y);
    if (isNaN(v)) {
      pokazWynik("", qsTr("%1 — poza zasięgiem danych").arg(w.name));
      return;
    }
    pokazWynik(sformatuj(v), qsTr("%1 · punkt").arg(w.name));
    log("punkt x=" + x.toFixed(2) + " y=" + y.toFixed(2) + " -> " + v);
  }

  function probkaKolo(cx, cy, r) {
    var w = warstwaBiezaca();
    if (!w) {
      toast(qsTr("Nie ma w projekcie żadnego rastra do próbkowania."));
      return;
    }
    if (r <= 0) {
      toast(qsTr("Promień zerowy — przeciągnij palcem od środka."));
      return;
    }
    var stat = ustawienia.statystyka;
    var v = NaN;
    var ile = -1;
    if (nazwaJednoznaczna(w.name)) {
      // Pętla po pikselach w C++, z prawdziwym rozmiarem piksela rastra.
      v = iface.sampleRasterBuffered(w.name, cx, cy, r, stat);
    } else {
      var s = siatkaWKole(w, cx, cy, r, stat);
      v = s.wartosc;
      ile = s.ile;
    }
    if (isNaN(v)) {
      pokazWynik("", qsTr("%1 — brak danych w tym kole").arg(w.name));
      return;
    }
    pokazWynik(sformatuj(v), qsTr("%1 · %2 z koła r = %3 m").arg(w.name).arg(nazwaStatystyki(stat)).arg(r.toFixed(1)));
    log("kolo x=" + cx.toFixed(2) + " y=" + cy.toFixed(2) + " r=" + r.toFixed(2) + " " + stat + " -> " + v + (ile >= 0 ? " (probek " + ile + ")" : " (silnik)"));
  }

  /**
   * Zapasowa siatka w kole, liczona z QML.
   *
   * Krok bierzemy z promienia, nie z rastra — z QML nie widać rozmiaru
   * piksela. 41×41 to najwyżej ~1300 wywołań; więcej nie ma sensu, bo
   * każde jest przejściem przez granicę QML→C++.
   */
  function siatkaWKole(w, cx, cy, r, stat) {
    var krok = Math.max(r / 20.0, 0.05);
    var wartosci = [];
    for (var i = -20; i <= 20; i++) {
      for (var j = -20; j <= 20; j++) {
        var dx = i * krok;
        var dy = j * krok;
        if (Math.sqrt(dx * dx + dy * dy) > r)
          continue;
        var v = iface.sampleRasterAt(w, cx + dx, cy + dy);
        if (!isNaN(v))
          wartosci.push(v);
      }
    }
    return {
      "wartosc": zbierz(wartosci, stat),
      "ile": wartosci.length
    };
  }

  function probkaLinia() {
    var w = warstwaBiezaca();
    if (!w) {
      toast(qsTr("Nie ma w projekcie żadnego rastra do próbkowania."));
      return;
    }
    if (wierzcholki.length < 2) {
      toast(qsTr("Linia potrzebuje co najmniej dwóch punktów."));
      return;
    }
    var dlugosc = dlugoscLamanej();
    if (dlugosc <= 0) {
      toast(qsTr("Linia ma zerową długość."));
      return;
    }
    // Najwyżej 200 próbek na całą łamaną — tyle wystarcza na profil,
    // a nie zatyka interfejsu przy linii przez pół arkusza.
    var krok = Math.max(dlugosc / 200.0, 0.05);
    var wartosci = [];
    for (var i = 1; i < wierzcholki.length; i++) {
      var a = wierzcholki[i - 1];
      var b = wierzcholki[i];
      var dx = b.x - a.x;
      var dy = b.y - a.y;
      var d = Math.sqrt(dx * dx + dy * dy);
      var n = Math.max(1, Math.round(d / krok));
      for (var k = 0; k <= n; k++) {
        // Wierzchołek wspólny dwóch odcinków liczony raz.
        if (k === 0 && i > 1)
          continue;
        var t = k / n;
        var v = iface.sampleRasterAt(w, a.x + dx * t, a.y + dy * t);
        if (!isNaN(v))
          wartosci.push(v);
      }
    }
    var stat = ustawienia.statystyka;
    var wynik = zbierz(wartosci, stat);
    if (isNaN(wynik)) {
      pokazWynik("", qsTr("%1 — brak danych wzdłuż linii").arg(w.name));
      return;
    }
    pokazWynik(sformatuj(wynik), qsTr("%1 · %2 z linii %3 m").arg(w.name).arg(nazwaStatystyki(stat)).arg(dlugosc.toFixed(1)));
    log("linia dlugosc=" + dlugosc.toFixed(2) + " probek=" + wartosci.length + " " + stat + " -> " + wynik);
  }

  function dlugoscLamanej() {
    var suma = 0;
    for (var i = 1; i < wierzcholki.length; i++) {
      var dx = wierzcholki[i].x - wierzcholki[i - 1].x;
      var dy = wierzcholki[i].y - wierzcholki[i - 1].y;
      suma += Math.sqrt(dx * dx + dy * dy);
    }
    return suma;
  }

  function zbierz(wartosci, stat) {
    if (!wartosci || wartosci.length === 0)
      return NaN;
    if (stat === "median") {
      var s = wartosci.slice().sort(function (a, b) {
        return a - b;
      });
      var m = Math.floor(s.length / 2);
      return s.length % 2 === 0 ? (s[m - 1] + s[m]) / 2 : s[m];
    }
    var suma = 0;
    for (var i = 0; i < wartosci.length; i++)
      suma += wartosci[i];
    return suma / wartosci.length;
  }

  function nazwaStatystyki(s) {
    return s === "median" ? qsTr("mediana") : qsTr("średnia");
  }

  //! Liczba z KROPKĄ — tak, żeby wkleić ją wprost w pole liczbowe.
  function sformatuj(v) {
    return v.toFixed(ustawienia.miejsca);
  }

  function pokazWynik(tekst, opis) {
    wynikTekst = tekst;
    wynikOpis = opis;
    if (tekst === "") {
      // Brak danych też jest odpowiedzią — inaczej wygląda, jakby nie zadziałało.
      toast(opis);
      return;
    }
    if (ustawienia.doSchowka && doSchowka(tekst))
      toast(qsTr("%1 — skopiowane").arg(tekst));
    else
      toast(tekst);
  }

  function doSchowka(tekst) {
    try {
      platformUtilities.copyTextToClipboard(tekst);
      return true;
    } catch (e) {
      log("schowek niedostępny: " + e);
      return false;
    }
  }

  // ══════════════════════════════════════════════════════ pasek wtyczek
  Component.onCompleted: {
    iface.addItemToPluginsToolbar(przyciskWtyczki);
    if (kontenerMapy) {
      nakladka.parent = kontenerMapy;
      nakladka.anchors.fill = kontenerMapy;
    }
    log("wtyczka " + wersja + " wczytana; kontener mapy: " + (kontenerMapy ? "jest" : "BRAK"));
  }

  Component.onDestruction: rozbroj()

  QfToolButton {
    id: przyciskWtyczki
    iconSource: 'icon.svg'
    iconColor: plugin.uzbrojony ? "#39ff14" : Theme.mainColor
    bgcolor: plugin.uzbrojony ? "#1b5e20" : Theme.darkGray
    round: true
    onClicked: plugin.uzbrojony ? plugin.rozbroj() : plugin.uzbroj()
    onPressAndHold: okno.open()
  }

  function uzbroj() {
    if (!kontenerMapy) {
      toast(qsTr("Nie znalazłem mapy — narzędzie niedostępne w tej wersji aplikacji."));
      return;
    }
    if (rastry().length === 0) {
      toast(qsTr("Projekt nie ma pobranego rastra. Dodaj NMT albo NMPT."));
      return;
    }
    if (!ukladMetryczny()) {
      toast(qsTr("Układ projektu jest w stopniach — promień w metrach nie ma tu sensu."));
      return;
    }
    wyczysc();
    uzbrojony = true;
    log("uzbrojone, tryb " + ustawienia.tryb + ", warstwa " + (warstwaBiezaca() ? warstwaBiezaca().name : "?"));
    toast(podpowiedz());
  }

  function rozbroj() {
    uzbrojony = false;
    wyczysc();
  }

  function wyczysc() {
    rysujKolo = false;
    promien = 0;
    wierzcholki = [];
    wynikTekst = "";
    wynikOpis = "";
    plotno.requestPaint();
  }

  function podpowiedz() {
    if (ustawienia.tryb === "punkt")
      return qsTr("Dotknij mapy — odczytam wartość w tym punkcie.");
    if (ustawienia.tryb === "kolo")
      return qsTr("Przyciśnij w środku i przeciągnij — promień ustawiasz palcem.");
    return qsTr("Stawiaj punkty łamanej, potem „Policz”.");
  }

  function toast(t) {
    if (mainWindow && mainWindow.displayToast)
      mainWindow.displayToast(t);
    log("toast: " + t);
  }

  function log(t) {
    console.log("PROBKA: " + t);
    iface.logMessage("PROBKA: " + t);
  }

  // ══════════════════════════════════════════════════════ nakładka na mapie
  // Własny Item wstawiony do "mapCanvasContainer": rysuje się NAD mapą,
  // a POD paskami narzędzi. Póki narzędzie jest uzbrojone, zjada zdarzenia
  // mapy — inaczej przeciągnięcie promienia przesuwałoby mapę.
  Item {
    id: nakladka

    visible: plugin.uzbrojony
    enabled: plugin.uzbrojony
    z: 900

    property var mapSettings: {
      try {
        return iface.mapCanvas().mapSettings;
      } catch (e) {
        return null;
      }
    }

    //! Punkt mapy → ekran.
    function naEkran(x, y) {
      if (!mapSettings)
        return Qt.point(0, 0);
      return mapSettings.coordinateToScreen(GeometryUtils.point(x, y));
    }

    //! Punkt ekranu → mapa.
    function naMape(px, py) {
      if (!mapSettings)
        return null;
      return mapSettings.screenToCoordinate(Qt.point(px, py));
    }

    //! Odległość ekranowa → jednostki mapy (metry w układzie metrycznym).
    function wMetrach(piksele) {
      if (!mapSettings)
        return 0;
      return piksele * mapSettings.mapUnitsPerPoint;
    }

    MouseArea {
      anchors.fill: parent
      // Pasek wyniku ma własne przyciski — nie zjadaj ich.
      anchors.bottomMargin: pasekWyniku.height
      // Bez tego przeciągnięcie promienia zabiera mapa pod spodem i zamiast
      // koła wychodzi przesunięcie widoku.
      preventStealing: true

      property bool ciagnie: false

      onPressed: function (mouse) {
        var p = nakladka.naMape(mouse.x, mouse.y);
        if (!p)
          return;
        if (ustawienia.tryb === "kolo") {
          plugin.srodekX = p.x;
          plugin.srodekY = p.y;
          plugin.promien = 0;
          plugin.rysujKolo = true;
          ciagnie = true;
          plotno.requestPaint();
        }
      }

      onPositionChanged: function (mouse) {
        if (!ciagnie || ustawienia.tryb !== "kolo")
          return;
        var s = nakladka.naEkran(plugin.srodekX, plugin.srodekY);
        var dx = mouse.x - s.x;
        var dy = mouse.y - s.y;
        plugin.promien = nakladka.wMetrach(Math.sqrt(dx * dx + dy * dy));
        plotno.requestPaint();
      }

      onReleased: function (mouse) {
        if (!ciagnie)
          return;
        ciagnie = false;
        plugin.probkaKolo(plugin.srodekX, plugin.srodekY, plugin.promien);
      }

      onClicked: function (mouse) {
        var p = nakladka.naMape(mouse.x, mouse.y);
        if (!p)
          return;
        if (ustawienia.tryb === "punkt") {
          plugin.srodekX = p.x;
          plugin.srodekY = p.y;
          plugin.rysujKolo = false;
          plotno.requestPaint();
          plugin.probkaPunkt(p.x, p.y);
        } else if (ustawienia.tryb === "linia") {
          var lista = plugin.wierzcholki.slice();
          lista.push({
            "x": p.x,
            "y": p.y
          });
          plugin.wierzcholki = lista;
          plotno.requestPaint();
        }
      }
    }

    Canvas {
      id: plotno
      anchors.fill: parent

      onPaint: {
        var ctx = getContext("2d");
        ctx.reset();
        ctx.lineWidth = 2;

        if (ustawienia.tryb === "kolo" && plugin.rysujKolo) {
          var s = nakladka.naEkran(plugin.srodekX, plugin.srodekY);
          var rpx = plugin.promien / Math.max(0.000001, nakladka.mapSettings ? nakladka.mapSettings.mapUnitsPerPoint : 1);
          ctx.strokeStyle = "#ff8f00";
          ctx.fillStyle = "#33ff8f00";
          ctx.beginPath();
          ctx.arc(s.x, s.y, Math.max(1, rpx), 0, 2 * Math.PI);
          ctx.fill();
          ctx.stroke();
          krzyzyk(ctx, s.x, s.y, "#ff8f00");
        } else if (ustawienia.tryb === "punkt" && plugin.wynikOpis !== "") {
          var q = nakladka.naEkran(plugin.srodekX, plugin.srodekY);
          krzyzyk(ctx, q.x, q.y, "#39ff14");
        } else if (ustawienia.tryb === "linia" && plugin.wierzcholki.length > 0) {
          ctx.strokeStyle = "#39ff14";
          ctx.beginPath();
          for (var i = 0; i < plugin.wierzcholki.length; i++) {
            var e = nakladka.naEkran(plugin.wierzcholki[i].x, plugin.wierzcholki[i].y);
            if (i === 0)
              ctx.moveTo(e.x, e.y);
            else
              ctx.lineTo(e.x, e.y);
          }
          ctx.stroke();
          for (var j = 0; j < plugin.wierzcholki.length; j++) {
            var w = nakladka.naEkran(plugin.wierzcholki[j].x, plugin.wierzcholki[j].y);
            ctx.fillStyle = "#39ff14";
            ctx.beginPath();
            ctx.arc(w.x, w.y, 4, 0, 2 * Math.PI);
            ctx.fill();
          }
        }
      }

      function krzyzyk(ctx, x, y, kolor) {
        ctx.strokeStyle = kolor;
        ctx.beginPath();
        ctx.moveTo(x - 10, y);
        ctx.lineTo(x + 10, y);
        ctx.moveTo(x, y - 10);
        ctx.lineTo(x, y + 10);
        ctx.stroke();
      }
    }

    // ── pasek u dołu: co robię, ile wyszło, co dalej ──────────────────
    Rectangle {
      id: pasekWyniku

      anchors.left: parent.left
      anchors.right: parent.right
      anchors.bottom: parent.bottom
      height: uklad.implicitHeight + 12
      color: "#e0263238"

      // Wynik ma SWÓJ wiersz. Przy trybie linii cztery przyciski w jednym
      // rzędzie zjadały liczbę do „14…” (piaskownica 21.09).
      ColumnLayout {
        id: uklad
        anchors.fill: parent
        anchors.margins: 6
        spacing: 2

        RowLayout {
          Layout.fillWidth: true
          spacing: 8

          Text {
            Layout.fillWidth: true
            text: plugin.wynikTekst !== "" ? plugin.wynikTekst : (ustawienia.tryb === "kolo" && plugin.rysujKolo ? qsTr("r = %1 m").arg(plugin.promien.toFixed(1)) : plugin.podpowiedz())
            font.pointSize: plugin.wynikTekst !== "" ? 16 : 9
            font.bold: plugin.wynikTekst !== ""
            color: "#ffffff"
            elide: Text.ElideRight
          }

          Button {
            visible: plugin.wynikTekst !== ""
            text: qsTr("Kopiuj")
            font.pointSize: 9
            onClicked: {
              if (plugin.doSchowka(plugin.wynikTekst))
                plugin.toast(qsTr("%1 — skopiowane").arg(plugin.wynikTekst));
            }
          }
        }

        Text {
          Layout.fillWidth: true
          visible: plugin.wynikOpis !== ""
          text: plugin.wynikOpis
          font.pointSize: 9
          color: "#b0bec5"
          elide: Text.ElideRight
        }

        RowLayout {
          Layout.fillWidth: true
          Layout.topMargin: 2
          spacing: 6

          Button {
            visible: ustawienia.tryb === "linia" && plugin.wierzcholki.length > 0
            text: qsTr("Cofnij")
            font.pointSize: 9
            onClicked: {
              var lista = plugin.wierzcholki.slice();
              lista.pop();
              plugin.wierzcholki = lista;
              plotno.requestPaint();
            }
          }

          Button {
            visible: ustawienia.tryb === "linia"
            enabled: plugin.wierzcholki.length > 1
            text: qsTr("Policz")
            font.pointSize: 9
            highlighted: true
            onClicked: plugin.probkaLinia()
          }

          Item {
            Layout.fillWidth: true
          }

          Button {
            text: qsTr("Koniec")
            font.pointSize: 9
            onClicked: plugin.rozbroj()
          }
        }
      }
    }
  }

  // ══════════════════════════════════════════════════════ ustawienia
  Dialog {
    id: okno

    parent: mainWindow.contentItem
    modal: true
    title: qsTr("Próbka z warstwy")
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 40, 500)
    standardButtons: Dialog.Close

    onOpened: {
      var lista = plugin.rastry();
      var nazwy = [];
      for (var i = 0; i < lista.length; i++)
        nazwy.push(lista[i].nazwa);
      warstwaCombo.model = nazwy;
      var w = plugin.warstwaBiezaca();
      warstwaCombo.currentIndex = w ? Math.max(0, nazwy.indexOf(w.name)) : -1;
      // Tryb i statystyka też odświeżane PRZY OTWARCIU: Component.onCompleted
      // ustawia je raz, przy wczytaniu wtyczki, i okno pokazywało potem stan
      // sprzed zmiany (piaskownica 21.09).
      trybCombo.currentIndex = Math.max(0, trybCombo.indexOfValue(ustawienia.tryb));
      statCombo.currentIndex = Math.max(0, statCombo.indexOfValue(ustawienia.statystyka));
    }

    ColumnLayout {
      anchors.fill: parent
      spacing: 8

      Label {
        Layout.fillWidth: true
        text: qsTr("Odczyt wartości z warstwy: punkt, średnia wzdłuż linii albo średnia z koła. Wynik idzie do schowka samą liczbą — tak, żeby wkleić go w pole formularza.")
        wrapMode: Text.WordWrap
        color: "#9e9e9e"
        font.pointSize: 9
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Label {
          text: qsTr("Warstwa:")
          color: "#9e9e9e"
        }

        ComboBox {
          id: warstwaCombo
          Layout.fillWidth: true
          onActivated: ustawienia.warstwa = currentText
        }
      }

      Label {
        Layout.fillWidth: true
        visible: warstwaCombo.count === 0
        text: qsTr("Projekt nie ma pobranego rastra. Podkład z sieci (WMS, XYZ) się nie nadaje — próbkować da się tylko dane w telefonie: NMT, NMPT, CHM, nachylenie.")
        wrapMode: Text.WordWrap
        color: "#ffa500"
        font.pointSize: 9
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Label {
          text: qsTr("Tryb:")
          color: "#9e9e9e"
        }

        ComboBox {
          id: trybCombo
          Layout.fillWidth: true
          textRole: "label"
          valueRole: "value"
          model: [
            {
              label: qsTr("Punkt — wartość pod palcem"),
              value: "punkt"
            },
            {
              label: qsTr("Linia — średnia wzdłuż łamanej"),
              value: "linia"
            },
            {
              label: qsTr("Koło — średnia z okręgu o promieniu"),
              value: "kolo"
            }
          ]
          Component.onCompleted: currentIndex = Math.max(0, indexOfValue(ustawienia.tryb))
          onActivated: {
            ustawienia.tryb = currentValue;
            plugin.wyczysc();
          }
        }
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8
        visible: ustawienia.tryb !== "punkt"

        Label {
          text: qsTr("Statystyka:")
          color: "#9e9e9e"
        }

        ComboBox {
          id: statCombo
          Layout.fillWidth: true
          textRole: "label"
          valueRole: "value"
          model: [
            {
              label: qsTr("średnia"),
              value: "mean"
            },
            {
              label: qsTr("mediana"),
              value: "median"
            }
          ]
          Component.onCompleted: currentIndex = Math.max(0, indexOfValue(ustawienia.statystyka))
          onActivated: ustawienia.statystyka = currentValue
        }
      }

      Label {
        Layout.fillWidth: true
        visible: ustawienia.tryb !== "punkt"
        text: qsTr("Mediana jest odporna na pojedyncze dziwne piksele — przy CHM to zwykle lepszy wybór niż średnia.")
        wrapMode: Text.WordWrap
        color: "#9e9e9e"
        font.pointSize: 9
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Label {
          text: qsTr("Miejsc po przecinku:")
          color: "#9e9e9e"
        }

        SpinBox {
          from: 0
          to: 4
          value: ustawienia.miejsca
          onValueModified: ustawienia.miejsca = value
        }
      }

      CheckBox {
        Layout.fillWidth: true
        text: qsTr("Kopiuj wynik do schowka")
        checked: ustawienia.doSchowka
        onToggled: ustawienia.doSchowka = checked
      }

      Label {
        Layout.fillWidth: true
        text: qsTr("Wersja %1 — rastry. Warstwy wektorowe (średnia z pola obiektów pod punktem, przeciętych linią albo w kole) czekają na czasownik w silniku.").arg(plugin.wersja)
        wrapMode: Text.WordWrap
        color: "#9e9e9e"
        font.pointSize: 9
      }
    }
  }
}
