import QtQuick
import org.qfield
import org.qfield.core
import Theme

/**
 * WorkFieldGIS — MODUŁ „Inwentaryzacja IGO” jako wtyczka (wersja 0.1, 16.10.2026).
 *
 * Moduł instaluje się na gotowym APK, tak jak każda wtyczka. Po włączeniu
 * zgłasza swój silnik aplikacji: iface.zarejestrujModul(silnik). Panel
 * „Moduły” (prawa szuflada) buduje z silnik.opis() kartę modułu i „Nowy
 * projekt z modułu”. Wyłączona albo odinstalowana wtyczka znika z panelu
 * sama — aplikacja trzyma do silnika tylko słaby wskaźnik.
 *
 * Etap 1 (decyzja Piotra 16.10.2026): projekt + płaty + eksport.
 *  - projekt w EPSG:2180, przyciąganie w metrach, załączniki (moduły
 *    wyposażenia aplikacji: „przyciaganie”, „zalaczniki”);
 *  - warstwy: granica gminy, gminy sąsiednie, działki, płaty IGO;
 *  - JEDEN GATUNEK = JEDEN PŁAT (płaty różnych gatunków mogą na siebie
 *    zachodzić);
 *  - pola płatu jak w projekcie APPL HM Nakło (gatunek, jednostka, ilość,
 *    miejsce, data) — czyli układ zgłoszenia IGO — plus faza, obserwator,
 *    działka i stan zgłoszenia;
 *  - ortofoto GUGiK: akcja „Podkłady…” prowadzi do okna z odmianą Ortofoto.
 *
 * Etapy 2–4 (zgłoszenie mailem, raport PDF działek, model zasięgu) — patrz
 * claude/MODUL_IGO_plan.md.
 *
 * Diagnostyka: log z prefiksem "IGO:".
 */
Item {
  id: wtyczka

  readonly property string wersja: "0.1"

  Component.onCompleted: {
    if (typeof iface.zarejestrujModul !== "function") {
      log("ta wersja aplikacji nie ma rejestru modułów (iface.zarejestrujModul) — potrzebna nowsza");
      return;
    }
    iface.zarejestrujModul(silnik);
    log("moduł " + wersja + " zarejestrowany");
  }

  function log(t) {
    console.log("IGO: " + t);
    try {
      iface.logMessage("IGO: " + t);
    } catch (e) {}
  }

  QtObject {
    id: silnik

    // Gatunki: Polska nazwa (łacińska). Wartość zapisywana = to samo.
    // DO SPRAWDZENIA PRZEZ PIOTRA z listami IGO (unijną i krajową) — lista
    // jest w JEDNYM miejscu, nowa wersja wtyczki ją poprawia.
    readonly property var gatunki: [
      "barszcz Sosnowskiego (Heracleum sosnowskyi)",
      "barszcz Mantegazziego (Heracleum mantegazzianum)",
      "rdestowiec ostrokończysty (Reynoutria japonica)",
      "rdestowiec sachaliński (Reynoutria sachalinensis)",
      "rdestowiec czeski (Reynoutria ×bohemica)",
      "niecierpek gruczołowaty (Impatiens glandulifera)",
      "nawłoć kanadyjska (Solidago canadensis)",
      "nawłoć późna (Solidago gigantea)",
      "kolczurka klapowana (Echinocystis lobata)",
      "czeremcha amerykańska (Prunus serotina)",
      "klon jesionolistny (Acer negundo)",
      "robinia akacjowa (Robinia pseudoacacia)",
      "róża pomarszczona (Rosa rugosa)",
      "inny gatunek (wpisz w uwagach)"
    ]

    function mapa(lista) {
      return lista.map(function (x) {
        const m = {};
        m[x] = x;
        return m;
      });
    }

    function mapaPar(pary) {
      return pary.map(function (p) {
        const m = {};
        m[p[0]] = p[1];
        return m;
      });
    }

    function opis() {
      return {
        "id": "inwentaryzacja_igo",
        "nazwa": "Inwentaryzacja IGO",
        "wersja": wtyczka.wersja,
        "silnik": "InwentaryzacjaIGO",
        "opis": "Płaty inwazyjnych gatunków obcych (jeden gatunek = jeden płat), działki zamawiającego i znalezione w terenie, granice gmin. EPSG:2180, przyciąganie w metrach, załączniki; ortofoto GUGiK w oknie podkładów.",
        "wymaga_silnika": ["InwentaryzacjaIGO.rozpoznaj", "InwentaryzacjaIGO.podsumuj"],
        "rozpoznanie": "InwentaryzacjaIGO.rozpoznaj",
        "role": [
          { "klucz": "opisGatunkow", "nazwa": "gatunki" },
          { "klucz": "opisDzialek", "nazwa": "działki" },
          { "klucz": "opisZgloszen", "nazwa": "zgłoszenia" }
        ],
        "przepis": {
          "uklad": "EPSG:2180",
          "grupa": "Inwentaryzacja IGO",
          "ustawienia": { "wfg_igo/warstwaPlatow": "platy_igo", "wfg_igo/warstwaDzialek": "dzialki" },
          "wyposazenie": ["przyciaganie", "zalaczniki"],
          // kolejność = kolejność dokładania; ostatnia na wierzchu legendy
          "warstwy": [
            { "nazwa": "gminy_sasiednie", "typ": "Polygon", "pola": [
              { "name": "teryt", "type": "text", "alias": "TERYT" },
              { "name": "nazwa", "type": "text", "alias": "Gmina" }
            ] },
            { "nazwa": "granica_gminy", "typ": "Polygon", "pola": [
              { "name": "teryt", "type": "text", "alias": "TERYT" },
              { "name": "nazwa", "type": "text", "alias": "Gmina" }
            ] },
            { "nazwa": "dzialki", "typ": "Polygon", "pola": [
              { "name": "teryt_dzialki", "type": "text", "alias": "Identyfikator działki (TERYT)" },
              { "name": "obreb", "type": "text", "alias": "Obręb" },
              { "name": "numer", "type": "text", "alias": "Numer działki" },
              { "name": "zrodlo", "type": "text", "alias": "Skąd działka", "widget": "ValueMap",
                "opcje": { "map": mapaPar([["z listy zamawiającego", "zamawiajacy"], ["znaleziona w terenie", "teren"]]) }, "domyslna": "'teren'" },
              { "name": "stan", "type": "text", "alias": "Stan kontroli", "widget": "ValueMap",
                "opcje": { "map": mapaPar([["niesprawdzona", "niesprawdzona"], ["sprawdzona — bez IGO", "bez_igo"], ["sprawdzona — z IGO", "z_igo"]]) }, "domyslna": "'niesprawdzona'" },
              { "name": "powierzchnia_ha", "type": "real", "alias": "Powierzchnia [ha]", "domyslna": "round($area / 10000, 4)", "przy_zmianie": true },
              { "name": "data_kontroli", "type": "date", "alias": "Data kontroli" },
              { "name": "uwagi", "type": "multiline", "alias": "Uwagi" }
            ] },
            { "nazwa": "platy_igo", "typ": "Polygon", "pola": [
              { "name": "gatunek", "type": "text", "alias": "Gatunek", "widget": "ValueMap", "opcje": { "map": mapa(gatunki) } },
              { "name": "jednostka", "type": "text", "alias": "Jednostka miary ilości", "widget": "ValueMap",
                "opcje": { "map": mapaPar([["powierzchnia [m²]", "m2"], ["liczba okazów [szt.]", "szt"]]) }, "domyslna": "'m2'" },
              { "name": "ilosc", "type": "real", "alias": "Ilość (m² albo okazy)",
                "domyslna": "if(\"jednostka\" = 'm2', round($area, 1), \"ilosc\")", "przy_zmianie": true },
              { "name": "powierzchnia_m2", "type": "real", "alias": "Powierzchnia płatu [m²]", "domyslna": "round($area, 1)", "przy_zmianie": true },
              { "name": "faza", "type": "text", "alias": "Faza rozwojowa", "widget": "ValueMap",
                "opcje": { "map": mapa(["siewki", "rozety", "kwitnące", "owocujące", "zamierające", "mieszane"]) } },
              { "name": "miejsce", "type": "text", "alias": "Opis lokalizacji" },
              { "name": "data_stwierdzenia", "type": "date", "alias": "Data stwierdzenia", "domyslna": "now()" },
              { "name": "obserwator", "type": "text", "alias": "Obserwator", "domyslna": "@wykonawca" },
              { "name": "teryt_dzialki", "type": "text", "alias": "Działka (TERYT)",
                "domyslna": "array_first(overlay_intersects(layer:='dzialki', expression:=\"teryt_dzialki\"))", "przy_zmianie": true },
              { "name": "zgloszony", "type": "text", "alias": "Zgłoszony do gminy", "widget": "ValueMap",
                "opcje": { "map": mapaPar([["nie", "nie"], ["tak", "tak"]]) }, "domyslna": "'nie'" },
              { "name": "data_zgloszenia", "type": "date", "alias": "Data zgłoszenia" },
              { "name": "uwagi", "type": "multiline", "alias": "Uwagi" }
            ] }
          ]
        },
        "akcje": [
          { "etykieta": "Podkłady, ortofoto i dane wysokościowe…", "okno": "podklady" },
          { "etykieta": "Podsumowanie płatów", "czasownik": "InwentaryzacjaIGO.podsumuj",
            "komunikat": "Płatów: {platy}, razem {powierzchnia} m², gatunków: {gatunkow}; niezgłoszonych: {niezgloszone}" }
        ]
      };
    }

    //! Warstwa po nazwie; w projekcie z Nakła płaty nazywają się „platy_IGO”.
    function warstwa(projekt, nazwy) {
      if (typeof NarzedziaProjektu === "undefined")
        return null;
      for (const n of nazwy) {
        const w = NarzedziaProjektu.warstwaPoNazwie(projekt, n);
        if (w)
          return w;
      }
      return null;
    }

    //! Wartość pierwszego z pól, które warstwa MA. QgsFeature.attribute()
    //! dla pola, którego nie ma, oddaje `undefined`, a dla pustej wartości
    //! `null` — po tym odróżniamy „nie ma pola” od „pole puste”, bez
    //! sięgania do API pól warstwy z QML.
    function wartosc(f, pola) {
      for (const p of pola) {
        const v = f.attribute(p);
        if (v !== undefined)
          return { "jest": true, "v": v };
      }
      return { "jest": false, "v": null };
    }

    //! Zliczenie obiektów wg pierwszego istniejącego pola z `pola`;
    //! `polaSumy` — pola do zsumowania (np. powierzchnia).
    function zlicz(w, pola, polaSumy) {
      const wynik = { "obiekty": 0, "wg": {}, "suma": 0, "jestPole": false };
      if (!w)
        return wynik;
      const it = LayerUtils.createFeatureIteratorFromExpression(w, "TRUE");
      let ile = 0;
      while (it.hasNext() && ile < 20000) {
        const f = it.next();
        ile++;
        const a = wartosc(f, pola);
        if (a.jest) {
          wynik.jestPole = true;
          const k = a.v === null || String(a.v) === "" ? "—" : String(a.v);
          wynik.wg[k] = (wynik.wg[k] || 0) + 1;
        }
        if (polaSumy) {
          const b = wartosc(f, polaSumy);
          const liczba = parseFloat(b.v);
          if (!isNaN(liczba))
            wynik.suma += liczba;
        }
      }
      it.close();
      wynik.obiekty = ile;
      return wynik;
    }

    function skrot(wg) {
      return Object.keys(wg).sort(function (a, b) {
        return wg[b] - wg[a];
      }).map(function (k) {
        return k.replace(/\s*\(.*\)$/, "") + " " + wg[k];
      }).join(", ");
    }

    function rozpoznaj(projekt) {
      const platy = warstwa(projekt, ["platy_igo", "platy_IGO"]);
      if (!platy)
        return { "blad": "brak warstwy platy_igo" };
      const dzialki = warstwa(projekt, ["dzialki"]);
      const g = zlicz(platy, ["gatunek", "nazwa_gatunku"], null);
      const z = zlicz(platy, ["zgloszony"], null);
      const d = dzialki ? zlicz(dzialki, ["stan"], null) : null;
      return {
        "warstwa": platy.name,
        "obiekty": g.obiekty,
        "opisGatunkow": g.jestPole ? skrot(g.wg) : "",
        "opisDzialek": d && d.jestPole ? d.obiekty + ": " + skrot(d.wg) : "",
        "opisZgloszen": z.jestPole ? skrot(z.wg) : "",
        "zModulu": iface.readProjectEntry("wfg_moduly", "inwentaryzacja_igo", "") !== ""
      };
    }

    function podsumuj(projekt) {
      const platy = warstwa(projekt, ["platy_igo", "platy_IGO"]);
      if (!platy)
        return { "blad": "W projekcie nie ma warstwy platy_igo" };
      const g = zlicz(platy, ["gatunek", "nazwa_gatunku"], ["powierzchnia_m2"]);
      const z = zlicz(platy, ["zgloszony"], null);
      const w = {
        "platy": g.obiekty,
        "powierzchnia": Math.round(g.suma),
        "gatunkow": Object.keys(g.wg).filter(function (k) {
          return k !== "—";
        }).length,
        // puste pole „zgłoszony” = jeszcze nie zgłoszony
        "niezgloszone": z.jestPole ? g.obiekty - (z.wg["tak"] || 0) : g.obiekty,
        "wg_gatunkow": g.wg
      };
      wtyczka.log("podsumowanie: " + JSON.stringify(w));
      return w;
    }
  }
}
