import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import Theme
import "zapis.js" as Zapis

/**
 * WorkField Zakres — zakres obszaru do wniosku w ODGiK (np. o mapę zasadniczą).
 *
 * Wersja 0.2 (07.10.2026): pływający panel rysowania u góry ekranu (Cofnij / Anuluj /
 *   Gotowe) — w 0.1 pasek na dole mapy był przykryty i nie dało się zatwierdzić.
 * Wersja 0.1 (07.10.2026).
 *
 * Skąd zakres:
 *   • widoczny obszar mapy,
 *   • narysowany na mapie (tapnięcia stawiają wierzchołki),
 *   • obiekt z warstwy poligonowej (np. „Zasięg opracowania”).
 *
 * Co zapisuje (katalog projektu: ODGIK/zakres_<data>_<nazwa>/):
 *   zakres.gml                 GML 3.2, PL-2000 (oś: północ, wschód — jak w EPSG)
 *   zakres.shp/.shx/.dbf/.prj/.cpg   shapefile, PL-2000
 *   zakres.dxf                 R12, X = wschód, Y = północ (konwencja CAD)
 *   zakres.kml                 WGS84 — do portali i Google Earth
 *   zakres_wspolrzedne.txt     wykaz współrzędnych X/Y (zapis geodezyjny) + powierzchnia
 *   zakres_mapa.png            załącznik graficzny: widok mapy z obrysem
 *   zakres_<nazwa>.zip         wszystko w jednym pliku — do maila i do wniosku
 *
 * Strefa PL-2000 (5–8, EPSG:2176–2179) dobierana ze środka obszaru.
 * Formaty zapisuje czysty JS (zapis.js) — przetestowany w Node i odczytany GDAL-em.
 *
 * Diagnostyka: log z prefiksem "ZAKRES:".
 */
Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property var kontenerMapy: iface.findItemByObjectName("mapCanvasContainer")

  readonly property string wersja: "0.2"

  //! Bieżący zakres: { zrodlo, crs, polys: [[[{x,y}]]] } we współrzędnych źródła.
  property var zakres: null
  //! To samo w PL-2000: { epsg, polys: [[[{e,n}]]], pow }
  property var zakres2000: null

  property bool rysuje: false
  property bool podglad: false
  property var wierzcholki: []
  property string katalogWyniku: ""
  property string zipWyniku: ""
  property var warstwyPoligonowe: []
  property var obiektyWarstwy: []

  Settings {
    id: ustawienia
    category: "WorkFieldZakres"
    property string nazwa: ""
    property string warstwa: ""
  }

  MapLayerModel {
    id: modelWarstw
    project: qgisProject
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(przycisk)
    if (kontenerMapy) {
      nakladka.parent = kontenerMapy
      nakladka.anchors.fill = kontenerMapy
    }
    log("wtyczka " + wersja + " wczytana; kontener mapy: " + (kontenerMapy ? "jest" : "BRAK"))
  }

  QfToolButton {
    id: przycisk
    iconSource: 'icon.svg'
    iconColor: plugin.rysuje ? "#39ff14" : "#B0BEC5"
    bgcolor: plugin.rysuje ? "#1b5e20" : Theme.darkGray
    round: true
    onClicked: {
      if (plugin.rysuje) {
        plugin.koniecRysowania(false)
        return
      }
      plugin.odswiezWarstwy()
      okno.open()
    }
  }

  function log(t) {
    console.log("ZAKRES: " + t)
    try { iface.logMessage("ZAKRES: " + t) } catch (e) {}
  }

  function toast(t) {
    if (mainWindow && mainWindow.displayToast)
      mainWindow.displayToast(t)
    log("toast: " + t)
  }

  function projectHome() {
    if (typeof qgisProject === "undefined" || !qgisProject || !qgisProject.homePath)
      return ""
    var p = qgisProject.homePath
    return p.endsWith("/") ? p : p + "/"
  }

  function mapSettings() {
    try { return iface.mapCanvas().mapSettings } catch (e) { return null }
  }

  // ══════════════════════════════════════════════════ źródła zakresu

  function zWidoku() {
    var ms = mapSettings()
    if (!ms) {
      toast(qsTr("Nie znalazłem mapy."))
      return
    }
    var r = ms.visibleExtent
    var ring = [
      { x: r.xMinimum, y: r.yMinimum }, { x: r.xMaximum, y: r.yMinimum },
      { x: r.xMaximum, y: r.yMaximum }, { x: r.xMinimum, y: r.yMaximum }
    ]
    ustawZakres(qsTr("widoczny obszar mapy"), ms.destinationCrs, [[ring]])
  }

  function zaczniRysowanie() {
    if (!kontenerMapy) {
      toast(qsTr("Nie znalazłem mapy — rysowanie niedostępne."))
      return
    }
    wierzcholki = []
    rysuje = true
    podglad = false
    okno.close()
    plotno.requestPaint()
    toast(qsTr("Stawiaj wierzchołki tapnięciami. Potem „Gotowe”."))
  }

  function koniecRysowania(zatwierdz) {
    rysuje = false
    if (zatwierdz) {
      if (wierzcholki.length < 3) {
        toast(qsTr("Potrzeba co najmniej 3 wierzchołków."))
        rysuje = true
        return
      }
      ustawZakres(qsTr("narysowany na mapie"), mapSettings().destinationCrs, [[wierzcholki.slice()]])
    }
    plotno.requestPaint()
    okno.open()
  }

  function odswiezWarstwy() {
    var lista = []
    try {
      var n = modelWarstw.rowCount()
      for (var i = 0; i < n; i++) {
        var w = modelWarstw.get(i).LayerPointer
        if (!w)
          continue
        var poligon = false
        try { poligon = (w.geometryType() === 2) } catch (e) { poligon = false }
        if (poligon)
          lista.push({ warstwa: w, nazwa: modelWarstw.get(i).Name })
      }
    } catch (e) {
      log("nie umiem przejrzeć warstw: " + e)
    }
    warstwyPoligonowe = lista
  }

  function wczytajObiekty(w) {
    var lista = []
    if (!w) {
      obiektyWarstwy = []
      return
    }
    try {
      var it = LayerUtils.createFeatureIteratorFromExpression(w, "TRUE")
      var ile = 0
      while (it.hasNext() && ile < 300) {
        var f = it.next()
        var opis = ""
        try { opis = FeatureUtils.displayName(w, f) } catch (e) {}
        lista.push({ obiekt: f, opis: (opis && opis !== "" ? opis : "#" + f.id) })
        ile++
      }
      it.close()
    } catch (e) {
      log("nie umiem odczytać obiektów: " + e)
    }
    obiektyWarstwy = lista
  }

  function zObiektu(w, f, opis) {
    var wkt = ""
    try { wkt = f.geometry.asWkt() } catch (e) { wkt = "" }
    if (!wkt) {
      toast(qsTr("Nie umiem odczytać geometrii obiektu w tej wersji aplikacji."))
      log("asWkt niedostępne albo pusta geometria")
      return
    }
    var polys = Zapis.parsujWkt(wkt)
    if (!polys || polys.length === 0) {
      toast(qsTr("Obiekt nie jest poligonem (albo ma pustą geometrię)."))
      return
    }
    ustawZakres(qsTr("obiekt „%1” z warstwy %2").arg(opis).arg(w.name), w.crs, polys)
  }

  // ══════════════════════════════════════════════════ przeliczenie do PL-2000

  function ustawZakres(zrodlo, crs, polys) {
    zakres = { zrodlo: zrodlo, crs: crs, polys: polys }
    zakres2000 = null
    katalogWyniku = ""
    zipWyniku = ""
    try {
      var sx = 0, sy = 0, n = 0
      for (var i = 0; i < polys.length; i++)
        for (var k = 0; k < polys[i][0].length; k++) {
          sx += polys[i][0][k].x
          sy += polys[i][0][k].y
          n++
        }
      var srodek = GeometryUtils.reprojectPointToWgs84(GeometryUtils.point(sx / n, sy / n), crs)
      var epsg = Zapis.epsgDlaDlugosci(srodek.x)
      var crs2000 = CoordinateReferenceSystemUtils.fromDescription("EPSG:" + epsg)
      var wynik = []
      for (var a = 0; a < polys.length; a++) {
        var poly = []
        for (var b = 0; b < polys[a].length; b++) {
          var ring = []
          for (var c = 0; c < polys[a][b].length; c++) {
            var p = GeometryUtils.reprojectPoint(GeometryUtils.point(polys[a][b][c].x, polys[a][b][c].y), crs, crs2000)
            ring.push({ e: p.x, n: p.y })
          }
          poly.push(ring)
        }
        wynik.push(poly)
      }
      zakres2000 = { epsg: epsg, polys: wynik, pow: Zapis.polePowierzchni(wynik), lon: srodek.x, lat: srodek.y }
      // Do podglądu i obrazu mapy: ten sam obrys w układzie mapy.
      var ms = mapSettings()
      if (ms && crs.authid !== ms.destinationCrs.authid) {
        zakres.polysMapa = polys.map(function (pp) {
          return pp.map(function (r) {
            return r.map(function (q) {
              var m = GeometryUtils.reprojectPoint(GeometryUtils.point(q.x, q.y), crs, ms.destinationCrs)
              return { x: m.x, y: m.y }
            })
          })
        })
      } else {
        zakres.polysMapa = polys
      }
      podglad = true
      plotno.requestPaint()
      log("zakres: " + zrodlo + ", EPSG:" + epsg + ", " + zakres2000.pow.toFixed(1) + " m2")
    } catch (e) {
      toast(qsTr("Nie udało się przeliczyć do układu 2000: ") + e)
      log("przeliczenie: " + e)
    }
  }

  function doWgs(polys, crs) {
    return polys.map(function (p) {
      return p.map(function (r) {
        return r.map(function (q) {
          var w = GeometryUtils.reprojectPointToWgs84(GeometryUtils.point(q.x, q.y), crs)
          return { lon: w.x, lat: w.y }
        })
      })
    })
  }

  // ══════════════════════════════════════════════════ zapis

  function dwa(n) { return (n < 10 ? "0" : "") + n }

  function zapisz() {
    if (!zakres || !zakres2000)
      return
    var home = projectHome()
    if (home === "") {
      toast(qsTr("Najpierw otwórz projekt — pliki lądują w jego katalogu."))
      return
    }
    var d = new Date()
    var stempel = d.getFullYear() + dwa(d.getMonth() + 1) + dwa(d.getDate()) + "_" + dwa(d.getHours()) + dwa(d.getMinutes())
    var nazwa = nazwaPole.text.trim() !== "" ? nazwaPole.text.trim() : "zakres"
    ustawienia.nazwa = nazwa
    var bezpieczna = FileUtils.sanitizeFilePathPart(nazwa).replace(/\s+/g, "_")
    var podkat = "zakres_" + stempel + "_" + bezpieczna
    platformUtilities.createDir(qgisProject.homePath, "ODGIK")
    platformUtilities.createDir(home + "ODGIK", podkat)
    var kat = home + "ODGIK/" + podkat + "/"
    var data = d.getFullYear() + "-" + dwa(d.getMonth() + 1) + "-" + dwa(d.getDate())
    var z = zakres2000
    var opis = qsTr("PL-2000 EPSG:%1, powierzchnia %2 ha").arg(z.epsg).arg((z.pow / 10000).toFixed(4))

    var teksty = [
      { nazwa: "zakres.gml", tresc: Zapis.gml(z.polys, z.epsg, nazwa, z.pow) },
      { nazwa: "zakres.dxf", tresc: Zapis.dxf(z.polys, nazwa) },
      { nazwa: "zakres.kml", tresc: Zapis.kml(doWgs(zakres.polys, zakres.crs), nazwa, opis) },
      { nazwa: "zakres_wspolrzedne.txt", tresc: Zapis.txt(z.polys, z.epsg, nazwa, z.pow, data) },
      { nazwa: "zakres.prj", tresc: Zapis.prj(z.epsg) },
      { nazwa: "zakres.cpg", tresc: "UTF-8" }
    ]
    var doZipa = []
    var bledy = []
    for (var i = 0; i < teksty.length; i++) {
      if (!iface.writeTextFile(kat + teksty[i].nazwa, teksty[i].tresc))
        bledy.push(teksty[i].nazwa)
      doZipa.push({ nazwa: teksty[i].nazwa, dane: Zapis.utf8(teksty[i].tresc) })
    }
    var s = Zapis.shp(z.polys, nazwa, z.pow)
    var binarne = [{ nazwa: "zakres.shp", b: s.shp }, { nazwa: "zakres.shx", b: s.shx }, { nazwa: "zakres.dbf", b: s.dbf }]
    for (var j = 0; j < binarne.length; j++) {
      if (!FileUtils.writeFileContent(kat + binarne[j].nazwa, binarne[j].b))
        bledy.push(binarne[j].nazwa)
      doZipa.push({ nazwa: binarne[j].nazwa, dane: new Uint8Array(binarne[j].b) })
    }
    katalogWyniku = kat
    if (bledy.length > 0) {
      statusZapisu.text = qsTr("⚠ Nie zapisały się: ") + bledy.join(", ")
      log("bledy zapisu: " + bledy.join(", "))
    }
    // Załącznik graficzny: zrzut mapy z obrysem, potem ZIP ze wszystkim.
    statusZapisu.text = qsTr("Zapisuję obraz mapy…")
    zrzutMapy(kat + "zakres_mapa.png", function (ok) {
      if (ok) {
        var png = FileUtils.readFileContent(kat + "zakres_mapa.png")
        if (png && png.byteLength > 0)
          doZipa.push({ nazwa: "zakres_mapa.png", dane: new Uint8Array(png) })
      }
      var zipNazwa = "zakres_" + bezpieczna + ".zip"
      var zipOk = FileUtils.writeFileContent(kat + zipNazwa, Zapis.zip(doZipa).buffer)
      zipWyniku = zipOk ? kat + zipNazwa : ""
      statusZapisu.text = (bledy.length > 0 ? qsTr("⚠ Nie zapisały się: ") + bledy.join(", ") + "\n" : "")
        + qsTr("Zapisano %1 plików").arg(doZipa.length + (zipOk ? 1 : 0))
        + (ok ? "" : qsTr(" (bez obrazu mapy)")) + qsTr(" w:\n") + kat
      log("zapisano do " + kat + ", zip: " + zipOk + ", png: " + ok)
    })
  }

  function zrzutMapy(sciezka, gotowe) {
    if (!kontenerMapy) {
      gotowe(false)
      return
    }
    podglad = true
    plotno.requestPaint()
    zwloka.sciezka = sciezka
    zwloka.gotowe = gotowe
    zwloka.start()
  }

  Timer {
    id: zwloka
    interval: 300
    property string sciezka: ""
    property var gotowe: null
    onTriggered: {
      var cb = gotowe
      var sc = sciezka
      try {
        plugin.kontenerMapy.grabToImage(function (r) {
          var ok = false
          try { ok = r.saveToFile(sc) } catch (e) { ok = false }
          cb(ok)
        })
      } catch (e) {
        plugin.log("grabToImage: " + e)
        cb(false)
      }
    }
  }

  // ══════════════════════════════════════════════════ nakładka na mapie
  Item {
    id: nakladka
    visible: plugin.rysuje || plugin.podglad
    z: 900

    function naEkran(x, y) {
      var ms = plugin.mapSettings()
      if (!ms)
        return Qt.point(0, 0)
      return ms.coordinateToScreen(GeometryUtils.point(x, y))
    }

    Connections {
      target: plugin.mapSettings()
      ignoreUnknownSignals: true
      function onExtentChanged() { plotno.requestPaint() }
      function onVisibleExtentChanged() { plotno.requestPaint() }
    }

    MouseArea {
      anchors.fill: parent
      enabled: plugin.rysuje
      visible: plugin.rysuje
      onClicked: function (mouse) {
        var ms = plugin.mapSettings()
        if (!ms)
          return
        var p = ms.screenToCoordinate(Qt.point(mouse.x, mouse.y))
        var l = plugin.wierzcholki.slice()
        l.push({ x: p.x, y: p.y })
        plugin.wierzcholki = l
        plotno.requestPaint()
      }
    }

    Canvas {
      id: plotno
      anchors.fill: parent
      onPaint: {
        var ctx = getContext("2d")
        ctx.reset()
        ctx.lineWidth = 3
        function obrys(ring, zamknij, kolor, wypelnienie) {
          if (ring.length === 0)
            return
          ctx.strokeStyle = kolor
          ctx.fillStyle = wypelnienie
          ctx.beginPath()
          for (var i = 0; i < ring.length; i++) {
            var e = nakladka.naEkran(ring[i].x, ring[i].y)
            if (i === 0) ctx.moveTo(e.x, e.y)
            else ctx.lineTo(e.x, e.y)
          }
          if (zamknij) {
            ctx.closePath()
            ctx.fill()
          }
          ctx.stroke()
        }
        if (plugin.rysuje) {
          obrys(plugin.wierzcholki, plugin.wierzcholki.length >= 3, "#ff1744", "#33ff1744")
          for (var j = 0; j < plugin.wierzcholki.length; j++) {
            var w = nakladka.naEkran(plugin.wierzcholki[j].x, plugin.wierzcholki[j].y)
            ctx.fillStyle = "#ff1744"
            ctx.beginPath()
            ctx.arc(w.x, w.y, 6, 0, 2 * Math.PI)
            ctx.fill()
          }
        } else if (plugin.podglad && plugin.zakres) {
          var pm = plugin.zakres.polysMapa || []
          for (var a = 0; a < pm.length; a++)
            for (var b = 0; b < pm[a].length; b++)
              obrys(pm[a][b], true, "#ff1744", b === 0 ? "#22ff1744" : "#00000000")
        }
      }
    }

  }

  // ══════════════════════════════════════════════════ panel rysowania
  // PŁYWAJĄCY, u góry ekranu, ponad wszystkim (v0.2). W 0.1 pasek leżał na dole
  // kontenera mapy i przykrywały go dolne paski aplikacji — nie było jak
  // zatwierdzić ani wyjść z rysowania (próba Piotra 07.10.2026).
  Rectangle {
    id: panelRysowania
    parent: mainWindow.contentItem
    visible: plugin.rysuje
    z: 10000
    width: Math.min(parent ? parent.width - 24 : 400, 460)
    x: parent ? (parent.width - width) / 2 : 0
    y: (typeof mainWindow.sceneTopMargin !== "undefined" ? mainWindow.sceneTopMargin : 0) + 72
    height: kolPanelu.implicitHeight + 16
    radius: 12
    color: "#f0263238"
    border.color: "#ff1744"
    border.width: 2

    ColumnLayout {
      id: kolPanelu
      anchors.fill: parent
      anchors.margins: 8
      spacing: 6

      Text {
        Layout.fillWidth: true
        horizontalAlignment: Text.AlignHCenter
        text: plugin.wierzcholki.length < 3
              ? qsTr("Rysowanie zakresu: tapnij mapę, aby dodać wierzchołek (%1/3)").arg(plugin.wierzcholki.length)
              : qsTr("Wierzchołków: %1 — dodawaj dalej albo zatwierdź").arg(plugin.wierzcholki.length)
        color: "#ffffff"
        font.pointSize: 10
        wrapMode: Text.WordWrap
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Button {
          Layout.fillWidth: true
          Layout.preferredHeight: 48
          text: qsTr("↶ Cofnij")
          enabled: plugin.wierzcholki.length > 0
          onClicked: {
            var l = plugin.wierzcholki.slice()
            l.pop()
            plugin.wierzcholki = l
            plotno.requestPaint()
          }
        }
        Button {
          Layout.fillWidth: true
          Layout.preferredHeight: 48
          text: qsTr("✕ Anuluj")
          onClicked: {
            plugin.wierzcholki = []
            plugin.koniecRysowania(false)
          }
        }
        Button {
          Layout.fillWidth: true
          Layout.preferredHeight: 48
          text: qsTr("✓ Gotowe")
          enabled: plugin.wierzcholki.length >= 3
          highlighted: true
          onClicked: plugin.koniecRysowania(true)
        }
      }
    }
  }

  // ══════════════════════════════════════════════════ okno
  Dialog {
    id: okno
    parent: mainWindow.contentItem
    modal: true
    title: qsTr("Zakres do wniosku w ODGiK")
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 40, 520)
    height: Math.min(mainWindow.height - 60, 700)
    standardButtons: Dialog.Close
    onClosed: {
      if (!plugin.rysuje)
        plugin.podglad = false
      plotno.requestPaint()
    }

    Flickable {
      anchors.fill: parent
      contentHeight: kol.implicitHeight
      clip: true

      ColumnLayout {
        id: kol
        width: parent.width
        spacing: 8

        Label {
          Layout.fillWidth: true
          wrapMode: Text.WordWrap
          color: "#9e9e9e"
          font.pointSize: 9
          text: qsTr("Zapisuje obszar w formatach przyjmowanych przez ośrodki dokumentacji: GML, SHP, DXF, KML, wykaz współrzędnych i obraz mapy — w układzie 2000 właściwej strefy.")
        }

        TextField {
          id: nazwaPole
          Layout.fillWidth: true
          placeholderText: qsTr("Nazwa zakresu (np. Nakło — działki z barszczem)")
          text: ustawienia.nazwa
        }

        Label { text: qsTr("Skąd zakres:"); font.bold: true }

        RowLayout {
          Layout.fillWidth: true
          spacing: 8
          Button {
            Layout.fillWidth: true
            text: qsTr("▭ Widok mapy")
            onClicked: plugin.zWidoku()
          }
          Button {
            Layout.fillWidth: true
            text: qsTr("✎ Narysuj")
            onClicked: plugin.zaczniRysowanie()
          }
        }

        RowLayout {
          Layout.fillWidth: true
          spacing: 8
          visible: plugin.warstwyPoligonowe.length > 0
          ComboBox {
            id: wyborWarstwy
            Layout.fillWidth: true
            model: plugin.warstwyPoligonowe.map(function (x) { return x.nazwa })
            Component.onCompleted: {
              var i = model.indexOf(ustawienia.warstwa)
              if (i >= 0) currentIndex = i
            }
            onModelChanged: {
              var i = model.indexOf(ustawienia.warstwa)
              currentIndex = i >= 0 ? i : 0
              if (currentIndex >= 0 && currentIndex < plugin.warstwyPoligonowe.length)
                plugin.wczytajObiekty(plugin.warstwyPoligonowe[currentIndex].warstwa)
            }
            onCurrentIndexChanged: {
              if (currentIndex >= 0 && currentIndex < plugin.warstwyPoligonowe.length) {
                ustawienia.warstwa = plugin.warstwyPoligonowe[currentIndex].nazwa
                plugin.wczytajObiekty(plugin.warstwyPoligonowe[currentIndex].warstwa)
              }
            }
          }
        }

        RowLayout {
          Layout.fillWidth: true
          spacing: 8
          visible: plugin.warstwyPoligonowe.length > 0
          ComboBox {
            id: wyborObiektu
            Layout.fillWidth: true
            model: plugin.obiektyWarstwy.map(function (x) { return x.opis })
            enabled: plugin.obiektyWarstwy.length > 0
          }
          Button {
            text: qsTr("Użyj obiektu")
            enabled: wyborObiektu.currentIndex >= 0 && plugin.obiektyWarstwy.length > 0
            onClicked: {
              var w = plugin.warstwyPoligonowe[wyborWarstwy.currentIndex]
              var o = plugin.obiektyWarstwy[wyborObiektu.currentIndex]
              plugin.zObiektu(w.warstwa, o.obiekt, o.opis)
            }
          }
        }

        Label {
          Layout.fillWidth: true
          visible: plugin.warstwyPoligonowe.length === 0
          wrapMode: Text.WordWrap
          color: "#9e9e9e"
          font.pointSize: 9
          text: qsTr("W projekcie nie ma warstwy poligonowej — zakres z obiektu niedostępny.")
        }

        Rectangle {
          Layout.fillWidth: true
          visible: plugin.zakres2000 !== null
          implicitHeight: info.implicitHeight + 14
          radius: 6
          color: "#263238"
          Label {
            id: info
            anchors.fill: parent
            anchors.margins: 7
            wrapMode: Text.WordWrap
            color: "#ffffff"
            text: plugin.zakres2000 === null ? "" :
              qsTr("Zakres: %1\nUkład: PL-2000, strefa %2 (EPSG:%3)\nWierzchołków: %4\nPowierzchnia: %5 ha (%6 m²)")
                .arg(plugin.zakres.zrodlo)
                .arg(Zapis.STREFY[plugin.zakres2000.epsg].strefa)
                .arg(plugin.zakres2000.epsg)
                .arg(Zapis.liczbaWierzcholkow(plugin.zakres2000.polys))
                .arg((plugin.zakres2000.pow / 10000).toFixed(4))
                .arg(plugin.zakres2000.pow.toFixed(0))
          }
        }

        Button {
          Layout.fillWidth: true
          enabled: plugin.zakres2000 !== null
          highlighted: true
          text: qsTr("Zapisz pliki dla ODGiK")
          onClicked: plugin.zapisz()
        }

        Label {
          id: statusZapisu
          Layout.fillWidth: true
          wrapMode: Text.WrapAnywhere
          visible: text !== ""
          color: "#39ff14"
          font.pointSize: 9
        }

        RowLayout {
          Layout.fillWidth: true
          spacing: 8
          visible: plugin.zipWyniku !== ""
          Button {
            Layout.fillWidth: true
            text: qsTr("Udostępnij ZIP")
            onClicked: platformUtilities.sendDatasetTo(plugin.zipWyniku)
          }
          Button {
            Layout.fillWidth: true
            visible: Qt.platform.os !== "android" && Qt.platform.os !== "ios"
            text: qsTr("Otwórz katalog")
            onClicked: Qt.openUrlExternally("file://" + plugin.katalogWyniku)
          }
        }

        Label {
          Layout.fillWidth: true
          wrapMode: Text.WordWrap
          color: "#9e9e9e"
          font.pointSize: 9
          text: qsTr("Wymagania ośrodków się różnią — zwykle wystarcza ZIP albo sam GML/SHP. Do wniosku papierowego: wykaz współrzędnych (TXT) i obraz mapy (PNG). GML: osie północ, wschód; DXF: X = wschód, Y = północ.")
        }
      }
    }
  }
}
