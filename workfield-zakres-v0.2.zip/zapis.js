.pragma library
// WorkField Zakres — zapis zakresu do plików dla ODGiK. Czysty JS, bez Qt:
// te same funkcje są testowane w Node i używane przez main.qml.
//
// Geometria wejściowa: wielokąty w PL-2000, każdy punkt {e: wschód, n: północ}.
//   polys = [ [ ring0, ring1… ], … ]   ring0 = obrys zewnętrzny, dalej otwory
// Pierścienie BEZ powtórzonego punktu zamykającego.

var STREFY = {
  2176: { strefa: 5, cm: 15, fe: 5500000 },
  2177: { strefa: 6, cm: 18, fe: 6500000 },
  2178: { strefa: 7, cm: 21, fe: 7500000 },
  2179: { strefa: 8, cm: 24, fe: 8500000 }
};

function epsgDlaDlugosci(lon) {
  if (lon < 16.5) return 2176;
  if (lon < 19.5) return 2177;
  if (lon < 22.5) return 2178;
  return 2179;
}

function poleRing(r) {
  // dodatnie = przeciwnie do ruchu wskazówek (w układzie e/n)
  var s = 0;
  for (var i = 0; i < r.length; i++) {
    var a = r[i], b = r[(i + 1) % r.length];
    s += a.e * b.n - b.e * a.n;
  }
  return s / 2;
}

function polePowierzchni(polys) {
  var p = 0;
  for (var i = 0; i < polys.length; i++) {
    p += Math.abs(poleRing(polys[i][0]));
    for (var j = 1; j < polys[i].length; j++)
      p -= Math.abs(poleRing(polys[i][j]));
  }
  return p;
}

function liczbaWierzcholkow(polys) {
  var n = 0;
  for (var i = 0; i < polys.length; i++)
    for (var j = 0; j < polys[i].length; j++)
      n += polys[i][j].length;
  return n;
}

// ── WKT -> wielokąty (współrzędne jak w WKT: x, y) ──────────────────────
function parsujWkt(wkt) {
  var t = String(wkt).trim().toUpperCase();
  var multi = t.indexOf("MULTIPOLYGON") === 0;
  if (!multi && t.indexOf("POLYGON") !== 0)
    return null;
  var i = t.indexOf("(");
  if (i < 0)
    return null;
  var pos = i;
  function lista() {
    // pos wskazuje '('
    pos++;
    var wynik = [];
    var tekst = "";
    while (pos < t.length) {
      var c = t[pos];
      if (c === "(") {
        wynik.push(lista());
      } else if (c === ")") {
        pos++;
        if (tekst.trim() !== "")
          wynik.push(tekst);
        return wynik;
      } else if (c === ",") {
        if (tekst.trim() !== "")
          wynik.push(tekst);
        tekst = "";
        pos++;
      } else {
        tekst += c;
        pos++;
      }
    }
    return wynik;
  }
  var drzewo = lista();
  function ring(r) {
    var pkt = [];
    for (var k = 0; k < r.length; k++) {
      var l = String(r[k]).trim().split(/\s+/);
      pkt.push({ x: parseFloat(l[0]), y: parseFloat(l[1]) });
    }
    if (pkt.length > 1 && pkt[0].x === pkt[pkt.length - 1].x && pkt[0].y === pkt[pkt.length - 1].y)
      pkt.pop();
    return pkt;
  }
  var polys = [];
  var surowe = multi ? drzewo : [drzewo];
  for (var a = 0; a < surowe.length; a++) {
    var poly = [];
    for (var b = 0; b < surowe[a].length; b++)
      poly.push(ring(surowe[a][b]));
    if (poly.length > 0 && poly[0].length >= 3)
      polys.push(poly);
  }
  return polys;
}

function f2(v) { return v.toFixed(2); }

function xmlEsc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

// ── GML 3.2 — kolejność osi jak w EPSG: północ, wschód ─────────────────
function gml(polys, epsg, nazwa, powM2) {
  var srs = "urn:ogc:def:crs:EPSG::" + epsg;
  function posList(r) {
    var z = r.concat([r[0]]);
    return z.map(function (p) { return f2(p.n) + " " + f2(p.e); }).join(" ");
  }
  function polygon(p, id) {
    var s = '<gml:Polygon gml:id="' + id + '" srsName="' + srs + '" srsDimension="2">'
      + '<gml:exterior><gml:LinearRing><gml:posList>' + posList(p[0]) + '</gml:posList></gml:LinearRing></gml:exterior>';
    for (var i = 1; i < p.length; i++)
      s += '<gml:interior><gml:LinearRing><gml:posList>' + posList(p[i]) + '</gml:posList></gml:LinearRing></gml:interior>';
    return s + '</gml:Polygon>';
  }
  var geom;
  if (polys.length === 1) {
    geom = polygon(polys[0], "zakres.g0");
  } else {
    geom = '<gml:MultiSurface gml:id="zakres.g" srsName="' + srs + '" srsDimension="2">';
    for (var i = 0; i < polys.length; i++)
      geom += '<gml:surfaceMember>' + polygon(polys[i], "zakres.g" + i) + '</gml:surfaceMember>';
    geom += '</gml:MultiSurface>';
  }
  return '<?xml version="1.0" encoding="UTF-8"?>\n'
    + '<ogr:FeatureCollection gml:id="zakres" xmlns:ogr="http://ogr.maptools.org/" '
    + 'xmlns:gml="http://www.opengis.net/gml/3.2">\n'
    + '  <ogr:featureMember>\n'
    + '    <ogr:zakres gml:id="zakres.0">\n'
    + '      <ogr:geometryProperty>' + geom + '</ogr:geometryProperty>\n'
    + '      <ogr:nazwa>' + xmlEsc(nazwa) + '</ogr:nazwa>\n'
    + '      <ogr:pow_m2>' + f2(powM2) + '</ogr:pow_m2>\n'
    + '    </ogr:zakres>\n'
    + '  </ogr:featureMember>\n'
    + '</ogr:FeatureCollection>\n';
}

// ── DXF R12 — X = wschód, Y = północ (konwencja CAD) ────────────────────
function dxf(polys, nazwa) {
  var L = [];
  function g(kod, war) { L.push(String(kod)); L.push(String(war)); }
  g(0, "SECTION"); g(2, "HEADER");
  g(9, "$ACADVER"); g(1, "AC1009");
  g(9, "$INSUNITS"); g(70, 6);
  g(0, "ENDSEC");
  g(0, "SECTION"); g(2, "TABLES");
  g(0, "TABLE"); g(2, "LAYER"); g(70, 1);
  g(0, "LAYER"); g(2, "ZAKRES"); g(70, 0); g(62, 1); g(6, "CONTINUOUS");
  g(0, "ENDTAB");
  g(0, "ENDSEC");
  g(0, "SECTION"); g(2, "ENTITIES");
  for (var i = 0; i < polys.length; i++) {
    for (var j = 0; j < polys[i].length; j++) {
      var r = polys[i][j];
      g(0, "POLYLINE"); g(8, "ZAKRES"); g(66, 1); g(10, "0.0"); g(20, "0.0"); g(30, "0.0"); g(70, 1);
      for (var k = 0; k < r.length; k++) {
        g(0, "VERTEX"); g(8, "ZAKRES"); g(10, f2(r[k].e)); g(20, f2(r[k].n)); g(30, "0.0");
      }
      g(0, "SEQEND"); g(8, "ZAKRES");
    }
  }
  g(0, "ENDSEC");
  g(0, "EOF");
  return L.join("\r\n") + "\r\n";
}

// ── KML (WGS84) — wymaga funkcji przeliczającej {e,n} -> {lon,lat} ─────
function kml(polysWgs, nazwa, opis) {
  function coords(r) {
    var z = r.concat([r[0]]);
    return z.map(function (p) { return p.lon.toFixed(7) + "," + p.lat.toFixed(7) + ",0"; }).join(" ");
  }
  function polygon(p) {
    var s = "<Polygon><outerBoundaryIs><LinearRing><coordinates>" + coords(p[0]) + "</coordinates></LinearRing></outerBoundaryIs>";
    for (var i = 1; i < p.length; i++)
      s += "<innerBoundaryIs><LinearRing><coordinates>" + coords(p[i]) + "</coordinates></LinearRing></innerBoundaryIs>";
    return s + "</Polygon>";
  }
  var geom = polysWgs.length === 1 ? polygon(polysWgs[0])
    : "<MultiGeometry>" + polysWgs.map(polygon).join("") + "</MultiGeometry>";
  return '<?xml version="1.0" encoding="UTF-8"?>\n'
    + '<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>' + xmlEsc(nazwa) + '</name>\n'
    + '<Style id="z"><LineStyle><color>ff0000ff</color><width>3</width></LineStyle><PolyStyle><color>330000ff</color></PolyStyle></Style>\n'
    + '<Placemark><name>' + xmlEsc(nazwa) + '</name><description>' + xmlEsc(opis) + '</description><styleUrl>#z</styleUrl>\n'
    + geom + '\n</Placemark></Document></kml>\n';
}

// ── TXT — wykaz współrzędnych, zapis geodezyjny (X północ, Y wschód) ────
function txt(polys, epsg, nazwa, powM2, data) {
  var s = STREFY[epsg];
  var L = [];
  L.push("ZAKRES OBSZARU — " + nazwa);
  L.push("Układ współrzędnych: PL-2000, strefa " + s.strefa + " (południk " + s.cm + "°), EPSG:" + epsg);
  L.push("X — współrzędna północna, Y — współrzędna wschodnia (zapis geodezyjny), metry");
  L.push("Powierzchnia: " + f2(powM2) + " m² = " + (powM2 / 10000).toFixed(4) + " ha");
  L.push("Sporządzono: " + data + " (WorkFieldGIS)");
  L.push("");
  var nr = 1;
  for (var i = 0; i < polys.length; i++) {
    for (var j = 0; j < polys[i].length; j++) {
      var tytul = polys.length > 1 ? "Część " + (i + 1) : "Obrys";
      if (j > 0) tytul += " — otwór " + j;
      L.push(tytul + ":");
      L.push("Nr\tX [m]\tY [m]");
      var r = polys[i][j];
      for (var k = 0; k < r.length; k++)
        L.push((nr++) + "\t" + f2(r[k].n) + "\t" + f2(r[k].e));
      L.push("");
    }
  }
  return L.join("\r\n");
}

// ── SHP / SHX / DBF / PRJ / CPG ─────────────────────────────────────────
function prj(epsg) {
  var s = STREFY[epsg];
  return 'PROJCS["ETRF2000-PL_CS2000_' + s.cm + '",GEOGCS["GCS_ETRF2000-PL",DATUM["D_ETRF2000_Poland",'
    + 'SPHEROID["GRS_1980",6378137.0,298.257222101]],PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]],'
    + 'PROJECTION["Transverse_Mercator"],PARAMETER["False_Easting",' + s.fe + '.0],PARAMETER["False_Northing",0.0],'
    + 'PARAMETER["Central_Meridian",' + s.cm + '.0],PARAMETER["Scale_Factor",0.999923],'
    + 'PARAMETER["Latitude_Of_Origin",0.0],UNIT["Meter",1.0]]';
}

function utf8(s) {
  var u = unescape(encodeURIComponent(s));
  var a = new Uint8Array(u.length);
  for (var i = 0; i < u.length; i++) a[i] = u.charCodeAt(i);
  return a;
}

// Zwraca { shp: ArrayBuffer, shx: ArrayBuffer, dbf: ArrayBuffer }
function shp(polys, nazwa, powM2) {
  // pierścienie: zewnętrzny zgodnie z ruchem wskazówek, otwory przeciwnie
  var czesci = [];
  for (var i = 0; i < polys.length; i++) {
    for (var j = 0; j < polys[i].length; j++) {
      var r = polys[i][j].slice();
      var cw = poleRing(r) < 0;
      if ((j === 0 && !cw) || (j > 0 && cw))
        r.reverse();
      r.push(r[0]);
      czesci.push(r);
    }
  }
  var npkt = 0;
  var xmin = Infinity, ymin = Infinity, xmax = -Infinity, ymax = -Infinity;
  czesci.forEach(function (r) {
    npkt += r.length;
    r.forEach(function (p) {
      xmin = Math.min(xmin, p.e); xmax = Math.max(xmax, p.e);
      ymin = Math.min(ymin, p.n); ymax = Math.max(ymax, p.n);
    });
  });
  var tresc = 4 + 32 + 4 + 4 + 4 * czesci.length + 16 * npkt; // bajty treści rekordu
  var dlShp = 100 + 8 + tresc;
  var b = new ArrayBuffer(dlShp);
  var v = new DataView(b);
  function naglowek(dv, dlugoscBajtow) {
    dv.setInt32(0, 9994, false);
    dv.setInt32(24, dlugoscBajtow / 2, false);
    dv.setInt32(28, 1000, true);
    dv.setInt32(32, 5, true);
    dv.setFloat64(36, xmin, true); dv.setFloat64(44, ymin, true);
    dv.setFloat64(52, xmax, true); dv.setFloat64(60, ymax, true);
  }
  naglowek(v, dlShp);
  var o = 100;
  v.setInt32(o, 1, false); v.setInt32(o + 4, tresc / 2, false); o += 8;
  v.setInt32(o, 5, true); o += 4;
  v.setFloat64(o, xmin, true); v.setFloat64(o + 8, ymin, true);
  v.setFloat64(o + 16, xmax, true); v.setFloat64(o + 24, ymax, true); o += 32;
  v.setInt32(o, czesci.length, true); v.setInt32(o + 4, npkt, true); o += 8;
  var start = 0;
  for (var c = 0; c < czesci.length; c++) { v.setInt32(o, start, true); o += 4; start += czesci[c].length; }
  czesci.forEach(function (r) {
    r.forEach(function (p) { v.setFloat64(o, p.e, true); v.setFloat64(o + 8, p.n, true); o += 16; });
  });

  var bx = new ArrayBuffer(108);
  var vx = new DataView(bx);
  naglowek(vx, 108);
  vx.setInt32(100, 50, false);
  vx.setInt32(104, tresc / 2, false);

  // DBF: NAZWA C(100), POW_M2 N(15,2)
  var pola = [{ n: "NAZWA", t: "C", d: 100, p: 0 }, { n: "POW_M2", t: "N", d: 15, p: 2 }];
  var dlRek = 1 + pola.reduce(function (s, f) { return s + f.d; }, 0);
  var dlNagl = 32 + 32 * pola.length + 1;
  var bd = new ArrayBuffer(dlNagl + dlRek + 1);
  var u8 = new Uint8Array(bd);
  var vd = new DataView(bd);
  var teraz = new Date();
  u8[0] = 3; u8[1] = teraz.getFullYear() - 1900; u8[2] = teraz.getMonth() + 1; u8[3] = teraz.getDate();
  vd.setInt32(4, 1, true); vd.setInt16(8, dlNagl, true); vd.setInt16(10, dlRek, true);
  u8[29] = 0; // kodowanie w .cpg
  for (var f = 0; f < pola.length; f++) {
    var base = 32 + 32 * f;
    for (var q = 0; q < pola[f].n.length; q++) u8[base + q] = pola[f].n.charCodeAt(q);
    u8[base + 11] = pola[f].t.charCodeAt(0);
    u8[base + 16] = pola[f].d; u8[base + 17] = pola[f].p;
  }
  u8[dlNagl - 1] = 0x0D;
  var r0 = dlNagl;
  u8[r0] = 0x20;
  var nb = utf8(String(nazwa));
  var naz = new Uint8Array(100);
  for (var z = 0; z < 100; z++) naz[z] = 0x20;
  // przycinamy do 100 bajtów bez rozcinania znaku UTF-8
  var ile = Math.min(nb.length, 100);
  while (ile > 0 && ile < nb.length && (nb[ile] & 0xC0) === 0x80) ile--;
  for (z = 0; z < ile; z++) naz[z] = nb[z];
  u8.set(naz, r0 + 1);
  var pw = f2(powM2);
  while (pw.length < 15) pw = " " + pw;
  for (z = 0; z < 15; z++) u8[r0 + 101 + z] = pw.charCodeAt(z);
  u8[dlNagl + dlRek] = 0x1A;
  return { shp: b, shx: bx, dbf: bd };
}

// ── ZIP (bez kompresji) — jeden plik do maila i do wniosku ──────────────
var _crcT = null;
function crc32(u8) {
  if (!_crcT) {
    _crcT = [];
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      _crcT.push(c >>> 0);
    }
  }
  var crc = 0xFFFFFFFF;
  for (var i = 0; i < u8.length; i++) crc = _crcT[(crc ^ u8[i]) & 0xFF] ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

// pliki: [{ nazwa, dane: Uint8Array }]
function zip(pliki) {
  var czesci = [], centralne = [], off = 0;
  var d = new Date();
  var czas = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  var data = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  pliki.forEach(function (p) {
    var nb = utf8(p.nazwa), crc = crc32(p.dane), n = p.dane.length;
    var h = new DataView(new ArrayBuffer(30));
    h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true);
    h.setUint16(8, 0, true); h.setUint16(10, czas, true); h.setUint16(12, data, true);
    h.setUint32(14, crc, true); h.setUint32(18, n, true); h.setUint32(22, n, true);
    h.setUint16(26, nb.length, true); h.setUint16(28, 0, true);
    czesci.push(new Uint8Array(h.buffer), nb, p.dane);
    var c = new DataView(new ArrayBuffer(46));
    c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true);
    c.setUint16(8, 0x0800, true); c.setUint16(10, 0, true); c.setUint16(12, czas, true); c.setUint16(14, data, true);
    c.setUint32(16, crc, true); c.setUint32(20, n, true); c.setUint32(24, n, true);
    c.setUint16(28, nb.length, true); c.setUint32(42, off, true);
    centralne.push(new Uint8Array(c.buffer), nb);
    off += 30 + nb.length + n;
  });
  var dlC = centralne.reduce(function (s, a) { return s + a.length; }, 0);
  var e = new DataView(new ArrayBuffer(22));
  e.setUint32(0, 0x06054b50, true); e.setUint16(8, pliki.length, true); e.setUint16(10, pliki.length, true);
  e.setUint32(12, dlC, true); e.setUint32(16, off, true);
  var wszystko = czesci.concat(centralne, [new Uint8Array(e.buffer)]);
  var dl = wszystko.reduce(function (s, a) { return s + a.length; }, 0);
  var wynik = new Uint8Array(dl), o = 0;
  wszystko.forEach(function (a) { wynik.set(a, o); o += a.length; });
  return wynik;
}
