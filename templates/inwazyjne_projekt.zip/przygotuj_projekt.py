# -*- coding: utf-8 -*-
"""
Sklada projekt terenowy WorkField pod inwentaryzacje gatunkow inwazyjnych.

UZYCIE (w QGIS):
    Wtyczki -> Konsola Pythona -> ikona "Uruchom skrypt" -> wskaz ten plik.
Skrypt dziala na katalogu, w ktorym lezy (tam gdzie inwazyjne.gpkg).

Powstaje: projekt.qgz z warstwa inwazyjnych, ortofotomapa GUGiK jako podklad,
formularz z lista gatunkow i ukrytymi polami metryczki.
"""
import os

from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsRasterLayer,
    QgsCoordinateReferenceSystem,
    QgsEditorWidgetSetup,
    QgsDefaultValue,
    QgsMarkerSymbol,
    QgsField,
)

KATALOG = os.path.dirname(os.path.abspath(__file__))
GPKG = os.path.join(KATALOG, 'inwazyjne.gpkg')
WYNIK = os.path.join(KATALOG, 'projekt.qgz')

# Lista do uzupelnienia wedlug potrzeb - to tylko punkt wyjscia.
GATUNKI = [
    'barszcz Sosnowskiego',
    'barszcz Mantegazziego',
    'rdestowiec ostrokonczysty',
    'rdestowiec sachalinski',
    'rdestowiec posredni',
    'nawloc kanadyjska',
    'nawloc pozna',
    'niecierpek gruczolowaty',
    'niecierpek drobnokwiatowy',
    'kolczurka klapowana',
    'klon jesionolistny',
    'czeremcha amerykanska',
    'robinia akacjowa',
    'dab czerwony',
    'winobluszcz zaroslowy',
    'slonecznik bulwiasty',
    'rudbekia naga',
    'inny (opisz w uwagach)',
]

LICZEBNOSC = ['pojedyncze', 'kilka', 'kilkanascie', 'platy', 'lan']
FAZA = ['wegetatywna', 'kwitnienie', 'owocowanie', 'po sezonie']

# Pola metryczki wypelniane automatycznie przez aplikacje - w formularzu tylko do odczytu
METRYCZKA = ['metoda', 'azymut', 'odleglosc_m', 'obs_x', 'obs_y', 'kat_przeciecia', 'foto', 'ujecie']


def lista_wartosci(wartosci):
    """Konfiguracja widzetu 'Mapa wartosci' dla podanej listy."""
    return QgsEditorWidgetSetup('ValueMap', {'map': [{w: w} for w in wartosci]})


def main():
    if not os.path.exists(GPKG):
        raise SystemExit('Brak %s - skrypt musi lezec obok GeoPackage.' % GPKG)

    projekt = QgsProject.instance()
    projekt.clear()
    projekt.setCrs(QgsCoordinateReferenceSystem('EPSG:2178'))
    projekt.setTitle('Gatunki inwazyjne')

    # --- podklad: ortofotomapa GUGiK (WMTS, standardowa rozdzielczosc)
    orto_url = ('type=xyz&url=https://mapy.geoportal.gov.pl/wss/service/PZGIK/ORTO/WMTS/'
                'StandardResolution?service%3DWMTS%26request%3DGetTile%26version%3D1.0.0'
                '%26layer%3DORTOFOTOMAPA%26style%3Ddefault%26format%3Dimage/jpeg'
                '%26tileMatrixSet%3DEPSG:3857%26tileMatrix%3DEPSG:3857:{z}'
                '%26tileRow%3D{y}%26tileCol%3D{x}&zmax=19&zmin=0')
    orto = QgsRasterLayer(orto_url, 'Ortofotomapa GUGiK', 'wms')
    if orto.isValid():
        projekt.addMapLayer(orto)
    else:
        print('UWAGA: podklad GUGiK nie wstal - dodaj go recznie.')

    # --- warstwa robocza
    warstwa = QgsVectorLayer('%s|layername=inwazyjne' % GPKG, 'inwazyjne', 'ogr')
    if not warstwa.isValid():
        raise SystemExit('Nie udalo sie wczytac warstwy z GeoPackage.')

    # symbol: czerwone kolo, widoczne na ortofoto
    symbol = QgsMarkerSymbol.createSimple({
        'name': 'circle',
        'color': '229,28,35,180',
        'outline_color': '255,255,255,255',
        'outline_width': '0.4',
        'size': '3.4',
    })
    warstwa.renderer().setSymbol(symbol)

    pola = warstwa.fields()
    ustaw = warstwa.setEditorWidgetSetup

    ustaw(pola.indexOf('gatunek'), lista_wartosci(GATUNKI))
    ustaw(pola.indexOf('liczebnosc'), lista_wartosci(LICZEBNOSC))
    ustaw(pola.indexOf('faza'), lista_wartosci(FAZA))
    ustaw(pola.indexOf('pokrycie_proc'), QgsEditorWidgetSetup('Range', {
        'Min': 0, 'Max': 100, 'Step': 5, 'Style': 'SpinBox'}))
    ustaw(pola.indexOf('uwagi'), QgsEditorWidgetSetup('TextEdit', {'IsMultiline': True}))
    ustaw(pola.indexOf('foto'), QgsEditorWidgetSetup('ExternalResource', {
        'RelativeStorage': 1,             # sciezka wzgledna wobec projektu
        'StorageMode': 0,
        'DocumentViewer': 1,              # podglad obrazu w formularzu
        'DocumentViewerHeight': 260,
    }))

    # metryczka: widoczna, ale nie do recznej edycji
    konfig = warstwa.editFormConfig()
    for nazwa in METRYCZKA:
        i = pola.indexOf(nazwa)
        if i >= 0:
            konfig.setReadOnly(i, True)
    warstwa.setEditFormConfig(konfig)

    # wartosci domyslne wypelniane przy tworzeniu obiektu
    i = pola.indexOf('data_czas')
    if i >= 0:
        warstwa.setDefaultValueDefinition(i, QgsDefaultValue("format_date(now(), 'yyyy-MM-dd HH:mm')"))
    i = pola.indexOf('autor')
    if i >= 0:
        warstwa.setDefaultValueDefinition(i, QgsDefaultValue("@obiekt_autor"))

    projekt.addMapLayer(warstwa)

    # zmienna projektu - podpis terenowy, do zmiany w Wlasciwosciach projektu
    projekt.setCustomVariables({'obiekt_autor': 'inwazje'})

    projekt.write(WYNIK)
    print('Zapisano:', WYNIK)
    print('Warstwa:', warstwa.name(), '| pol:', len(pola), '| CRS:', warstwa.crs().authid())
    print('\nDalej: skopiuj CALY katalog na telefon i otworz projekt w WorkField.')


main()
