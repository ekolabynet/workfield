# Projekt terenowy: gatunki inwazyjne

Zawartość katalogu:

- `inwazyjne.gpkg` — pusta warstwa punktowa (EPSG:2178) z kompletem pól,
  w tym metryczką trybu odległego (`metoda`, `azymut`, `odleglosc_m`,
  `obs_x`, `obs_y`, `kat_przeciecia`).
- `przygotuj_projekt.py` — skrypt PyQGIS, który składa `projekt.qgz`:
  podkład ortofotomapy GUGiK, styl warstwy, formularz z listą gatunków,
  pola metryczki jako tylko do odczytu.
- `workfield_klawisze.json` — definicja klawisza `IN` w pasku szybkiego zapisu
  i presety odległości (25/50/100/200 m).

## Jak złożyć projekt

1. Otwórz QGIS → Wtyczki → Konsola Pythona → „Uruchom skrypt" → wskaż
   `przygotuj_projekt.py`. Skrypt działa na katalogu, w którym leży.
2. Otwórz powstały `projekt.qgz`, sprawdź wzrokowo podkład i warstwę,
   uzupełnij listę gatunków (Właściwości warstwy → Atrybuty → `gatunek`).
3. Zmienna projektu `obiekt_autor` (Właściwości projektu → Zmienne) trafia
   do pola `autor` — ustaw na osobę, która będzie zbierać dane.

## Przekazanie w teren

Skopiuj **cały katalog** (z `.gpkg`, `.qgz` i `workfield_klawisze.json`) do
pamięci telefonu, w miejsce widoczne dla WorkFielda. Aplikacja po otwarciu
projektu sama wczyta definicję klawisza `IN` — bez żadnej konfiguracji na miejscu.

Zdjęcia zapisują się w podkatalogu `DCIM` obok projektu, a ścieżki w polu `foto`
są względne, więc katalog można kopiować w całości bez rozjeżdżania się odnośników.
