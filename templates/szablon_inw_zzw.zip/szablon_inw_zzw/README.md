# Szablon WorkFieldGIS — Inwentaryzacja botaniczna ZZW

## Instalacja szablonu

1. Uruchom `zbuduj_projekt.py` w QGIS (Wtyczki → Konsola Pythona → Pokaż edytor
   → otwórz plik → Uruchom). Powstanie `projekt.qgs` obok `dane.gpkg`.
2. Otwórz `projekt.qgs` w QGIS, sprawdź formularze, zapisz.
3. Skopiuj **cały ten katalog** do `templates/` w katalogu danych WorkFieldGIS
   na telefonie.
4. W aplikacji: prawa szuflada → Projekty → **Nowy projekt z szablonu**.

## Przyciski paska szybkiego przechwytywania

Pojawiają się automatycznie, bo projekt zawiera warstwy o rozpoznanych nazwach:

| Przycisk | Warstwa w projekcie | Tabela w GPKG |
|---|---|---|
| zalążek płatu | `platy_zalazki` | `FITO_ZALAZKI` |
| gatunek | `gatunki` | `FITO_SPIS_GATUNKOWY` |
| zdjęcie fitosocjologiczne | `zdjecia_fito` | `FITO_ZDJECIA` |

**Tych trzech nazw nie wolno zmieniać.** Nazwy tabel w GeoPackage pozostają
zgodne z metodyką (`FITO_*`) — rozjazd jest celowy.

Jeśli przyciski się nie pojawią, pasek dopasowuje prawdopodobnie nazwę tabeli,
nie nazwę warstwy. Wtedy w `zbuduj_projekt.py` zamień listę `WARSTWY` tak,
by nazwa projektu równała się nazwie tabeli, albo zmień nazwy tabel w GPKG.

## Przed wydaniem zespołowi

- [ ] Na każdym telefonie ustaw zmienną projektu `wykonawca` (Projekt →
      Właściwości → Zmienne). Domyślnie jest `Imię Nazwisko`.
- [ ] Potwierdź `id_obiektu` — teraz `592`, wartość tymczasowa.
- [ ] Pobierz podkład ortofoto do trybu offline.
- [ ] Sprawdź na telefonie, czy formularz nie zacina się przy wyborze gatunku
      (słownik ma 2824 pozycje).

## Zakładki formularza płatu

1. **Płat** — identyfikacja i klasyfikacja (wypełniane zawsze)
2. **Ściółka** — ukryta dla roślinności wodnej i naskalnej
3. **Gleba** — ukryta, dopóki `BADANO_PROFIL` ≠ TAK
4. **Ślady** — dżdżownice, krety, buchtowanie, artefakty
5. **Dokumentacja** — zdjęcie, zaburzenie, uwagi
6. **Gatunki** — lista powiązanych obserwacji

## Przepływ terenowy

| Sytuacja | Działanie |
|---|---|
| płat już wydzielony | otwórz poligon, wypełnij formularz |
| nowa granica | narysuj linię w `ciecia` (na wylot!) |
| nowy płat | przycisk „zalążek" → punkt + opis |
| spis gatunkowy | przycisk „gatunek", powtarzaj w pętli |
| zdjęcie fitosocjologiczne | przycisk „zdjęcie" + Tabela 7 |

Wieczorem w QGIS: *Podziel liniami* → złączenie przestrzenne przenosi opisy
z zalążków → nadanie `ID_PŁATU` → oznacz zalążki i cięcia jako `PRZETWORZONE`.
