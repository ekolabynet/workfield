# Szablon: szybkie obserwacje

Uniwersalny notatnik terenowy. Trzy warstwy o tej samej logice — różnią się
tylko geometrią.

| Warstwa | Geometria | Zastosowanie |
|---|---|---|
| `obserwacje` | punkt | pojedyncze stanowisko, drzewo, znalezisko |
| `obserwacje_linie` | linia | ścieżka, rów, szpaler, granica liniowa |
| `obserwacje_obszary` | poligon | wydzielenie, płat, teren o wspólnej cesze |

Pola: `nazwa`, `notatka`, `foto`, `data_czas`, `dokladnosc_m`
(punkty dodatkowo `kategoria`). Czas i dokładność GPS wypełniają się same.

## Praca w terenie

1. Wybierz warstwę na pasku szybkiego przechwytywania.
2. Punkt: stań w miejscu i naciśnij przycisk (pozycja z GNSS).
   Linia/obszar: rysuj po mapie lub idź i zbieraj wierzchołki.
3. Uzupełnij `nazwa` i `notatka`, zrób zdjęcie — trafi do `DCIM/`.

## Wskazówki

- **`kategoria`** to twoja własna klasyfikacja — ustal ją z zespołem przed
  wyjazdem, żeby dane dało się później grupować.
- Pole `dokladnosc_m` to zapis jakości GNSS w chwili pomiaru. Przy ≥ 5 m nie
  ufaj położeniu przy obiektach mniejszych niż kilka metrów.
- Ten szablon nie ma słownika gatunków — jeśli inwentaryzujesz roślinność,
  użyj `szablon_obs_roslinnosc` albo `szablon_inw_zzw`.
