Szablon WorkField — inwentaryzacja dendrologiczna

Zbudowany 16.08.2026 skryptem zbuduj_szablon_dendro.py, uruchamianym bezokiennie z basha. Wzorzec pól pochodzi z realnego zbioru „APPL LS Adamowizna 2026-06-11" (eksport z Mapit Spatial, EPSG:2178).

Warstwy
Warstwa	Tabela	Geometria	Rola
drzewa	DEN_DRZEWA	POINT Z	inwentarz pojedynczych drzew i krzewów
grupy	DEN_GRUPY	MULTIPOLYGON	skupiny, żywopłoty, zadrzewienia
uwagi	DEN_UWAGI	POINT	luźne spostrzeżenia
tyczenie	DEN_TYCZENIE	POINT	warstwa robocza dla kafla bez zdjęcia
zasieg	DEN_ZASIEG	MULTIPOLYGON	granica opracowania, tylko do odczytu
taksony	TAKSONY	tabela	słownik gatunków + próg zezwolenia

Plus ZAL_DRZEWA, ZAL_GRUPY, ZAL_UWAGI — załączniki N:1 od pierwszej sekundy, wraz z relacjami i zakładką w formularzu.

Kafle paska: D (drzewa), G (grupy), U (uwagi), T (tyczenie, "zdjecie": false).

Decyzje wynikające z metody (OpenVTA) — nie zmieniać bez potrzeby.

Opis stanu drzewa powstaje metodą tagów: operator wpisuje skrót, a klawiatura predykcyjna (Gboard) rozwija go w pełną frazę. Proza jest produktem końcowym — rekord opuszcza teren w formie finalnej, a schemat kowariat definiuje się przy odczycie, nie przy zapisie.

Stąd trzy rzeczy, które w szablonie wyglądają „nieporządnie", a są celowe:

UWAGI to zwykłe pole tekstowe bez słowników i bez generatora zdania. Aplikacja nigdy go nie przetwarza. Rozwijanie skrótów należy do klawiatury.
GATUNEK jest tekstem, nie listą wyboru — też bywa wpisywany skrótem. Zgodność ze słownikiem sprawdza ograniczenie miękkie: ostrzega, nie blokuje. Spację doklejaną przez Gboard przycina parser w biurze.
Oba pola obwodów są tekstowe. Niosą trzy stany naraz: pomiar (74), wartość cenzurowaną (>65) i wielopień (60+36), a przy krzewach powierzchnię (>25m2). Rozbicie ich wymuszałoby w terenie decyzję, której metoda świadomie nie wymusza. Parsowanie należy do odczytu.

Warunek techniczny, sprawdzony w kodzie: WorkField nie wyłącza tekstu predykcyjnego (TextEdit.qml:86 → Qt.ImhNone), więc słownik Gboarda ma prawo działać w polu uwag. ImhNoPredictiveText występuje tylko przy polach liczbowych (Range.qml).

Nazwy kolumn

Kolumny mają nazwy techniczne (OBW_5, OBW_130, KORONA_SZER, NR_INW), a pełne opisy z pliku źródłowego idą jako aliasy — w formularzu i na wydruku widać opis, w wyrażeniach i skryptach krótką nazwę. Mapowanie na nagłówki oczekiwane przez odbiorcę należy do eksportu.

Pola pochodne i metadane
SZEROKOSC_M — we wzorcowym zbiorze to dokładnie ćwiartka szerokości korony (sprawdzone na 25 rekordach, bez wyjątku). Liczy je wyrażenie round("KORONA_SZER"/4.0, 1) przy każdej edycji; pole ukryte w formularzu.
Metadane RTK ograniczone do trzech: RTK_DOKL, RTK_KAT, RTK_SAT (w oryginale było osiemnaście kolumn GNSS, wszystkie puste). Pułapka: @position_* wypełnia się TYLKO przy zamrożonej pozycji, @gnss_* zawsze (expressioncontextutils.cpp:27-33). Wartości domyślne korzystają z @gnss_horizontal_accuracy, @gnss_number_of_used_satellites i @gnss_imu_pitch.
PROG_CM w słowniku taksonów — ustawowy próg obwodu na wys. 5 cm, powyżej którego wycinka wymaga zezwolenia (80 dla topoli, wierzb, klonu jesionolistnego i srebrzystego, 65 dla kasztanowca, robinii i platanu, 50 dla pozostałych). Do wykorzystania przy kontroli pola OBW_5.
Pułapka z kaflami paska

QfQuickCaptureBar.loadDefinitions() czyta klucze etykieta, warstwa, kolor, zdjecie, opcjonalnie rozmiar. Trybu ani podpowiedzi NIE podaje się — pasek wylicza je z typu geometrii. Klucz nazwa zamiast etykieta daje w logu „definicje z pliku, 0 klawiszy".

Kafel z "zdjecie": false na warstwie punktowej odblokowuje trzy tryby naraz (captureInto, l. 1114-1130): punkt bez uruchamiania aparatu, serię wierzchołków pod długim przytrzymaniem i dokładanie wierzchołków z GNSS do rysowanej geometrii. Bez niego nie obejdziesz obrysu grupy pieszo. Przełączniki KTW i ODL nie mają własnej warstwy — zapisują do warstwy tapniętego kafla.

Do zrobienia
Wypełnić TAKSONY — dopóki tabela jest pusta, podpowiadanie nazwy polskiej i kontrola gatunku nie mają z czego działać (nie blokują zapisu). Kandydat na źródło: wf_wskazniki.gpkg.
Podkład DXF — szablon nie zna ścieżki do mapy zasadniczej; dokładany ręcznie przy pierwszym zadaniu. Do rozstrzygnięcia, czy zostaje DXF-em, czy magazyn konwertuje go do GPKG przy wydaniu (wydajność na telefonie).
Parser opisów — wersjonowany schemat odczytu (rdzeń → cecha / rola / strefa / sloty), po stronie biura, obok konwersja_do_szablonu.py.
Eksport do układu odbiorcy — mapowanie kolumn technicznych na pełne nagłówki, w tym składanie 60+36 z tabeli pomiarów, gdyby kiedyś powstała.
