# -*- coding: utf-8 -*-
"""
Budowa projektu szablonu WorkFieldGIS - Inwentaryzacja botaniczna ZZW.

URUCHOMIENIE:
  QGIS -> Wtyczki -> Konsola Pythona -> ikona "Pokaż edytor" -> otwórz ten plik -> Uruchom

Skrypt tworzy projekt.qgs obok dane.gpkg w tym samym katalogu.
Nazwy warstw (platy_zalazki / zdjecia_fito / gatunki) są rozpoznawane
przez pasek szybkiego przechwytywania WorkFieldGIS - NIE ZMIENIAĆ.
"""
import os
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsEditorWidgetSetup, QgsDefaultValue,
    QgsFieldConstraints, QgsAttributeEditorContainer, QgsAttributeEditorField,
    QgsEditFormConfig, QgsOptionalExpression, QgsExpression, QgsRelation,
    QgsCoordinateReferenceSystem, QgsAttributeEditorRelation,
)

KAT = os.path.dirname(os.path.abspath(__file__))

# Plik danych: 'dane.gpkg' albo pierwszy .gpkg w katalogu skryptu.
GPKG = os.path.join(KAT, 'dane.gpkg')
if not os.path.exists(GPKG):
    kandydaci = [f for f in sorted(os.listdir(KAT)) if f.lower().endswith('.gpkg')]
    if not kandydaci:
        raise RuntimeError('Brak pliku .gpkg w katalogu: ' + KAT)
    GPKG = os.path.join(KAT, kandydaci[0])
QGS = os.path.splitext(GPKG)[0] + '.qgs' if os.path.basename(GPKG) != 'dane.gpkg' \
      else os.path.join(KAT, 'projekt.qgs')
print('Dane :', GPKG)
print('Projekt:', QGS)

# nazwa w projekcie -> tabela w GeoPackage
WARSTWY = [
    ('toposektory',    'FITO_TOPOSEKTORY'),
    ('platy',          'FITO_PLATY'),
    ('platy_zalazki',  'FITO_ZALAZKI'),      # <- przycisk paska
    ('gatunki',        'FITO_SPIS_GATUNKOWY'),  # <- przycisk paska
    ('zdjecia_fito',   'FITO_ZDJECIA'),      # <- przycisk paska
    ('ciecia',         'FITO_CIECIA'),
    ('slownik',        'SLOWNIK_GATUNKOW'),
]

# ----------------------------------------------------------------- słowniki
MAPA = lambda d: QgsEditorWidgetSetup('ValueMap', {'map': [{k: v} for k, v in d]})
TAKNIE = MAPA([('tak', 'TAK'), ('nie', 'NIE')])

TYP_FIZ = MAPA([
    ('D - drzewiasta', 'D'), ('K - krzewiasta', 'K'), ('Z - ziołoroślowa', 'Z'),
    ('L - łąkowa i murawowa', 'L'), ('N - nietrwała zielna', 'N'),
    ('W - wodna i przywodna', 'W'), ('S - naskalna', 'S'), ('M - mozaikowa', 'M'),
])
SPONT = MAPA([('U - urządzona', 'U'), ('S - spontaniczna', 'S')])
FORMA_ROSL = MAPA([(k, k) for k in [
    'RDU', 'RDS', 'RKS', 'RKU', 'RZS', 'RZU', 'RLS', 'RLU', 'RNS',
    'RNU', 'RWS', 'RWU', 'RSS', 'RSU', 'RMU', 'RMS']])
WILG = MAPA([('sucha', 'sucha'), ('świeża', 'świeża'), ('wilgotna', 'wilgotna')])
SKALA_015 = MAPA([('0 - brak', '0'), ('1 - niska', '1'),
                  ('3 - średnia', '3'), ('5 - wysoka', '5')])
ZAGESZCZ = MAPA([('1 - bardzo niskie', '1'), ('2 - niskie', '2'),
                 ('3 - średnie', '3'), ('4 - wysokie', '4'),
                 ('5 - bardzo wysokie', '5')])
ROZKLAD = MAPA([('0 - nierozłożona', '0'), ('1 - słabo', '1'),
                ('3 - średnio', '3'), ('5 - silnie', '5')])
WARSTWA_AB = MAPA([('A - drzewa', 'A'), ('B - krzewy', 'B'),
                   ('C - runo', 'C'), ('D - mszaki', 'D')])
SKUPISK = MAPA([('1 - równomierne', '1'), ('3 - umiarkowanie skupiskowe', '3'),
                ('5 - całkowicie skupiskowe', '5')])
ZABURZ = MAPA([('brak', 'brak'), ('koszenie', 'koszenie'),
               ('grabienie', 'grabienie'), ('wycinka', 'wycinka'),
               ('roboty ziemne', 'roboty ziemne'), ('wydeptywanie', 'wydeptywanie')])
TYP_GRAN = MAPA([('fizjonomiczna', 'fizjonomiczna'), ('siedliskowa', 'siedliskowa'),
                 ('antropogeniczna', 'antropogeniczna'), ('pielęgnacyjna', 'pielęgnacyjna')])
STATUS_Z = MAPA([('nowy płat', 'nowy'), ('podział', 'podział'), ('scalenie', 'scalenie')])
UKRYTY = QgsEditorWidgetSetup('Hidden', {})
FOTO = QgsEditorWidgetSetup('ExternalResource', {
    'DocumentViewer': 1, 'RelativeStorage': 1, 'StorageMode': 0,
    'FileWidget': True, 'FileWidgetButton': True,
})

# ------------------------------------------------------------------ pomocnicze
# --- samonaprawa schematu: brakujące kolumny tekstowe ---
WYMAGANE = {
    'FITO_PLATY':   ['BADANO_PROFIL', 'ID_PŁATU_MACIERZYSTEGO',
                     'ZABURZENIE', 'DATA_ZABURZENIA', 'FOTO'],
    'FITO_ZALAZKI': ['BADANO_PROFIL', 'ID_PŁATU_MACIERZYSTEGO',
                     'ZABURZENIE', 'DATA_ZABURZENIA', 'FOTO',
                     'ID_PŁATU_ROBOCZY', 'STATUS_ZALAZKA', 'PRZETWORZONE'],
    'FITO_SPIS_GATUNKOWY': ['WARSTWA', 'URZĄDZONA', 'PO_ZABURZENIU',
                            'WERYFIKACJA', 'ZAPIS_SUROWY', 'FOTO'],
    'FITO_ZDJECIA': ['FOTO', 'DIAGNOZA_SYNTAKSON'],
    'FITO_CIECIA':  ['PRZETWORZONE', 'PEWNOSC', 'TYP_GRANICY'],
}
import sqlite3
_con = sqlite3.connect(GPKG)
for _tab, _pola in WYMAGANE.items():
    try:
        _ist = [r[1] for r in _con.execute('PRAGMA table_info("%s")' % _tab)]
    except sqlite3.OperationalError:
        continue
    if not _ist:
        continue
    for _p in _pola:
        if _p not in _ist:
            _con.execute('ALTER TABLE "%s" ADD COLUMN "%s" TEXT' % (_tab, _p))
            print('  dodano kolumnę %s.%s' % (_tab, _p))
_con.commit()
_con.close()

proj = QgsProject.instance()
proj.clear()
proj.setCrs(QgsCoordinateReferenceSystem('EPSG:2178'))
L = {}

for nazwa, tabela in WARSTWY:
    uri = '{}|layername={}'.format(GPKG, tabela)
    lyr = QgsVectorLayer(uri, nazwa, 'ogr')
    if not lyr.isValid():
        raise RuntimeError('Nie wczytano warstwy: ' + tabela)
    proj.addMapLayer(lyr)
    L[nazwa] = lyr

# warstwy podkładowe REF_* (jeśli są) - tylko do dociągania, bez formularzy
for tabela, etykieta in [('REF_wydzielenia', 'podklad_wydzielenia'),
                         ('REF_zadrzewienia', 'podklad_zadrzewienia')]:
    ref = QgsVectorLayer('{}|layername={}'.format(GPKG, tabela), etykieta, 'ogr')
    if ref.isValid():
        ref.setReadOnly(True)
        proj.addMapLayer(ref)
        L[etykieta] = ref
        print('podkład:', tabela)

BRAKI = []

def idx(lyr, pole, wymagane=True):
    i = lyr.fields().indexOf(pole)
    if i < 0:
        wpis = '{}.{}'.format(lyr.name(), pole)
        if wpis not in BRAKI:
            BRAKI.append(wpis)
        if wymagane:
            raise KeyError(wpis)
    return i

def widget(lyr, pole, setup):
    i = idx(lyr, pole, False)
    if i >= 0:
        lyr.setEditorWidgetSetup(i, setup)

def domyslna(lyr, pole, wyr, przy_aktualizacji=False):
    i = idx(lyr, pole, False)
    if i >= 0:
        lyr.setDefaultValueDefinition(i, QgsDefaultValue(wyr, przy_aktualizacji))

def ograniczenie(lyr, pole, wyr, opis, twarde=False):
    i = idx(lyr, pole, False)
    if i < 0:
        return
    lyr.setConstraintExpression(i, wyr, opis)
    lyr.setFieldConstraint(
        i, QgsFieldConstraints.ConstraintExpression,
        QgsFieldConstraints.ConstraintStrengthHard if twarde
        else QgsFieldConstraints.ConstraintStrengthSoft)

def alias(lyr, pole, tekst):
    i = idx(lyr, pole, False)
    if i >= 0:
        lyr.setFieldAlias(i, tekst)

# ============================================================ PŁATY / ZALĄŻKI
DZIEDZICZ_TS = ("overlay_intersects('toposektory', \"ID_TOPOSEKTORA\", limit:=1)[0]")

def konfiguruj_platy(lyr, zalazek=False):
    for p in ['ID_OBIEKTU', 'FORMA_POKRYCIA', 'ID_TOPOSEKTORA']:
        widget(lyr, p, UKRYTY)
    if not zalazek:
        widget(lyr, 'POWIERZCHNIA_M2', UKRYTY)
        widget(lyr, 'ZAPIS_SUROWY_GATUNKI', UKRYTY)
        domyslna(lyr, 'POWIERZCHNIA_M2', 'round($area, 2)', True)

    domyslna(lyr, 'ID_OBIEKTU', "@id_obiektu")
    domyslna(lyr, 'FORMA_POKRYCIA', "'R'")
    domyslna(lyr, 'ID_TOPOSEKTORA', DZIEDZICZ_TS)
    domyslna(lyr, 'DATA_WIZJI_LOKALNEJ', "format_date(now(),'yyyy-MM-dd')")
    domyslna(lyr, 'WYKONAWCA', "@wykonawca")

    widget(lyr, 'TYP_FIZJONOMICZNY', TYP_FIZ)
    widget(lyr, 'SPONTANICZNOŚĆ', SPONT)
    widget(lyr, 'FORMA_ROŚLINNOŚCI', FORMA_ROSL)
    widget(lyr, 'AKTUALNA_WILGOTNOŚĆ_GLEBY', WILG)
    widget(lyr, 'ZAGĘSZCZENIE_GLEBY', ZAGESZCZ)
    widget(lyr, 'STAN_ROZŁOŻENIA_ŚCIÓŁKI', ROZKLAD)
    widget(lyr, 'AKTYWNOŚĆ_DŻDŻOWNIC', SKALA_015)
    widget(lyr, 'AKTYWNOŚĆ_KRETÓW', SKALA_015)
    widget(lyr, 'ZABURZENIE', ZABURZ)
    widget(lyr, 'BADANO_PROFIL', TAKNIE)
    for p in ['ANTRIK', 'HORTIK', 'HISTIK', 'MURSZIK', 'ARTEFAKTY',
              'MEMBRANA', 'ŚLADY_ROBÓT_ZIEMNYCH']:
        widget(lyr, p, TAKNIE)
    widget(lyr, 'FOTO', FOTO)
    domyslna(lyr, 'FOTO',
             "'DCIM/' || coalesce(\"ID_PŁATU\",'PLAT') || '_' "
             "|| format_date(now(),'yyyyMMdd_HHmm') || '.jpg'")

    # podpowiedź formy roślinności z typu + spontaniczności
    domyslna(lyr, 'FORMA_ROŚLINNOŚCI',
             "CASE WHEN \"TYP_FIZJONOMICZNY\" IS NULL OR \"SPONTANICZNOŚĆ\" IS NULL "
             "THEN NULL ELSE 'R' || \"TYP_FIZJONOMICZNY\" || \"SPONTANICZNOŚĆ\" END")

    ograniczenie(lyr, 'POKRYCIE_ŚCIÓŁKĄ',
                 '"POKRYCIE_ŚCIÓŁKĄ" IS NULL OR ("POKRYCIE_ŚCIÓŁKĄ" BETWEEN 0 AND 100)',
                 'Zakres 0-100%')
    ograniczenie(lyr, 'BUCHTOWANIE',
                 '"BUCHTOWANIE" IS NULL OR ("BUCHTOWANIE" BETWEEN 0 AND 100)',
                 'Zakres 0-100%')

    alias(lyr, 'BADANO_PROFIL', 'Czy badano profil glebowy?')
    alias(lyr, 'POKRYCIE_ŚCIÓŁKĄ', 'Pokrycie ściółką [%]')
    alias(lyr, 'ŚREDNIA_GRUBOŚĆ_ŚCIÓŁKI', 'Grubość ściółki [cm]')
    alias(lyr, 'ZAWARTOŚĆ_CZĘŚCI_ORGANICZNYCH', 'Części organiczne [%]')
    alias(lyr, 'BUCHTOWANIE', 'Buchtowanie [%]')

    # ---- formularz: zakładki
    cfg = lyr.editFormConfig()
    cfg.setLayout(QgsEditFormConfig.TabLayout)
    root = cfg.invisibleRootContainer()
    root.clear()

    def zakladka(tytul, pola, warunek=None):
        k = QgsAttributeEditorContainer(tytul, root)
        k.setIsGroupBox(False)
        for p in pola:
            j = idx(lyr, p, False)
            if j >= 0:
                k.addChildElement(QgsAttributeEditorField(p, j, k))
        if warunek:
            k.setVisibilityExpression(QgsOptionalExpression(QgsExpression(warunek), True))
        root.addChildElement(k)
        return k

    pola1 = (['ID_PŁATU_ROBOCZY', 'STATUS_ZALAZKA'] if zalazek else []) + [
        'ID_PŁATU', 'NAZWA_PŁATU', 'TYP_FIZJONOMICZNY', 'SPONTANICZNOŚĆ',
        'FORMA_ROŚLINNOŚCI', 'OPIS_PŁATU', 'BADANO_PROFIL']
    zakladka('1. Płat', pola1)
    zakladka('2. Ściółka',
             ['POKRYCIE_ŚCIÓŁKĄ', 'ŚREDNIA_GRUBOŚĆ_ŚCIÓŁKI', 'STAN_ROZŁOŻENIA_ŚCIÓŁKI'],
             '"TYP_FIZJONOMICZNY" IS NULL OR "TYP_FIZJONOMICZNY" NOT IN (\'W\',\'S\')')
    zakladka('3. Gleba',
             ['ZAGĘSZCZENIE_GLEBY', 'AKTUALNA_WILGOTNOŚĆ_GLEBY',
              'ZAWARTOŚĆ_CZĘŚCI_ORGANICZNYCH', 'ANTRIK', 'HORTIK', 'HISTIK',
              'MURSZIK', 'MEMBRANA'],
             '"BADANO_PROFIL" = \'TAK\'')
    zakladka('4. Ślady',
             ['AKTYWNOŚĆ_DŻDŻOWNIC', 'AKTYWNOŚĆ_KRETÓW', 'BUCHTOWANIE',
              'ARTEFAKTY', 'ŚLADY_ROBÓT_ZIEMNYCH'])
    zakladka('5. Dokumentacja',
             ['FOTO', 'ZABURZENIE', 'DATA_ZABURZENIA',
              'ID_PŁATU_MACIERZYSTEGO', 'UWAGI', 'WYKONAWCA', 'DATA_WIZJI_LOKALNEJ'])
    lyr.setEditFormConfig(cfg)

konfiguruj_platy(L['platy'], zalazek=False)
konfiguruj_platy(L['platy_zalazki'], zalazek=True)
widget(L['platy_zalazki'], 'PRZETWORZONE', TAKNIE)
domyslna(L['platy_zalazki'], 'PRZETWORZONE', "'NIE'")
domyslna(L['platy_zalazki'], 'STATUS_ZALAZKA', "'nowy'")

L['platy'].setDisplayExpression(
    '"ID_PŁATU" || \' - \' || coalesce("NAZWA_PŁATU",\'bez opisu\') '
    '|| \' - \' || round($area) || \' m2\'')
L['platy_zalazki'].setDisplayExpression(
    'coalesce("ID_PŁATU_ROBOCZY","ID_PŁATU",\'zalążek\')')

# ==================================================================== GATUNKI
g = L['gatunki']
for p in ['ID_OBIEKTU']:
    widget(g, p, UKRYTY)
domyslna(g, 'ID_OBIEKTU', "@id_obiektu")
domyslna(g, 'DATA_WIZJI_LOKALNEJ', "format_date(now(),'yyyy-MM-dd')")
domyslna(g, 'WYKONAWCA', "@wykonawca")
domyslna(g, 'ID_PŁATU', "overlay_intersects('platy', \"ID_PŁATU\", limit:=1)[0]")
domyslna(g, 'ID_OBSERWACJI',
         "coalesce(\"ID_PŁATU\",'X') || '_' || format_date(now(),'yyyyMMdd_HHmmss')")

widget(g, 'GATUNEK', QgsEditorWidgetSetup('ValueRelation', {
    'Layer': L['slownik'].id(), 'LayerName': 'slownik',
    'LayerSource': L['slownik'].source(), 'LayerProviderName': 'ogr',
    'Key': 'GATUNEK', 'Value': 'ETYKIETA',
    'AllowNull': True, 'OrderByValue': True, 'UseCompleter': True,
    'NofColumns': 1, 'AllowMulti': False,
}))
widget(g, 'WARSTWA', WARSTWA_AB)
widget(g, 'SKUPISKOWOŚĆ', SKUPISK)
widget(g, 'URZĄDZONA', TAKNIE)
widget(g, 'PO_ZABURZENIU', TAKNIE)
widget(g, 'FOTO', FOTO)
domyslna(g, 'FOTO',
         "'DCIM/' || coalesce(\"ID_PŁATU\",'PLAT') || '_gat_' "
         "|| format_date(now(),'yyyyMMdd_HHmm') || '.jpg'")

ograniczenie(g, 'POKRYCIE_PROCENT',
             '"POKRYCIE_PROCENT" IS NULL OR ("POKRYCIE_PROCENT" > 0 '
             'AND "POKRYCIE_PROCENT" <= 100)', 'Zakres 1-100%')
ograniczenie(g, 'GATUNEK',
             '"GATUNEK" IS NULL OR array_length(array_agg("GATUNEK", '
             'layer:=\'slownik\', filter:="GATUNEK" = attribute(@parent,\'GATUNEK\'))) > 0',
             'Gatunek spoza słownika - sprawdź pisownię')

cfg = g.editFormConfig()
cfg.setLayout(QgsEditFormConfig.TabLayout)
root = cfg.invisibleRootContainer()
root.clear()
k = QgsAttributeEditorContainer('Obserwacja', root)
for p in ['GATUNEK', 'WARSTWA', 'POKRYCIE_PROCENT', 'SKUPISKOWOŚĆ']:
    j = idx(g, p, False)
    if j >= 0:
        k.addChildElement(QgsAttributeEditorField(p, j, k))
root.addChildElement(k)
k2 = QgsAttributeEditorContainer('Szczegóły', root)
for p in ['ID_PŁATU', 'URZĄDZONA', 'PO_ZABURZENIU', 'FOTO', 'UWAGI',
          'WYKONAWCA', 'DATA_WIZJI_LOKALNEJ']:
    j = idx(g, p, False)
    if j >= 0:
        k2.addChildElement(QgsAttributeEditorField(p, j, k2))
root.addChildElement(k2)
g.setEditFormConfig(cfg)
g.setDisplayExpression('"GATUNEK" || \' \' || coalesce("WARSTWA",\'\') '
                       '|| coalesce("POKRYCIE_PROCENT",\'\')')

# ============================================================== ZDJĘCIA FITO
z = L['zdjecia_fito']
widget(z, 'ID_OBIEKTU', UKRYTY)
domyslna(z, 'ID_OBIEKTU', "@id_obiektu")
domyslna(z, 'ID_PŁATU', "overlay_intersects('platy', \"ID_PŁATU\", limit:=1)[0]")
domyslna(z, 'DATA', "format_date(now(),'yyyy-MM-dd')")
domyslna(z, 'WYKONAWCA', "@wykonawca")
domyslna(z, 'KSZTAŁT', "'koło'")
domyslna(z, 'NR_ZDJĘCIA',
         "coalesce(\"ID_PŁATU\",'X') || '_' || format_date(now(),'HHmm')")
widget(z, 'KSZTAŁT', MAPA([('koło', 'koło'), ('kwadrat', 'kwadrat'),
                           ('prostokąt', 'prostokąt'), ('nieregularny', 'nieregularny')]))
widget(z, 'FOTO', FOTO)
for p in ['POKRYCIE_A', 'POKRYCIE_B', 'POKRYCIE_C', 'POKRYCIE_D']:
    ograniczenie(z, p, '"{0}" IS NULL OR ("{0}" BETWEEN 0 AND 100)'.format(p),
                 'Zakres 0-100%')
z.setDisplayExpression('"NR_ZDJĘCIA"')

# =================================================================== CIĘCIA
c = L['ciecia']
widget(c, 'ID_OBIEKTU', UKRYTY)
domyslna(c, 'ID_OBIEKTU', "@id_obiektu")
domyslna(c, 'ID_TOPOSEKTORA', DZIEDZICZ_TS)
domyslna(c, 'DATA', "format_date(now(),'yyyy-MM-dd')")
domyslna(c, 'WYKONAWCA', "@wykonawca")
domyslna(c, 'ID_CIECIA', "format_date(now(),'yyyyMMdd_HHmmss')")
domyslna(c, 'PRZETWORZONE', "'NIE'")
widget(c, 'TYP_GRANICY', TYP_GRAN)
widget(c, 'PRZETWORZONE', TAKNIE)
widget(c, 'PEWNOSC', MAPA([('pewna', 'pewna'), ('do weryfikacji', 'do weryfikacji')]))
c.setDisplayExpression('"ID_CIECIA"')

# ================================================== relacja płat -> gatunki
rel = QgsRelation()
rel.setId('platy_gatunki')
rel.setName('Gatunki w płacie')
rel.setReferencedLayer(L['platy'].id())
rel.setReferencingLayer(L['gatunki'].id())
rel.addFieldPair('ID_PŁATU', 'ID_PŁATU')
if rel.isValid():
    proj.relationManager().addRelation(rel)
    cfg = L['platy'].editFormConfig()
    root = cfg.invisibleRootContainer()
    kr = QgsAttributeEditorContainer('6. Gatunki', root)
    kr.addChildElement(QgsAttributeEditorRelation(rel.id(), kr))
    root.addChildElement(kr)
    L['platy'].setEditFormConfig(cfg)
else:
    print('UWAGA: relacja płat->gatunki nieprawidłowa, pomijam')

# ============================================================ zmienne, zapis
from qgis.core import QgsExpressionContextUtils as ECU

# ID_OBIEKTU i NAZWA_OBIEKTU czytane z warstwy toposektorów - bez edycji skryptu
id_obiektu, nazwa_obiektu = 0, 'Obiekt'
ts = L['toposektory']
for f in ts.getFeatures():
    if f['ID_OBIEKTU']:
        id_obiektu = int(f['ID_OBIEKTU'])
        nazwa_obiektu = f['NAZWA_OBIEKTU'] or nazwa_obiektu
        break
if not id_obiektu:
    print('UWAGA: nie odczytano ID_OBIEKTU z FITO_TOPOSEKTORY - ustaw ręcznie '
          'w Projekt > Właściwości > Zmienne')
print('Obiekt: %s (%s)' % (nazwa_obiektu, id_obiektu))

ECU.setProjectVariable(proj, 'wykonawca', 'Imię Nazwisko')
ECU.setProjectVariable(proj, 'id_obiektu', id_obiektu)
ECU.setProjectVariable(proj, 'nazwa_obiektu', nazwa_obiektu)

if BRAKI:
    print('POMINIĘTO (brak pól w danych):')
    for b in BRAKI:
        print('   ', b)

proj.setTitle('Inwentaryzacja botaniczna ZZW - ' + str(nazwa_obiektu))
proj.write(QGS)
print('ZAPISANO:', QGS)
print('Warstwy:', ', '.join(l.name() for l in proj.mapLayers().values()))
