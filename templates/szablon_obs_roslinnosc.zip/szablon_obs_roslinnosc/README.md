# Szablon: obserwacje roślinności

Uproszczony obieg fitosocjologiczny: od zalążka płatu, przez wydzielenie
granic, po spis gatunków i zdjęcie fitosocjologiczne.

| Warstwa | Geometria | Rola |
|---|---|---|
| `platy_zalazki` | punkt | „tu jest coś ciekawego" — szybki znacznik z GPS |
| `platy` | poligon | granice płatu, `zbiorowisko` |
| `gatunki` | punkt | spis: `gatunek`, `ilosciowosc`, powiązanie przez `nr_platu` |
| `zdjecia_fito` | punkt | zdjęcie fitosocjologiczne: `nr_zdjecia`, `powierzchnia_m2` |

## Kolejność pracy

1. **Zalążek** — idąc w teren zaznaczasz punkty wymagające opisu (jeden przycisk).
2. **Płat** — obrysowujesz granice, nadajesz `nr_platu`.
3. **Gatunki** — dla danego `nr_platu` dopisujesz kolejne gatunki
   z ilościowością.
4. **Zdjęcie fito** — jeśli metodyka wymaga zdjęcia z określonej powierzchni.

**`nr_platu` spina wszystko.** Wpisuj go konsekwentnie — bez niego spis
gatunkowy nie przypisze się do płatu.

## Zdjęcia i tagowanie

Fotografuj każdy płat i wątpliwe gatunki. Po powrocie: galeria → 🏷 →
przypisz gatunek do zdjęcia (podpowiedzi biorą się z pola `gatunek` w tym
projekcie). Do jednego zdjęcia przypisuj **gatunek główny**, nie wszystko,
co majaczy w tle.
