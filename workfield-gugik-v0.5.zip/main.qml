import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import Theme

/**
 * WorkField GUGiK — pobieranie obiektów z usług GUGiK.
 *
 * Wersja 0.2: diagnostyka na stdout + Test połączenia. ULDK — działka (lub budynek) pod palcem.
 *   tapnięcie w ikonę  → włącza/wyłącza tryb pobierania (ikona świeci na zielono),
 *   tapnięcie w mapę   → pobiera obiekt z ULDK do warstwy REF_dzialki / REF_budynki,
 *   przytrzymanie ikony → ustawienia.
 *
 * Docelowo: pozostałe usługi GUGiK (WFS BDOT10k/KIEG, NMT, ortofoto) — szkielet
 * `zrodla` niżej jest przygotowany pod dokładanie kolejnych pozycji.
 *
 * Diagnostyka: wszystko leci do logu z prefiksem "GUGIK:" (grep "GUGIK:").
 */
Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property var pointHandler: iface.findItemByObjectName("pointHandler")
  // Elementy interfejsu, których tapnięcia NIE wolno przechwycić — inaczej
  // przy włączonym trybie nie da się dotknąć własnej ikony, żeby go wyłączyć.
  // (qgismobileapp.qml woła pointHandler.clicked() PRZED sprawdzeniem pasków.)
  property var pasekWtyczek: iface.findItemByObjectName("pluginsToolbar")
  property var wyszukiwarka: iface.findItemByObjectName("locatorItem")

  readonly property string nazwaObslugi: "workfield_gugik_uldk"
  // MapCanvasPointHandler.Priority.High == 100 (enum niedostępny z wtyczki)
  readonly property int priorytetWysoki: 100

  readonly property string uldkBaza: "https://uldk.gugik.gov.pl/"
  readonly property string sridUldk: "2180"

  property bool uzbrojony: false
  property bool zajety: false
  property string ostatniSurowy: ""

  // ------------------------------------------------------------------ źródła
  // Jedno miejsce na definicje rodzajów obiektów. Dodanie budynków wymagało
  // tylko jednej pozycji na tej liście — tak samo pójdą kolejne usługi.
  readonly property var zrodla: [
    {
      klucz: "dzialka",
      etykieta: qsTr("działki"),
      zapytanie: "GetParcelByXY",
      warstwa: "REF_dzialki",
      // kolejność MUSI się zgadzać z listą `result` w URL-u
      atrybuty: ["teryt", "parcel", "region", "commune", "county", "voivodeship"],
      pola: [
        { name: "ID_DZIALKI", type: "text" },
        { name: "NR_DZIALKI", type: "text" },
        { name: "OBREB", type: "text" },
        { name: "GMINA", type: "text" },
        { name: "POWIAT", type: "text" },
        { name: "WOJEWODZTWO", type: "text" },
        { name: "POW_M2", type: "real" },
        { name: "POBRANO", type: "text" },
        { name: "ZRODLO", type: "text" },
        { name: "SUROWE", type: "text" }
      ],
      poleId: "ID_DZIALKI",
      poleEtykiety: "NR_DZIALKI"
    },
    {
      klucz: "budynek",
      etykieta: qsTr("budynki"),
      zapytanie: "GetBuildingByXY",
      warstwa: "REF_budynki",
      atrybuty: ["teryt", "function", "region", "commune", "county", "voivodeship"],
      pola: [
        { name: "ID_BUDYNKU", type: "text" },
        { name: "FUNKCJA", type: "text" },
        { name: "OBREB", type: "text" },
        { name: "GMINA", type: "text" },
        { name: "POWIAT", type: "text" },
        { name: "WOJEWODZTWO", type: "text" },
        { name: "POW_M2", type: "real" },
        { name: "POBRANO", type: "text" },
        { name: "ZRODLO", type: "text" },
        { name: "SUROWE", type: "text" }
      ],
      poleId: "ID_BUDYNKU",
      poleEtykiety: "FUNKCJA"
    }
  ]

  function zrodloBiezace() {
    for (var i = 0; i < zrodla.length; i++)
      if (zrodla[i].klucz === ustawienia.rodzaj)
        return zrodla[i];
    return zrodla[0];
  }

  Settings {
    id: ustawienia
    category: "WorkFieldGUGiK"
    property string rodzaj: "dzialka"
    //! PUSTE = baza projektu (`dane.gpkg`). Nazwa pliku = osobny plik
    //! obok projektu, jak do v0.2. Puste jest domyslne, bo osobny plik
    //! trzeba pamietac przy kazdym wydaniu, szablonie i zwrocie.
    property string plikGpkg: ""
    property bool zapiszProjekt: true
    property bool etykiety: true
    property bool jedenStrzal: false // wyłącz tryb po pierwszym udanym pobraniu
    // Kolejność osi w zapytaniu, ustalona doświadczalnie przy pierwszym udanym
    // pobraniu i zapamiętana — patrz komentarz przy funkcji pobierz().
    property bool osieOdwrotne: false
  }

  // ------------------------------------------------------------- pasek/ikona
  Component.onCompleted: {
    iface.addItemToPluginsToolbar(przyciskWtyczki);
    log("wtyczka wczytana, obsługa tapnięć: " + (pointHandler ? "znaleziona" : "BRAK"));
  }

  Component.onDestruction: {
    if (uzbrojony)
      rozbroj();
  }

  QfToolButton {
    id: przyciskWtyczki
    iconSource: 'icon.svg'
    iconColor: plugin.uzbrojony ? "#39ff14" : "#FB8C00"
    bgcolor: plugin.uzbrojony ? "#1b5e20" : Theme.darkGray
    round: true
    onClicked: {
      if (plugin.uzbrojony)
        plugin.rozbroj();
      else
        plugin.uzbroj();
    }
    onPressAndHold: okno.open()
  }

  // ------------------------------------------------------------ tryb tapnięć
  function uzbroj() {
    if (!pointHandler) {
      toast(qsTr("Nie znalazłem obsługi tapnięć mapy — tryb niedostępny."));
      return;
    }
    var ok = pointHandler.registerHandler(nazwaObslugi, function (point, type, interactionType) {
      if (interactionType !== "clicked")
        return false;
      if (plugin.wInterfejsie(point))
        return false;
      if (plugin.zajety) {
        plugin.toast(qsTr("Czekam na odpowiedź ULDK…"));
        return true;
      }
      plugin.pobierzDlaPunktuEkranu(point);
      return true;
    }, priorytetWysoki);
    if (!ok) {
      // handler o tej nazwie już istnieje (np. po nieczystym przeładowaniu)
      pointHandler.deregisterHandler(nazwaObslugi);
      toast(qsTr("Tryb był już włączony — wyłączam. Dotknij ikonę ponownie."));
      return;
    }
    uzbrojony = true;
    log("tryb ULDK WŁĄCZONY, rodzaj: " + ustawienia.rodzaj);
    toast(qsTr("ULDK: dotknij mapy, aby pobrać %1.").arg(zrodloBiezace().etykieta));
  }

  //! Czy tapnięcie trafiło w interfejs, a nie w mapę?
  function wInterfejsie(point) {
    if (!pointHandler)
      return false;
    if (pasekWtyczek && pointHandler.pointInItem(point, pasekWtyczek))
      return true;
    if (wyszukiwarka && pointHandler.pointInItem(point, wyszukiwarka))
      return true;
    return false;
  }

  function rozbroj() {
    if (pointHandler)
      pointHandler.deregisterHandler(nazwaObslugi);
    uzbrojony = false;
    log("tryb ULDK wyłączony");
  }

  // ------------------------------------------------------------------- ULDK
  function pobierzDlaPunktuEkranu(point) {
    var ms = null;
    try {
      ms = iface.mapCanvas().mapSettings;
    } catch (e) {
    }
    if (!ms) {
      toast(qsTr("Nie mam dostępu do mapy."));
      return;
    }

    var wMapie = ms.screenToCoordinate(point);
    var crs2180 = CoordinateReferenceSystemUtils.fromDescription("EPSG:" + sridUldk);
    var p = GeometryUtils.reprojectPoint(wMapie, ms.destinationCrs, crs2180);
    if (!p || isNaN(p.x) || isNaN(p.y)) {
      toast(qsTr("Nie umiem przeliczyć punktu na PUWG 1992."));
      return;
    }

    pobierz(p.x, p.y, ms, ustawienia.osieOdwrotne);
  }

  function urlUldk(zr, x, y) {
    return uldkBaza + "?request=" + zr.zapytanie + "&xy=" + x.toFixed(2) + "," + y.toFixed(2) + "&srid=" + sridUldk + "&result=" + zr.atrybuty.join(",") + ",geom_wkt";
  }

  /**
   * \a odwrotnie — zapytanie z zamienionymi X/Y.
   *
   * Kolejność osi w PUWG 1992 to klasyczna pułapka: w konwencji geodezyjnej
   * X to północ, w QGIS/PROJ x to wschód. Dokumentacja ULDK mówi „kolejność
   * zgodna z reprezentacją WKT dla wybranego układu", co nie rozstrzyga sprawy
   * na tyle, żeby na tym oprzeć zapis danych terenowych. Dlatego nie zgadujemy:
   * pytamy, sprawdzamy czy zwrócony obrys naprawdę obejmuje miejsce tapnięcia,
   * a jeśli nie — pytamy raz jeszcze na odwrót. Kolejność, która zadziałała,
   * zostaje zapamiętana w ustawieniach, więc kolejne tapnięcia idą od razu
   * dobrą drogą (jedno zapytanie, nie dwa).
   */
  function pobierz(x, y, ms, odwrotnie) {
    var zr = zrodloBiezace();
    var url = urlUldk(zr, odwrotnie ? y : x, odwrotnie ? x : y);
    zajety = true;
    log("pytam (osie " + (odwrotnie ? "odwrotne" : "wprost") + "): " + url);

    var xhr = new XMLHttpRequest();
    xhr.open("GET", url);
    xhr.timeout = 25000;
    xhr.ontimeout = function () {
      plugin.zajety = false;
      plugin.toast(qsTr("ULDK nie odpowiedziało w 25 s — sprawdź zasięg."));
      plugin.log("timeout");
    };
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== XMLHttpRequest.DONE)
        return;
      plugin.zajety = false;
      if (xhr.status !== 200) {
        plugin.toast(xhr.status === 0 ? qsTr("Brak odpowiedzi ULDK (status 0) — sieć, TLS albo blokada. Sprawdź „Test połączenia\" w ustawieniach wtyczki.") : qsTr("ULDK odpowiedziało błędem %1 — szczegóły w oknie wtyczki.").arg(xhr.status));
        plugin.ostatniSurowy = "status " + xhr.status + " (" + xhr.statusText + ")\n" + String(xhr.responseText);
        plugin.log("BŁĄD status=" + xhr.status + " statusText=" + xhr.statusText + " treść: " + String(xhr.responseText).substring(0, 300));
        return;
      }
      plugin.ostatniSurowy = String(xhr.responseText);
      plugin.przetworz(plugin.ostatniSurowy, ms, x, y, odwrotnie);
    };
    xhr.send();
  }

  /**
   * Dwie sondy, żeby jednym tapnięciem rozdzielić dwie różne awarie:
   *  A) najprostsze możliwe zapytanie (działka po identyfikatorze, bez żadnych
   *     dodatkowych parametrów) — sprawdza samo POŁĄCZENIE z usługą,
   *  B) nasze pełne zapytanie po współrzędnych ze środka mapy — sprawdza NASZE
   *     PARAMETRY.
   * A pada → problem z siecią/TLS/blokadą, nie z wtyczką.
   * A przechodzi, B pada → wina naszych parametrów i widać, których.
   */
  function testPolaczenia() {
    ostatniSurowy = qsTr("Testuję…");
    sonda(qsTr("A. połączenie (GetParcelById, bez parametrów)"), uldkBaza + "?request=GetParcelById&id=141201_1.0001.6509", function () {
      var ms = null;
      try {
        ms = iface.mapCanvas().mapSettings;
      } catch (e) {
      }
      if (!ms) {
        ostatniSurowy += "\n\n" + qsTr("B. pominięta — brak dostępu do mapy.");
        return;
      }
      var crs2180 = CoordinateReferenceSystemUtils.fromDescription("EPSG:" + sridUldk);
      var p = GeometryUtils.reprojectPoint(ms.center, ms.destinationCrs, crs2180);
      var url = urlUldk(zrodloBiezace(), p.x, p.y);
      sonda(qsTr("B. nasze zapytanie (środek mapy)"), url, null);
    });
  }

  function sonda(nazwa, url, potem) {
    log("SONDA " + nazwa + " → " + url);
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url);
    xhr.timeout = 25000;
    xhr.ontimeout = function () {
      plugin.dopiszWynikSondy(nazwa, url, qsTr("BRAK ODPOWIEDZI w 25 s (timeout)"));
      if (potem)
        potem();
    };
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== XMLHttpRequest.DONE)
        return;
      var opis = "status " + xhr.status + " (" + xhr.statusText + "), " + String(xhr.responseText).length + " zn.\n" + String(xhr.responseText).substring(0, 600);
      plugin.dopiszWynikSondy(nazwa, url, opis);
      if (potem)
        potem();
    };
    xhr.send();
  }

  function dopiszWynikSondy(nazwa, url, opis) {
    if (ostatniSurowy === qsTr("Testuję…"))
      ostatniSurowy = "";
    ostatniSurowy += (ostatniSurowy === "" ? "" : "\n\n") + "── " + nazwa + " ──\n" + url + "\n" + opis;
    log("SONDA " + nazwa + " ⇒ " + opis.replace(/\n/g, " | ").substring(0, 300));
  }

  function przetworz(tekst, ms, x, y, odwrotnie) {
    var zr = zrodloBiezace();
    log("odpowiedź (" + tekst.length + " zn.): " + tekst.substring(0, 160).replace(/\n/g, "\\n"));

    var linie = tekst.split(/\r?\n/);
    var dane = "";
    for (var i = 0; i < linie.length; i++) {
      if (linie[i].indexOf("|") >= 0) {
        dane = linie[i];
        break;
      }
    }

    if (dane === "") {
      var pierwsza = (linie.length > 0 ? linie[0] : "").trim();
      if (pierwsza.indexOf("-1") === 0 || pierwsza === "0") {
        if (odwrotnie === ustawienia.osieOdwrotne) {
          log("brak wyniku — próbuję z zamienioną kolejnością osi");
          pobierz(x, y, ms, !odwrotnie);
          return;
        }
        toast(qsTr("ULDK nie zna tu %1 (poza zasięgiem usługi?).").arg(zr.etykieta));
        return;
      }
      toast(qsTr("Nie rozumiem odpowiedzi ULDK — szczegóły w oknie wtyczki."));
      return;
    }

    var pola = dane.split("|");
    if (pola.length < 2) {
      toast(qsTr("Odpowiedź ULDK bez geometrii."));
      return;
    }

    // Nie polegamy na tym, że ULDK zwróci pola w kolejności z parametru
    // `result` — geometrię rozpoznajemy po treści, identyfikator po wzorcu
    // TERYT, a cały wiersz zapisujemy w polu SUROWE. Gdyby usługa kiedyś
    // przestawiła kolumny, w danych nadal będzie wszystko, co przyszło.
    var iGeom = -1;
    for (var g = pola.length - 1; g >= 0; g--) {
      if (wygladaNaGeometrie(pola[g].trim())) {
        iGeom = g;
        break;
      }
    }
    if (iGeom < 0) {
      toast(qsTr("W odpowiedzi ULDK nie znalazłem geometrii."));
      log("brak geometrii w wierszu: " + dane.substring(0, 200));
      return;
    }

    var wielokaty = null;
    try {
      var surowaGeom = pola[iGeom].trim();
      wielokaty = /^[0-9a-fA-F]+$/.test(surowaGeom) ? wielokatyZHexWkb(surowaGeom) : pierscienieZWkt(surowaGeom);
    } catch (e) {
      log("błąd geometrii: " + e);
      toast(qsTr("Nie umiem odczytać geometrii z ULDK: ") + e);
      return;
    }
    if (!wielokaty || wielokaty.length === 0) {
      toast(qsTr("Puste obrysy w odpowiedzi ULDK."));
      return;
    }

    // Kontrola PO fakcie, nie z deklaracji: czy zwrócony obrys naprawdę obejmuje
    // miejsce tapnięcia? Liczymy to sami, na współrzędnych PUWG 1992, jeszcze
    // przed przeliczeniem do układu mapy — jeden warunek zamiast trzech założeń.
    if (!punktWWielokatach(wielokaty, x, y, 3.0)) {
      if (odwrotnie === ustawienia.osieOdwrotne) {
        log("obrys nie obejmuje tapnięcia — próbuję z zamienioną kolejnością osi");
        pobierz(x, y, ms, !odwrotnie);
        return;
      }
      toast(qsTr("ULDK zwróciło obiekt z innego miejsca — nic nie zapisuję. Szczegóły w oknie wtyczki."));
      log("ODRZUCONE: obrys nie obejmuje tapnięcia przy obu kolejnościach osi");
      return;
    }

    if (odwrotnie !== ustawienia.osieOdwrotne) {
      ustawienia.osieOdwrotne = odwrotnie;
      log("zapamiętuję kolejność osi: " + (odwrotnie ? "odwrotna (Y,X)" : "wprost (X,Y)"));
    }

    var wkt = wktZWielokatow(wielokaty);
    var geom2180 = GeometryUtils.createGeometryFromWkt(wkt);
    if (!geom2180) {
      toast(qsTr("QGIS nie przyjął geometrii z ULDK."));
      log("odrzucony WKT: " + wkt.substring(0, 200));
      return;
    }

    var crs2180 = CoordinateReferenceSystemUtils.fromDescription("EPSG:" + sridUldk);
    var geom = GeometryUtils.reprojectGeometry(geom2180, crs2180, ms.destinationCrs);

    var powierzchnia = powierzchniaWielokatow(wielokaty);
    var opisy = opisyZPol(pola, iGeom);
    // W polu SUROWE zapisujemy atrybuty bez geometrii — geometria jest już
    // w geometrii obiektu, a jej hex potrafi mieć dziesiątki kilobajtów.
    zapisz(zr, opisy, opisy.join("|"), geom, powierzchnia, ms);
  }

  function wygladaNaGeometrie(t) {
    if (t.length < 20)
      return false;
    if (/^(SRID\s*=|POLYGON|MULTIPOLYGON)/i.test(t))
      return true;
    return /^[0-9a-fA-F]+$/.test(t);
  }

  //! Wszystkie pola poza geometrią, w kolejności otrzymanej z usługi.
  function opisyZPol(pola, iGeom) {
    var wynik = [];
    for (var i = 0; i < pola.length; i++) {
      if (i === iGeom)
        continue;
      wynik.push(pola[i].trim());
    }
    return wynik;
  }

  //! Identyfikator: pole wyglądające na TERYT (np. 022503_5.0003.134), inaczej pierwsze.
  function identyfikatorZOpisow(opisy) {
    for (var i = 0; i < opisy.length; i++) {
      if (/^\d{6}_\d+\.\d+/.test(opisy[i]))
        return opisy[i];
    }
    return opisy.length > 0 ? opisy[0] : "";
  }

  // ---------------------------------------------------------------- zapis
  function zapisz(zr, opisy, surowyWiersz, geom, powierzchnia, ms) {
    var warstwa = warstwaDocelowa(zr, ms);
    if (!warstwa) {
      toast(qsTr("Nie udało się przygotować warstwy %1 — szczegóły w logu.").arg(zr.warstwa));
      return;
    }

    var identyfikator = identyfikatorZOpisow(opisy);
    if (identyfikator !== "" && juzJest(warstwa, zr.poleId, identyfikator)) {
      toast(qsTr("%1 %2 już jest w warstwie.").arg(zr.etykieta).arg(identyfikator));
      return;
    }

    var obiekt = FeatureUtils.createBlankFeature(warstwa.fields, geom);
    ustawPole(warstwa, obiekt, zr.poleId, identyfikator);

    // pozostałe opisy trafiają po kolei w pozostałe kolumny opisowe
    var kolumny = [];
    var i;
    for (i = 1; i < zr.atrybuty.length; i++)
      kolumny.push(zr.pola[i].name);
    var pozostale = [];
    for (i = 0; i < opisy.length; i++) {
      if (opisy[i] !== identyfikator)
        pozostale.push(opisy[i]);
    }
    for (i = 0; i < kolumny.length && i < pozostale.length; i++)
      ustawPole(warstwa, obiekt, kolumny[i], pozostale[i]);

    ustawPole(warstwa, obiekt, "SUROWE", surowyWiersz);
    ustawPole(warstwa, obiekt, "POW_M2", Math.round(powierzchnia * 100) / 100);
    ustawPole(warstwa, obiekt, "POBRANO", teraz());
    ustawPole(warstwa, obiekt, "ZRODLO", "ULDK GUGiK");

    warstwa.startEditing();
    var dodane = LayerUtils.addFeature(warstwa, obiekt);
    var zapisane = warstwa.commitChanges();

    // Kontrola PO fakcie, nie z wartości zwracanych: czy obiekt naprawdę jest
    // w warstwie? (QgsFeature to w QML typ wartościowy — deklaracje kłamią.)
    var jestWWarstwie = identyfikator !== "" ? juzJest(warstwa, zr.poleId, identyfikator) : dodane;
    if (!jestWWarstwie) {
      toast(qsTr("Nie udało się zapisać obiektu do warstwy %1.").arg(zr.warstwa));
      log("zapis nieudany: addFeature=" + dodane + " commitChanges=" + zapisane + " warstwa=" + zr.warstwa);
      return;
    }

    log("zapisano " + zr.klucz + " " + identyfikator + " (" + Math.round(powierzchnia) + " m2)");
    toast(qsTr("Pobrano: %1  •  %2 m²").arg(identyfikator).arg(Math.round(powierzchnia)));

    if (ustawienia.jedenStrzal && uzbrojony)
      rozbroj();
  }

  function ustawPole(warstwa, obiekt, nazwa, wartosc) {
    var idx = warstwa.fields.indexOf(nazwa);
    if (idx >= 0)
      obiekt.setAttribute(idx, wartosc);
  }

  function juzJest(warstwa, polePola, wartosc) {
    var idx = warstwa.fields.indexOf(polePola);
    if (idx < 0)
      return false;
    try {
      var wyr = "\"" + polePola + "\" = '" + String(wartosc).replace(/'/g, "''") + "'";
      var it = LayerUtils.createFeatureIteratorFromExpression(warstwa, wyr);
      var jest = it.hasNext();
      it.close();
      return jest;
    } catch (e) {
      log("kontrola duplikatu nieudana: " + e);
      return false;
    }
  }

  //! Gdzie zakladamy warstwy. Puste `plikGpkg` = baza projektu.
  function bazaDocelowa() {
    if (ustawienia.plikGpkg.trim() !== "")
      return projectHome() + ustawienia.plikGpkg.trim();
    if (typeof NarzedziaProjektu !== "undefined") {
      var p = NarzedziaProjektu.plikDanych(qgisProject);
      if (p && p !== "")
        return p;
    }
    return projectHome() + "dane.gpkg";
  }

  function warstwaDocelowa(zr, ms) {
    var istniejaca = LayerUtils.vectorLayerByName(qgisProject, zr.warstwa);
    // ISTNIEJE to za malo. Warstwa wskazujaca na nieistniejacy plik jest
    // w projekcie, wyglada normalnie i dopiero zapis sie nie udaje —
    // z komunikatem, ktory nie mowi o przyczynie. 17.09 kosztowalo to
    // kwadrans szukania w ULDK zamiast w pliku.
    if (istniejaca && istniejaca.isValid)
      return istniejaca;
    if (istniejaca) {
      log("warstwa " + zr.warstwa + " jest w projekcie, ale NIEPRAWIDLOWA "
          + "(brak pliku zrodlowego?) — zakladam od nowa");
      ProjectUtils.removeMapLayer(qgisProject, istniejaca);
    }

    var dom = projectHome();
    if (dom === "") {
      toast(qsTr("Najpierw otwórz projekt — warstwa powstaje w jego katalogu."));
      return null;
    }

    var sciezka = bazaDocelowa();
    var authid = iface.projectCrsAuthid();
    if (!authid || authid === "")
      authid = "EPSG:" + sridUldk;

    log("tworzę warstwę " + zr.warstwa + " w " + sciezka + " (" + authid + ")");
    var warstwa = LayerUtils.createEmptyLayer(sciezka, zr.warstwa, "MultiPolygon", authid, zr.pola);
    if (!warstwa) {
      log("createEmptyLayer zwróciło null — być może warstwa jest już w pliku GPKG, a projekt jej nie zna");
      return null;
    }
    if (!ProjectUtils.addMapLayer(qgisProject, warstwa)) {
      log("addMapLayer nieudane");
      return null;
    }
    if (ustawienia.etykiety)
      LayerUtils.setLabelsEnabled(warstwa, true, zr.poleEtykiety);
    iface.setLayerSelectable(warstwa, false);
    if (ustawienia.zapiszProjekt)
      ProjectUtils.saveProject(qgisProject);
    return warstwa;
  }

  // ------------------------------------------------------- geometria: WKT
  function pierscienieZWkt(wkt) {
    var s = String(wkt).replace(/^\s*SRID\s*=\s*\d+\s*;\s*/i, "").trim();
    var otw = s.indexOf("(");
    if (otw < 0)
      throw qsTr("brak nawiasu w WKT");
    var multi = s.substring(0, otw).toUpperCase().indexOf("MULTI") >= 0;
    var poziomWielokata = multi ? 2 : 1;
    var poziomPierscienia = multi ? 3 : 2;

    var wielokaty = [];
    var biezacy = null;
    var start = -1;
    var glebokosc = 0;
    for (var k = otw; k < s.length; k++) {
      var c = s.charAt(k);
      if (c === "(") {
        glebokosc++;
        if (glebokosc === poziomWielokata) {
          biezacy = [];
          wielokaty.push(biezacy);
        }
        if (glebokosc === poziomPierscienia)
          start = k + 1;
      } else if (c === ")") {
        if (glebokosc === poziomPierscienia && start >= 0 && biezacy) {
          biezacy.push(punktyZTekstu(s.substring(start, k)));
          start = -1;
        }
        glebokosc--;
      }
    }
    return wielokaty;
  }

  function punktyZTekstu(tekst) {
    var wyjscie = [];
    var czesci = tekst.split(",");
    for (var i = 0; i < czesci.length; i++) {
      var xy = czesci[i].trim().split(/\s+/);
      if (xy.length >= 2) {
        var x = parseFloat(xy[0]);
        var y = parseFloat(xy[1]);
        if (!isNaN(x) && !isNaN(y))
          wyjscie.push([x, y]);
      }
    }
    return wyjscie;
  }

  // ------------------------------------------------------- geometria: WKB
  // ULDK potrafi zwrócić geometrię jako szesnastkowe (E)WKB także wtedy, gdy
  // poprosimy o geom_wkt. Zamiast zakładać, że tego nie zrobi — czytamy oba.
  function wielokatyZHexWkb(hex) {
    var h = String(hex).replace(/\s+/g, "");
    if (h.length % 2 !== 0)
      throw qsTr("nieparzysta długość WKB");
    var n = h.length / 2;
    var bufor = new ArrayBuffer(n);
    var bajty = new Uint8Array(bufor);
    for (var i = 0; i < n; i++)
      bajty[i] = parseInt(h.substr(i * 2, 2), 16);
    var dv = new DataView(bufor);
    var stan = { poz: 0 };
    var wynik = czytajWkbGeom(dv, stan);
    return wynik;
  }

  function czytajWkbGeom(dv, stan) {
    var le = dv.getUint8(stan.poz) === 1;
    stan.poz += 1;
    var typ = dv.getUint32(stan.poz, le);
    stan.poz += 4;

    var maZ = false;
    var maM = false;
    if (typ & 0x80000000)
      maZ = true;
    if (typ & 0x40000000)
      maM = true;
    if (typ & 0x20000000)
      stan.poz += 4; // SRID

    var bazowy = typ & 0x0000ffff;
    if (bazowy > 3000) {
      maM = true;
      maZ = true;
      bazowy -= 3000;
    } else if (bazowy > 2000) {
      maM = true;
      bazowy -= 2000;
    } else if (bazowy > 1000) {
      maZ = true;
      bazowy -= 1000;
    }
    var wymiary = 2 + (maZ ? 1 : 0) + (maM ? 1 : 0);

    if (bazowy === 3)
      return [czytajWkbWielokat(dv, stan, le, wymiary)];

    if (bazowy === 6) {
      var ile = dv.getUint32(stan.poz, le);
      stan.poz += 4;
      var lista = [];
      for (var i = 0; i < ile; i++) {
        var czesc = czytajWkbGeom(dv, stan);
        for (var j = 0; j < czesc.length; j++)
          lista.push(czesc[j]);
      }
      return lista;
    }

    throw qsTr("WKB typu %1 nie obsługuję (oczekuję wielokąta)").arg(bazowy);
  }

  function czytajWkbWielokat(dv, stan, le, wymiary) {
    var ilePierscieni = dv.getUint32(stan.poz, le);
    stan.poz += 4;
    var wielokat = [];
    for (var r = 0; r < ilePierscieni; r++) {
      var ilePunktow = dv.getUint32(stan.poz, le);
      stan.poz += 4;
      var pierscien = [];
      for (var p = 0; p < ilePunktow; p++) {
        var x = dv.getFloat64(stan.poz, le);
        stan.poz += 8;
        var y = dv.getFloat64(stan.poz, le);
        stan.poz += 8;
        stan.poz += (wymiary - 2) * 8;
        pierscien.push([x, y]);
      }
      wielokat.push(pierscien);
    }
    return wielokat;
  }

  // --------------------------------------------------- geometria: wspólne
  function wktZWielokatow(wielokaty) {
    var czesci = [];
    for (var w = 0; w < wielokaty.length; w++) {
      var pierscienie = [];
      for (var r = 0; r < wielokaty[w].length; r++) {
        var punkty = [];
        for (var p = 0; p < wielokaty[w][r].length; p++)
          punkty.push(wielokaty[w][r][p][0] + " " + wielokaty[w][r][p][1]);
        pierscienie.push("(" + punkty.join(",") + ")");
      }
      czesci.push("(" + pierscienie.join(",") + ")");
    }
    return "MULTIPOLYGON(" + czesci.join(",") + ")";
  }

  function powierzchniaWielokatow(wielokaty) {
    var suma = 0;
    for (var w = 0; w < wielokaty.length; w++) {
      for (var r = 0; r < wielokaty[w].length; r++) {
        var a = Math.abs(polePierscienia(wielokaty[w][r]));
        suma += (r === 0 ? a : -a);
      }
    }
    return suma;
  }

  /**
   * Czy punkt (x, y) leży w którymś z wielokątów (z uwzględnieniem dziur),
   * albo nie dalej niż \a tolerancja metrów od jego krawędzi? Tolerancja
   * ratuje tapnięcia dokładnie w granicę i drobne różnice zaokrągleń.
   */
  function punktWWielokatach(wielokaty, x, y, tolerancja) {
    for (var w = 0; w < wielokaty.length; w++) {
      if (wielokaty[w].length === 0)
        continue;
      if (!punktWPierscieniu(wielokaty[w][0], x, y)) {
        if (odlegloscOdPierscienia(wielokaty[w][0], x, y) <= tolerancja)
          return true;
        continue;
      }
      var wDziurze = false;
      for (var r = 1; r < wielokaty[w].length; r++) {
        if (punktWPierscieniu(wielokaty[w][r], x, y)) {
          wDziurze = true;
          break;
        }
      }
      if (!wDziurze)
        return true;
    }
    return false;
  }

  function punktWPierscieniu(pierscien, x, y) {
    var w = false;
    for (var i = 0, j = pierscien.length - 1; i < pierscien.length; j = i++) {
      var xi = pierscien[i][0];
      var yi = pierscien[i][1];
      var xj = pierscien[j][0];
      var yj = pierscien[j][1];
      if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi))
        w = !w;
    }
    return w;
  }

  function odlegloscOdPierscienia(pierscien, x, y) {
    var min = Number.MAX_VALUE;
    for (var i = 0; i < pierscien.length - 1; i++) {
      var d = odlegloscOdOdcinka(x, y, pierscien[i][0], pierscien[i][1], pierscien[i + 1][0], pierscien[i + 1][1]);
      if (d < min)
        min = d;
    }
    return min;
  }

  function odlegloscOdOdcinka(px, py, x1, y1, x2, y2) {
    var dx = x2 - x1;
    var dy = y2 - y1;
    var dl = dx * dx + dy * dy;
    var t = dl === 0 ? 0 : ((px - x1) * dx + (py - y1) * dy) / dl;
    t = Math.max(0, Math.min(1, t));
    var rx = px - (x1 + t * dx);
    var ry = py - (y1 + t * dy);
    return Math.sqrt(rx * rx + ry * ry);
  }

  function polePierscienia(pierscien) {
    var s = 0;
    for (var i = 0; i < pierscien.length - 1; i++)
      s += pierscien[i][0] * pierscien[i + 1][1] - pierscien[i + 1][0] * pierscien[i][1];
    return s / 2;
  }

  // ---------------------------------------------------------------- drobne
  function projectHome() {
    if (typeof qgisProject === "undefined" || !qgisProject || !qgisProject.homePath)
      return "";
    var p = qgisProject.homePath;
    return p.endsWith("/") ? p : p + "/";
  }

  function teraz() {
    var d = new Date();
    function p2(n) {
      return (n < 10 ? "0" : "") + n;
    }
    return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()) + " " + p2(d.getHours()) + ":" + p2(d.getMinutes()) + ":" + p2(d.getSeconds());
  }

  function toast(t) {
    if (mainWindow && mainWindow.displayToast)
      mainWindow.displayToast(t);
    log("toast: " + t);
  }

  // Dwa kanały świadomie: console.log wychodzi na stdout (na desktopie
  // `grep "GUGIK:"` na wyjściu ./build-sys/output/bin/qfield), a logMessage
  // ląduje w logu aplikacji — jedyny, który da się odczytać na telefonie.
  function log(t) {
    console.log("GUGIK: " + t);
    iface.logMessage("GUGIK: " + t);
  }

  // ------------------------------------------------------------- ustawienia
  Dialog {
    id: okno
    parent: mainWindow.contentItem
    modal: true
    title: qsTr("GUGiK — pobieranie obiektów")
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 40, 500)
    height: Math.min(mainWindow.height - 80, 560)
    standardButtons: Dialog.Close

    ColumnLayout {
      anchors.fill: parent
      spacing: 8

      Label {
        Layout.fillWidth: true
        text: qsTr("Tapnięcie w ikonę wtyczki włącza tryb pobierania: kolejne tapnięcie w mapę pobiera obiekt z ULDK zamiast otwierać formularz.")
        wrapMode: Text.WordWrap
        color: "#9e9e9e"
        font.pointSize: 9
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Label {
          text: qsTr("Pobieram:")
          color: "#9e9e9e"
        }

        ComboBox {
          id: rodzajCombo
          Layout.fillWidth: true
          textRole: "label"
          valueRole: "value"
          model: [
            { label: qsTr("działki (ULDK)"), value: "dzialka" },
            { label: qsTr("budynki (ULDK)"), value: "budynek" }
          ]
          Component.onCompleted: currentIndex = Math.max(0, indexOfValue(ustawienia.rodzaj))
          onActivated: {
            ustawienia.rodzaj = currentValue;
            plugin.log("rodzaj zmieniony na " + currentValue);
          }
        }
      }

      TextField {
        Layout.fillWidth: true
        text: ustawienia.plikGpkg
        placeholderText: qsTr("plik GPKG w katalogu projektu")
        // Puste zostaje puste — to znaczy "baza projektu".
        onEditingFinished: ustawienia.plikGpkg = text.trim()
      }

      CheckBox {
        Layout.fillWidth: true
        text: qsTr("Podpisz obiekty na mapie")
        checked: ustawienia.etykiety
        onToggled: ustawienia.etykiety = checked
      }

      CheckBox {
        Layout.fillWidth: true
        text: qsTr("Zapisz projekt po utworzeniu warstwy")
        checked: ustawienia.zapiszProjekt
        onToggled: ustawienia.zapiszProjekt = checked
      }

      CheckBox {
        Layout.fillWidth: true
        text: qsTr("Wyłącz tryb po jednym pobraniu")
        checked: ustawienia.jedenStrzal
        onToggled: ustawienia.jedenStrzal = checked
      }

      Button {
        Layout.fillWidth: true
        text: qsTr("Test połączenia z ULDK")
        onClicked: plugin.testPolaczenia()
      }

      Label {
        Layout.fillWidth: true
        text: qsTr("Ostatnia odpowiedź ULDK (do diagnostyki):")
        color: "#9e9e9e"
        font.pointSize: 9
        visible: plugin.ostatniSurowy !== ""
      }

      ScrollView {
        Layout.fillWidth: true
        Layout.fillHeight: true
        visible: plugin.ostatniSurowy !== ""

        TextArea {
          readOnly: true
          wrapMode: Text.WrapAnywhere
          font.pointSize: 8
          text: plugin.ostatniSurowy
        }
      }

      Label {
        Layout.fillWidth: true
        text: qsTr("Dane: ULDK — Główny Urząd Geodezji i Kartografii (uldk.gugik.gov.pl).")
        wrapMode: Text.WordWrap
        color: "#9e9e9e"
        font.pointSize: 9
      }
    }
  }
}
