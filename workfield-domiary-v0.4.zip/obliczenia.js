.pragma library

// WorkField Domiary — obliczenia (czysty JS, bez Qt; testowane w Node: test_obliczenia.js).
//
// Układ: PL-2000 (EPSG:2176–2179). Wewnątrz e = wschód, n = północ [m].
// Na zewnątrz (ekran, dziennik) zapis geodezyjny: X = północ, Y = wschód.
//
// Punkt nawiązania: { nazwa, e, n, h (wys. lub null), s (błąd poziomy [m]), zrodlo }
// Odległość:        { d (odczyt dalmierza [m]), kat (kąt pionowy [°] lub null) }

var R = 6382000.0;      // promień kuli średniej dla Polski [m]
var K0 = 0.999923;      // skala na południku osiowym PL-2000

var STREFY = {
  2176: { strefa: 5, cm: 15, fe: 5500000 },
  2177: { strefa: 6, cm: 18, fe: 6500000 },
  2178: { strefa: 7, cm: 21, fe: 7500000 },
  2179: { strefa: 8, cm: 24, fe: 8500000 }
};

function epsgDlaDlugosci(lon) {
  if (lon < 16.5) return 2176;
  if (lon < 19.5) return 2177;
  if (lon < 22.5) return 2178;
  return 2179;
}

// ─────────────────────────────────────────────────────────── liczby z pól

//! "12,345" / " 12.3 m" → 12.345; puste lub śmieci → NaN
function liczba(t) {
  if (t === null || t === undefined)
    return NaN;
  var s = String(t).trim().replace(",", ".").replace(/\s*m$/i, "");
  if (s === "" || !/^[-+]?\d*\.?\d+(e[-+]?\d+)?$/i.test(s))
    return NaN;
  return parseFloat(s);
}

function f(x, n) {
  if (x === null || x === undefined || !isFinite(x))
    return "—";
  return x.toFixed(n);
}

// ─────────────────────────────────────────────────────────── redukcje

//! Skala odwzorowania PL-2000 w punkcie o współrzędnej e.
function skala(e, epsg) {
  var s = STREFY[epsg];
  if (!s)
    return 1;
  var y = (e - s.fe) / K0;
  var q = y * y / (R * R);
  return K0 * (1 + q / 2 + q * q / 24);
}

//! Redukcja na poziom elipsoidy (h — wysokość terenu; brak = 0).
function redukcjaWysokosci(h) {
  if (h === null || h === undefined || !isFinite(h))
    return 1;
  return R / (R + h);
}

//! Odczyt skośny + kąt pionowy → odległość pozioma.
function pozioma(d, kat) {
  if (kat === null || kat === undefined || !isFinite(kat))
    return d;
  return d * Math.cos(kat * Math.PI / 180);
}

//! Współczynnik: odległość pozioma w terenie → odległość w układzie 2000.
function wspolczynnik(stacje, epsg, redukuj) {
  if (!redukuj || stacje.length === 0)
    return 1;
  var se = 0, sh = 0, nh = 0;
  for (var i = 0; i < stacje.length; i++) {
    se += stacje[i].e;
    if (stacje[i].h !== null && stacje[i].h !== undefined && isFinite(stacje[i].h)) {
      sh += stacje[i].h;
      nh++;
    }
  }
  var h = nh > 0 ? sh / nh : 0;
  return skala(se / stacje.length, epsg) * redukcjaWysokosci(h);
}

// ─────────────────────────────────────────────────────────── geometria

function odl(a, b) {
  var de = b.e - a.e, dn = b.n - a.n;
  return Math.sqrt(de * de + dn * dn);
}

//! Azymut A→B w gradach (od północy, zgodnie z ruchem wskazówek).
function azymutGrad(a, b) {
  var t = Math.atan2(b.e - a.e, b.n - a.n) * 200 / Math.PI;
  return t < 0 ? t + 400 : t;
}

//! Kąt w punkcie P między kierunkami na A i B [°].
function katWPunkcie(p, a, b) {
  var a1 = Math.atan2(a.e - p.e, a.n - p.n);
  var a2 = Math.atan2(b.e - p.e, b.n - p.n);
  var k = Math.abs(a1 - a2) * 180 / Math.PI;
  return k > 180 ? 360 - k : k;
}

// ─────────────────────────────────────────────────────── ocena dokładności

//! Błąd odległości łącznie z niepewnością położenia stacji.
function sigmaObs(sd, stacja) {
  var ss = (stacja.s !== null && stacja.s !== undefined && isFinite(stacja.s)) ? stacja.s : 0;
  return Math.sqrt(sd * sd + ss * ss);
}

//! Ocena punktu p wyznaczonego z odległości (MNK, macierz kowariancji).
//! obs: [{ stacja, d (zredukowana), sd }]
function ocena(p, obs) {
  var n11 = 0, n12 = 0, n22 = 0, vpv = 0;
  var poprawki = [];
  for (var i = 0; i < obs.length; i++) {
    var st = obs[i].stacja;
    var s = odl(st, p);
    if (s < 1e-9)
      continue;
    var ae = (p.e - st.e) / s, an = (p.n - st.n) / s;
    var sig = sigmaObs(obs[i].sd, st);
    var w = 1 / (sig * sig);
    n11 += ae * ae * w;
    n12 += ae * an * w;
    n22 += an * an * w;
    var v = obs[i].d - s;
    vpv += v * v * w;
    poprawki.push({ nazwa: st.nazwa, v: v, sigma: sig, odstaje: Math.abs(v) > 3 * sig });
  }
  var det = n11 * n22 - n12 * n12;
  var nadmiar = obs.length - 2;
  var sigma0 = nadmiar > 0 ? Math.sqrt(vpv / nadmiar) : null;
  if (det <= 1e-12 * (n11 + n22) * (n11 + n22) || det <= 0)
    return { mp: Infinity, me: Infinity, mn: Infinity, osA: Infinity, poprawki: poprawki, sigma0: sigma0, zla: true };
  // a posteriori, ale nigdy optymistyczniej niż a priori
  var skalaQ = (sigma0 !== null && sigma0 > 1) ? sigma0 * sigma0 : 1;
  var qee = n22 / det * skalaQ, qnn = n11 / det * skalaQ, qen = -n12 / det * skalaQ;
  var sr = (qee + qnn) / 2, roz = Math.sqrt(Math.max(0, (qee - qnn) * (qee - qnn) / 4 + qen * qen));
  return {
    me: Math.sqrt(qee), mn: Math.sqrt(qnn), mp: Math.sqrt(qee + qnn),
    osA: Math.sqrt(sr + roz), osB: Math.sqrt(Math.max(0, sr - roz)),
    poprawki: poprawki, sigma0: sigma0, zla: false
  };
}

// ─────────────────────────────────────────────────── 1. przecięcie liniowe

//! Oba rozwiązania przecięcia okręgów (A, dA) i (B, dB).
//! „lewy” / „prawy” — patrząc z A na B.
//! tol — ile brakującej długości [m] wolno zrzucić na błąd pomiaru (styczność).
function przeciecie(A, B, dA, dB, tol) {
  var c = odl(A, B);
  if (c < 0.01)
    return { blad: "Punkty nawiązania pokrywają się (baza < 1 cm)." };
  if (!(dA > 0) || !(dB > 0))
    return { blad: "Podaj obie odległości (większe od zera)." };
  var brak = Math.max(c - (dA + dB), Math.abs(dA - dB) - c);
  var uwagi = [];
  var a = (dA * dA - dB * dB + c * c) / (2 * c);
  var h2 = dA * dA - a * a;
  if (brak > 0) {
    if (brak > tol)
      return {
        blad: "Odległości nie tworzą trójkąta z bazą " + f(c, 3) + " m — brakuje " + f(brak, 3)
          + " m. Sprawdź odczyty i czy punkty nawiązania są właściwe."
      };
    uwagi.push("Okręgi ledwie się stykają (brak " + f(brak * 100, 1) + " cm) — punkt leży prawie na linii bazy, wynik słaby.");
    h2 = 0;
    a = Math.max(0, Math.min(c, a));
  }
  var h = Math.sqrt(Math.max(0, h2));
  var ue = (B.e - A.e) / c, un = (B.n - A.n) / c;
  var se = A.e + a * ue, sn = A.n + a * un;
  // lewa normalna do kierunku (ue, un) w układzie (e, n): (-un, ue)
  var L = { e: se - h * un, n: sn + h * ue };
  var P = { e: se + h * un, n: sn - h * ue };
  var gamma = katWPunkcie(L, A, B);
  if (gamma < 30 || gamma > 150)
    uwagi.push("Kąt przecięcia " + f(gamma, 0) + "° — poza zakresem 30–150°, dokładność wyraźnie spada.");
  return { lewy: L, prawy: P, baza: c, gamma: gamma, uwagi: uwagi };
}

// ───────────────────────────────────────── 2. punkt na prostej / przedłużenie

//! Punkt w odległości d od A w kierunku B (d > AB = za B — przedłużenie).
//! wstecz = true: po przeciwnej stronie A (przedłużenie za A).
function naProstej(A, B, d, wstecz, sd) {
  var c = odl(A, B);
  if (c < 0.01)
    return { blad: "Punkty nawiązania pokrywają się (baza < 1 cm)." };
  if (!(d >= 0))
    return { blad: "Podaj odległość." };
  var znak = wstecz ? -1 : 1;
  var ue = (B.e - A.e) / c, un = (B.n - A.n) / c;
  var P = { e: A.e + znak * d * ue, n: A.n + znak * d * un };
  var t = znak * d / c; // położenie na prostej w jednostkach bazy: 0 = A, 1 = B
  // Poprzecznie błąd stacji przenosi się liniowo (dźwignia), wzdłuż: odczyt + A.
  var sA = (A.s && isFinite(A.s)) ? A.s : 0, sB = (B.s && isFinite(B.s)) ? B.s : 0;
  var poprz = Math.sqrt(Math.pow(sA * (1 - t), 2) + Math.pow(sB * t, 2));
  var wzdl = Math.sqrt(sd * sd + sA * sA);
  var uwagi = [];
  if (t > 2 || t < -1)
    uwagi.push("Przedłużenie dalej niż baza A–B — błąd poprzeczny rośnie z każdym metrem (dźwignia ×" + f(Math.abs(t), 1) + ").");
  var opis = wstecz ? "przedłużenie za " + A.nazwa + " o " + f(d, 3) + " m"
                    : (t > 1 ? "przedłużenie za " + B.nazwa + " o " + f(d - c, 3) + " m"
                             : "na odcinku " + A.nazwa + "–" + B.nazwa + ", " + f(d, 3) + " m od " + A.nazwa);
  return { punkt: P, baza: c, t: t, opis: opis, mp: Math.sqrt(poprz * poprz + wzdl * wzdl), poprzeczny: poprz, wzdluzny: wzdl, uwagi: uwagi };
}

// ───────────────────────────────────────────── 3. wcięcie liniowe (MNK)

function gaussNewton(start, obs) {
  var p = { e: start.e, n: start.n };
  for (var it = 0; it < 30; it++) {
    var n11 = 0, n12 = 0, n22 = 0, u1 = 0, u2 = 0;
    for (var i = 0; i < obs.length; i++) {
      var st = obs[i].stacja;
      var s = odl(st, p);
      if (s < 1e-9)
        s = 1e-9;
      var ae = (p.e - st.e) / s, an = (p.n - st.n) / s;
      var sig = sigmaObs(obs[i].sd, st);
      var w = 1 / (sig * sig);
      var l = obs[i].d - s;
      n11 += ae * ae * w; n12 += ae * an * w; n22 += an * an * w;
      u1 += ae * l * w; u2 += an * l * w;
    }
    var det = n11 * n22 - n12 * n12;
    if (!(det > 0))
      return null;
    var de = (n22 * u1 - n12 * u2) / det;
    var dn = (n11 * u2 - n12 * u1) / det;
    p.e += de;
    p.n += dn;
    if (Math.abs(de) < 1e-7 && Math.abs(dn) < 1e-7)
      return p;
  }
  return p;
}

function sumaKw(p, obs) {
  var s = 0;
  for (var i = 0; i < obs.length; i++) {
    var sig = sigmaObs(obs[i].sd, obs[i].stacja);
    var v = (obs[i].d - odl(obs[i].stacja, p)) / sig;
    s += v * v;
  }
  return s;
}

//! Czy stacje leżą prawie na jednej prostej? (mniejsza oś rozrzutu < 3% większej)
function prawieProsta(obs) {
  var n = obs.length, se = 0, sn = 0;
  for (var i = 0; i < n; i++) { se += obs[i].stacja.e; sn += obs[i].stacja.n; }
  se /= n; sn /= n;
  var cee = 0, cnn = 0, cen = 0;
  for (var j = 0; j < n; j++) {
    var de = obs[j].stacja.e - se, dn = obs[j].stacja.n - sn;
    cee += de * de; cnn += dn * dn; cen += de * dn;
  }
  var sr = (cee + cnn) / 2, roz = Math.sqrt((cee - cnn) * (cee - cnn) / 4 + cen * cen);
  var duza = sr + roz, mala = Math.max(0, sr - roz);
  return duza > 0 && Math.sqrt(mala / duza) < 0.03;
}

//! obs: [{ stacja, d (zredukowana), sd }], co najmniej 3.
function wciecie(obs, tol) {
  if (obs.length < 3)
    return { blad: "Wcięcie wymaga co najmniej 3 punktów nawiązania z odległościami." };
  // Starty: oba rozwiązania z każdej pary — chroni przed lustrzanym minimum.
  var starty = [];
  for (var i = 0; i < obs.length; i++)
    for (var j = i + 1; j < obs.length; j++) {
      var pr = przeciecie(obs[i].stacja, obs[j].stacja, obs[i].d, obs[j].d, Math.max(tol, 1));
      if (pr.blad)
        continue;
      starty.push(pr.lewy, pr.prawy);
    }
  if (starty.length === 0)
    return { blad: "Żadna para odległości nie tworzy trójkąta z bazą — sprawdź odczyty." };
  var wyniki = [];
  for (var k = 0; k < starty.length; k++) {
    var p = gaussNewton(starty[k], obs);
    if (!p)
      continue;
    var dup = false;
    for (var m = 0; m < wyniki.length; m++)
      if (odl(wyniki[m].punkt, p) < 0.001) { dup = true; break; }
    if (!dup)
      wyniki.push({ punkt: p, suma: sumaKw(p, obs) });
  }
  if (wyniki.length === 0)
    return { blad: "Obliczenie nie zbiegło się — układ punktów nawiązania jest zdegenerowany." };
  wyniki.sort(function (a, b) { return a.suma - b.suma });
  var naj = wyniki[0];
  var oc = ocena(naj.punkt, obs);
  var uwagi = [];
  // Drugie minimum prawie tak dobre jak pierwsze = punkty nawiązania prawie na prostej.
  // Próg: różnica sumy kwadratów < 25 (czyli ok. 5σ) — dane nie rozstrzygają.
  if (wyniki.length > 1) {
    if (wyniki[1].suma - naj.suma < 25 && odl(wyniki[1].punkt, naj.punkt) > 0.05)
      uwagi.push("Wynik niejednoznaczny: drugie położenie (" + f(odl(wyniki[1].punkt, naj.punkt), 2)
        + " m dalej) pasuje prawie równie dobrze. Punkty nawiązania leżą prawie na jednej prostej — dodaj punkt z boku.");
  }
  if (oc.zla)
    uwagi.push("Geometria zdegenerowana — nie da się ocenić dokładności.");
  if (uwagi.length === 0 && prawieProsta(obs))
    uwagi.push("Punkty nawiązania leżą prawie na jednej prostej — wynik słaby w kierunku poprzecznym do niej.");
  if (oc.sigma0 !== null && oc.sigma0 > 2) {
    uwagi.push("Odległości są ze sobą niezgodne bardziej niż zakłada σ odległości (σ₀ = " + f(oc.sigma0, 1) + ").");
    // Kto winny? Przy 4+ punktach: wyłączamy po kolei i patrzymy, bez którego jest zgodnie.
    var podejrzany = null;
    if (obs.length >= 4) {
      for (var q = 0; q < obs.length; q++) {
        var bez = obs.slice(0, q).concat(obs.slice(q + 1));
        var pb = gaussNewton(naj.punkt, bez);
        if (!pb)
          continue;
        var s0 = Math.sqrt(sumaKw(pb, bez) / (bez.length - 2));
        if (podejrzany === null || s0 < podejrzany.s0)
          podejrzany = { nazwa: obs[q].stacja.nazwa, s0: s0, v: obs[q].d - odl(obs[q].stacja, pb) };
      }
    }
    if (podejrzany && podejrzany.s0 < 2)
      uwagi.push("Najpewniej błędna odległość do " + podejrzany.nazwa + " (odchyłka " + f(podejrzany.v * 100, 1)
        + " cm; bez niej σ₀ = " + f(podejrzany.s0, 1) + "). Zmierz ją ponownie albo wyłącz ten punkt.");
    else
      uwagi.push(obs.length >= 4 ? "Nie da się wskazać jednej błędnej odległości — sprawdź wszystkie odczyty i punkty nawiązania."
                                 : "Przy 3 punktach nie da się wskazać, która odległość jest błędna — dodaj czwarty punkt albo zmierz ponownie.");
  }
  return { punkt: naj.punkt, ocena: oc, alternatywa: wyniki.length > 1 ? wyniki[1].punkt : null, uwagi: uwagi };
}

// ─────────────────────────────────────────────────────────── teksty

//! Jeden punkt w zapisie geodezyjnym.
function xy(p) {
  return "X = " + f(p.n, 2) + "   Y = " + f(p.e, 2);
}

function csvPole(t) {
  var s = (t === null || t === undefined) ? "" : String(t);
  if (/[;"\n\r]/.test(s))
    s = '"' + s.replace(/"/g, '""') + '"';
  return s;
}

var NAGLOWEK_CSV = ["data", "nr", "rodzaj", "metoda", "X_2000", "Y_2000", "EPSG", "mp_m", "nawiazania",
                    "odleglosci", "poprawki_m", "wspolczynnik", "uwagi", "opis", "WKT"];

function wierszCsv(w) {
  return [w.data, w.nr, w.rodzaj, w.metoda, f(w.n, 3), f(w.e, 3), w.epsg,
          (w.mp !== null && isFinite(w.mp)) ? f(w.mp, 3) : "", w.nawiazania, w.odleglosci, w.poprawki,
          w.wsp ? w.wsp.toFixed(7) : "", w.uwagi, w.opis,
          "POINT (" + f(w.e, 3) + " " + f(w.n, 3) + ")"].map(csvPole).join(";");
}

function utf8(s) {
  var u = unescape(encodeURIComponent(s));
  var a = new Uint8Array(u.length);
  for (var i = 0; i < u.length; i++) a[i] = u.charCodeAt(i);
  return a;
}

function zUtf8(bufor) {
  var a = new Uint8Array(bufor);
  var s = "";
  for (var i = 0; i < a.length; i += 8192)
    s += String.fromCharCode.apply(null, Array.prototype.slice.call(a, i, i + 8192));
  try {
    return decodeURIComponent(escape(s));
  } catch (e) {
    return null;
  }
}

//! Współrzędne z WKT punktu (Point, PointZ, MultiPoint — pierwszy).
function punktZWkt(wkt) {
  var m = /\(\s*\(?\s*([-+0-9.eE]+)\s+([-+0-9.eE]+)(?:\s+([-+0-9.eE]+))?/.exec(wkt || "");
  if (!m || !/^\s*(multi)?point/i.test(wkt))
    return null;
  return { x: parseFloat(m[1]), y: parseFloat(m[2]), z: m[3] !== undefined ? parseFloat(m[3]) : null };
}

function nastepnaNazwa(punkty) {
  var zajete = {};
  for (var i = 0; i < punkty.length; i++)
    zajete[punkty[i].nazwa] = true;
  var litery = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  for (var k = 0; k < litery.length; k++)
    if (!zajete[litery[k]])
      return litery[k];
  var n = 1;
  while (zajete["N" + n]) n++;
  return "N" + n;
}
