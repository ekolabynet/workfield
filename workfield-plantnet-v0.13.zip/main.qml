import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore
import org.qfield
import Theme

/**
 * WorkField Pl@ntNet — rozpoznawanie gatunków roślin ze zdjęć.
 * Wersja 0.11: 0.10 + sekcja „Czym je rozróżnić" (WF_CECHY przez PhotoTagStore, tylko WorkField).
 *  - do 5 zdjęć TEJ SAMEJ rośliny naraz (kwiat + liść + pokrój = wyższa pewność);
 *  - pasek miniatur: ✕ usuwa zdjęcie, przycisk pod miniaturą przełącza organ
 *    (liść → kwiat → owoc → kora → pokrój) — duże cele, pod rękawice;
 *  - „Wyczyść" przygotowuje okno pod następną roślinę.
 * Klucz API przechowywany lokalnie w ustawieniach (nigdy w kodzie!).
 */
Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property bool busy: false
  property var __resourceSource
  property var cechyStore: null
  property var cechyWiersze: []

  readonly property var organy: [
    { v: "leaf", l: "liść" },
    { v: "flower", l: "kwiat" },
    { v: "fruit", l: "owoc" },
    { v: "bark", l: "kora" },
    { v: "auto", l: "pokrój" }
  ]

  function organLabel(v) {
    for (var i = 0; i < organy.length; i++)
      if (organy[i].v === v)
        return organy[i].l
    return v
  }

  function nextOrgan(v) {
    for (var i = 0; i < organy.length; i++)
      if (organy[i].v === v)
        return organy[(i + 1) % organy.length].v
    return organy[0].v
  }

  Settings {
    id: pluginSettings
    category: "WorkFieldPlantNet"
    property string apiKey: ""
    property string organ: "leaf"
    property string flora: "auto-geo"
    property string autoFloraId: ""
    property string autoFloraTitle: ""
    property string autoFloraDay: ""
    property bool autoFoto: false
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(pluginButton)
    try {
      // klasa istnieje tylko w WorkField; w stockowym QFieldzie sekcja cech
      // po prostu sie nie pojawi, a wtyczka dziala dalej
      cechyStore = Qt.createQmlObject('import org.qfield 1.0; PhotoTagStore {}', plugin, "wfCechy")
    } catch (e) {
      cechyStore = null
    }
  }

  QfToolButton {
    id: pluginButton
    iconSource: 'icon.svg'
    iconColor: "#FB8C00"
    bgcolor: Theme.darkGray
    round: true
    onClicked: dialog.open()
  }

  function projectHome() {
    if (typeof qgisProject === "undefined" || !qgisProject || !qgisProject.homePath)
      return ""
    var p = qgisProject.homePath
    return p.endsWith("/") ? p : p + "/"
  }

  function newPhotoName() {
    var d = new Date()
    function p2(n) { return (n < 10 ? "0" : "") + n }
    return "DCIM/plantnet_" + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate())
        + "_" + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds()) + ".JPG"
  }

  function acquire(fromCamera) {
    if (photosModel.count >= 5) {
      statusLabel.error(qsTr("Maksymalnie 5 zdjęć jednej rośliny."))
      return
    }
    var home = projectHome()
    if (home === "") {
      statusLabel.error(qsTr("Najpierw otwórz projekt — zdjęcia lądują w jego katalogu."))
      return
    }
    platformUtilities.createDir(qgisProject.homePath, "DCIM")
    var filepath = newPhotoName()
    statusLabel.step(fromCamera ? qsTr("Uruchamiam aparat…") : qsTr("Otwieram galerię…"))
    if (fromCamera) {
      plugin.__resourceSource = platformUtilities.getCameraPicture(home, filepath, "JPG", plugin)
    } else {
      plugin.__resourceSource = platformUtilities.getGalleryPicture(home, filepath, plugin)
    }
  }

  Connections {
    target: plugin.__resourceSource ? plugin.__resourceSource : null
    ignoreUnknownSignals: true
    function onResourceReceived(path) {
      if (!path || path === "") {
        statusLabel.error(qsTr("Nie otrzymano zdjęcia (anulowano?)."))
        return
      }
      var full = path.startsWith("/") ? path : plugin.projectHome() + path
      photosModel.append({ path: full, organ: pluginSettings.organ })
      statusLabel.step(qsTr("Zdjęć w komplecie: ") + photosModel.count + "/5")
    }
  }

  ListModel {
    id: photosModel
  }

  ListModel {
    id: resultsModel
  }

  TextEdit {
    id: clipboardHelper
    visible: false
    function copyText(t) {
      text = t
      selectAll()
      copy()
    }
  }

  Dialog {
    id: dialog
    parent: mainWindow.contentItem
    modal: true
    title: "Pl@ntNet — rozpoznanie gatunku"
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: Math.min(mainWindow.width - 40, 500)
    height: Math.min(mainWindow.height - 80, 680)
    standardButtons: Dialog.Close

    ColumnLayout {
      anchors.fill: parent
      spacing: 8

      TextField {
        id: apiKeyField
        Layout.fillWidth: true
        placeholderText: qsTr("Klucz API Pl@ntNet")
        text: pluginSettings.apiKey
        echoMode: TextInput.PasswordEchoOnEdit
        onEditingFinished: pluginSettings.apiKey = text.trim()
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Label {
          text: qsTr("Flora:")
          color: "#9e9e9e"
        }

        ComboBox {
          id: floraCombo
          Layout.fillWidth: true
          textRole: "label"
          valueRole: "value"
          model: [
            { label: qsTr("auto (z pozycji)"), value: "auto-geo" },
            { label: qsTr("Europa Środkowa"), value: "k-middle-europe" },
            { label: qsTr("uprawne i ozdobne"), value: "useful" },
            { label: qsTr("cały świat"), value: "k-world-flora" }
          ]
          Component.onCompleted: {
            currentIndex = Math.max(0, indexOfValue(pluginSettings.flora))
          }
          onActivated: pluginSettings.flora = currentValue
        }

        Button {
          visible: pluginSettings.flora === "auto-geo" && pluginSettings.autoFloraId !== ""
          text: "↻"
          font.bold: true
          implicitWidth: 44
          onClicked: {
            pluginSettings.autoFloraId = ""
            pluginSettings.autoFloraTitle = ""
            pluginSettings.autoFloraDay = ""
            statusLabel.step(qsTr("Pamięć flory wyczyszczona — ustalę ją na nowo przy następnym rozpoznaniu."))
          }
        }
      }

      CheckBox {
        Layout.fillWidth: true
        text: qsTr("Auto-Pl@ntNet po zdjęciu w formularzu")
        checked: pluginSettings.autoFoto
        onToggled: pluginSettings.autoFoto = checked
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        Button {
          Layout.fillWidth: true
          enabled: photosModel.count < 5
          text: qsTr("📷 Zrób zdjęcie")
          onClicked: plugin.acquire(true)
        }

        Button {
          Layout.fillWidth: true
          enabled: photosModel.count < 5
          text: qsTr("🖼 Galeria")
          onClicked: plugin.acquire(false)
        }

        Button {
          visible: photosModel.count > 0
          text: qsTr("Wyczyść")
          onClicked: {
            photosModel.clear()
            resultsModel.clear()
            plugin.cechyWiersze = []
            statusLabel.text = ""
          }
        }
      }

      ListView {
        id: photoStrip
        Layout.fillWidth: true
        Layout.preferredHeight: photosModel.count > 0 ? 116 : 0
        visible: photosModel.count > 0
        orientation: ListView.Horizontal
        spacing: 6
        clip: true
        model: photosModel

        delegate: Column {
          spacing: 3

          Rectangle {
            width: 78
            height: 78
            radius: 6
            color: "#263238"

            Image {
              anchors.fill: parent
              anchors.margins: 1
              source: "file://" + path
              fillMode: Image.PreserveAspectCrop
              asynchronous: true
              cache: false
              sourceSize.width: 300
            }

            Rectangle {
              width: 26
              height: 26
              radius: 13
              color: "#c62828"
              anchors.top: parent.top
              anchors.right: parent.right
              anchors.margins: 2

              Label {
                anchors.centerIn: parent
                text: "✕"
                color: "#ffffff"
                font.bold: true
              }

              MouseArea {
                anchors.fill: parent
                onClicked: photosModel.remove(index)
              }
            }
          }

          Button {
            width: 78
            height: 32
            text: plugin.organLabel(organ)
            onClicked: {
              var n = plugin.nextOrgan(organ)
              photosModel.setProperty(index, "organ", n)
              pluginSettings.organ = n
            }
          }
        }
      }

      Button {
        Layout.fillWidth: true
        enabled: !plugin.busy && photosModel.count > 0 && apiKeyField.text.trim() !== ""
        text: plugin.busy ? qsTr("Rozpoznawanie…")
                          : qsTr("Rozpoznaj gatunek (zdjęć: ") + photosModel.count + ")"
        onClicked: plugin.identify()
      }

      Label {
        id: statusLabel
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        font.bold: true
        property bool isError: false
        color: "#39ff14"
        visible: text !== ""
        function step(t) { isError = false; text = t }
        function error(t) { isError = true; text = "⚠ " + t; plugin.busy = false }
      }

      ListView {
        id: resultsView
        Layout.fillWidth: true
        Layout.fillHeight: true
        clip: true
        model: resultsModel
        spacing: 4

        delegate: Rectangle {
          width: resultsView.width
          height: rowCol.implicitHeight + 16
          radius: 6
          color: index === 0 ? "#e8f5e9" : "#f5f5f5"

          Column {
            id: rowCol
            anchors.verticalCenter: parent.verticalCenter
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.margins: 10
            spacing: 2

            Label {
              width: parent.width
              text: score + "%  —  " + scientificName
              font.bold: index === 0
              font.italic: true
              wrapMode: Text.WordWrap
              color: "#212121"
            }
            Label {
              width: parent.width
              visible: commonName !== ""
              text: commonName
              wrapMode: Text.WordWrap
              color: "#555555"
            }
          }

          MouseArea {
            anchors.fill: parent
            onClicked: {
              clipboardHelper.copyText(scientificName)
              mainWindow.displayToast(qsTr("Skopiowano: ") + scientificName)
            }
          }
        }
      }

      Flickable {
        Layout.fillWidth: true
        Layout.preferredHeight: visible ? Math.min(cechyKol.implicitHeight, 170) : 0
        visible: plugin.cechyWiersze.length > 0
        contentHeight: cechyKol.implicitHeight
        clip: true

        Column {
          id: cechyKol
          width: parent.width
          spacing: 3

          Label {
            width: parent.width
            text: qsTr("Czym je rozróżnić:")
            color: "#00838F"
            font.bold: true
          }

          Repeater {
            model: plugin.cechyWiersze

            Column {
              width: cechyKol.width
              spacing: 0

              Label {
                width: parent.width
                text: modelData.naglowek
                color: "#2E7D32"
                font.bold: true
                font.pointSize: 9
                wrapMode: Text.WordWrap
              }

              Label {
                width: parent.width
                text: modelData.tekst
                color: "#424242"
                font.pointSize: 9
                wrapMode: Text.WordWrap
              }
            }
          }
        }
      }

      Label {
        Layout.fillWidth: true
        text: qsTr("Do 5 zdjęć tej samej rośliny — przycisk pod miniaturą przełącza, co widać. Dotknij wyniku, aby skopiować nazwę. Dane: Pl@ntNet (my.plantnet.org).")
        wrapMode: Text.WordWrap
        font.pointSize: 9
        color: "#9e9e9e"
      }
    }
  }

  // ---------------------------------------------------------- logika

  function currentLatLon() {
    try {
      var ms = iface.mapCanvas().mapSettings
      var wgs = GeometryUtils.reprojectPointToWgs84(ms.center, ms.destinationCrs)
      if (Math.abs(wgs.y) <= 90 && Math.abs(wgs.x) <= 180)
        return { lat: wgs.y, lon: wgs.x }
    } catch (e) {
    }
    return null
  }

  function today() {
    var d = new Date()
    return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate()
  }

  // Ustala florę i woła done(idFlory). Dla trybu auto pyta Pl@ntNet
  // o projekty właściwe dla pozycji; wynik pamięta do końca dnia.
  function resolveFlora(done) {
    if (pluginSettings.flora !== "auto-geo") {
      done(pluginSettings.flora)
      return
    }
    if (pluginSettings.autoFloraId !== "" && pluginSettings.autoFloraDay === today()) {
      done(pluginSettings.autoFloraId)
      return
    }
    var pos = currentLatLon()
    if (!pos) {
      statusLabel.step(qsTr("Nie znam pozycji — używam flory Europy Środkowej."))
      done("k-middle-europe")
      return
    }
    statusLabel.step(qsTr("Ustalam florę dla pozycji…"))
    var xhr = new XMLHttpRequest()
    xhr.open("GET", "https://my-api.plantnet.org/v2/projects"
             + "?lat=" + pos.lat.toFixed(4) + "&lon=" + pos.lon.toFixed(4)
             + "&api-key=" + encodeURIComponent(pluginSettings.apiKey.trim()))
    xhr.timeout = 20000
    xhr.ontimeout = function () {
      statusLabel.step(qsTr("Brak odpowiedzi o florę — używam Europy Środkowej."))
      done("k-middle-europe")
    }
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== XMLHttpRequest.DONE)
        return
      var flora = "k-middle-europe"
      var title = ""
      try {
        var arr = JSON.parse(xhr.responseText)
        for (var i = 0; i < arr.length; i++) {
          if (arr[i].id && arr[i].id.indexOf("k-") === 0) {
            flora = arr[i].id
            title = arr[i].title || arr[i].id
            break
          }
        }
      } catch (e) {
      }
      if (title !== "") {
        pluginSettings.autoFloraId = flora
        pluginSettings.autoFloraTitle = title
        pluginSettings.autoFloraDay = today()
        statusLabel.step(qsTr("Flora dla pozycji: ") + title)
      } else {
        statusLabel.step(qsTr("Nie ustaliłem flory — używam Europy Środkowej."))
      }
      done(flora)
    }
    xhr.send()
  }

  function skrocNazwe(n) {
    var cz = String(n).split(" ")
    return cz.length > 1 ? cz[0][0] + ". " + cz.slice(1).join(" ") : n
  }

  // Porownanie cech kandydatow z tabeli WF_CECHY (wf_wskazniki.gpkg).
  function zbudujCechy() {
    cechyWiersze = []
    if (!cechyStore || typeof cechyStore.speciesCechy !== "function")
      return
    var home = projectHome()
    if (home === "")
      return
    try {
      cechyStore.open(qgisProject.homePath)
    } catch (e) {
      return
    }
    var kolejnosc = ["JEZYCZEK", "POCHWY", "BLASZKA", "OSCI", "ROZLOGI", "KWIATOSTAN", "POKROJ", "KLOSKI", "USZKA", "WYSOKOSC_CM", "SIEDLISKO", "KWITNIENIE"]
    var kand = []
    for (var i = 0; i < resultsModel.count && kand.length < 3; i++) {
      var c = cechyStore.speciesCechy(resultsModel.get(i).scientificName)
      if (c && c.GATUNEK !== undefined)
        kand.push({ nazwa: String(c.GATUNEK), rob: String(c.WERYFIKACJA || "").trim() === "", c: c })
    }
    if (kand.length === 0)
      return
    var out = []
    for (var j = 0; j < kand.length; j++) {
      var v = String(kand[j].c.CECHA_KLUCZOWA || "").trim()
      if (v !== "")
        out.push({ naglowek: skrocNazwe(kand[j].nazwa) + (kand[j].rob ? " (rob.)" : ""), tekst: v })
    }
    if (kand.length >= 2) {
      var dodane = 0
      for (var k = 0; k < kolejnosc.length; k++) {
        var kn = kolejnosc[k]
        var vals = kand.map(function (x) { return String(x.c[kn] || "").trim() })
        if (vals.filter(function (x) { return x !== "" }).length < 2)
          continue
        var rozne = false
        for (var m = 1; m < vals.length; m++)
          if (vals[m] !== "" && vals[0] !== "" && vals[m] !== vals[0])
            rozne = true
        if (!rozne)
          continue
        out.push({ naglowek: "≠ " + kn.toLowerCase(),
                   tekst: kand.map(function (x, idx) { return skrocNazwe(x.nazwa) + ": " + (vals[idx] || "—") }).join("   •   ") })
        if (++dodane >= 3)
          break
      }
    }
    cechyWiersze = out
  }

  function str2bytes(s) {
    var u = unescape(encodeURIComponent(s))
    var arr = new Uint8Array(u.length)
    for (var i = 0; i < u.length; i++)
      arr[i] = u.charCodeAt(i)
    return arr
  }

  function identify() {
    plugin.busy = true
    resultsModel.clear()
    plugin.cechyWiersze = []
    var stage = "start"
    try {
      var boundary = "----WorkFieldPlantNet" + Date.now()
      var parts = []
      var totalKB = 0

      for (var i = 0; i < photosModel.count; i++) {
        var ph = photosModel.get(i)
        stage = "czytanie " + (i + 1) + "/" + photosModel.count + ": " + ph.path
        statusLabel.step(qsTr("Czytam zdjęcie ") + (i + 1) + "/" + photosModel.count + "…")
        var content = FileUtils.readFileContent(ph.path)
        var blen = (content && content.byteLength !== undefined) ? content.byteLength : -1
        if (blen <= 0) {
          statusLabel.error(qsTr("Zdjęcie ") + (i + 1) + qsTr(" nieczytelne (0 bajtów): ") + ph.path)
          return
        }
        totalKB += Math.round(blen / 1024)
        var fname = FileUtils.fileName(ph.path)
        parts.push(str2bytes("--" + boundary + "\r\n"
            + 'Content-Disposition: form-data; name="organs"\r\n\r\n'
            + ph.organ + "\r\n"
            + "--" + boundary + "\r\n"
            + 'Content-Disposition: form-data; name="images"; filename="' + fname + '"\r\n'
            + "Content-Type: image/jpeg\r\n\r\n"))
        parts.push(new Uint8Array(content))
        parts.push(str2bytes("\r\n"))
      }
      parts.push(str2bytes("--" + boundary + "--\r\n"))

      stage = "sklejanie treści zapytania"
      var total = 0
      for (var j = 0; j < parts.length; j++)
        total += parts[j].length
      var body = new Uint8Array(total)
      var off = 0
      for (var k = 0; k < parts.length; k++) {
        body.set(parts[k], off)
        off += parts[k].length
      }

      statusLabel.step(qsTr("Wysyłam ") + photosModel.count + qsTr(" zdj. (")
                       + totalKB + qsTr(" KB) do Pl@ntNet…"))
      plugin.resolveFlora(function (floraId) {
        plugin.sendToPlantNet(body, boundary, floraId)
      })
    } catch (e) {
      statusLabel.error(qsTr("Błąd: ") + e + qsTr(" [etap: ") + stage + "]")
    }
  }

  function sendToPlantNet(body, boundary, floraId) {
    var url = "https://my-api.plantnet.org/v2/identify/"
        + encodeURIComponent(floraId)
        + "?api-key=" + encodeURIComponent(pluginSettings.apiKey.trim())
        + "&lang=pl&nb-results=6"

    try {
      var xhr = new XMLHttpRequest()
      xhr.open("POST", url)
      xhr.timeout = 60000
      xhr.ontimeout = function () {
        statusLabel.error(qsTr("Serwer nie odpowiedział w 60 s. Sprawdź zasięg."))
      }
      xhr.setRequestHeader("Content-Type", "multipart/form-data; boundary=" + boundary)
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== XMLHttpRequest.DONE)
          return
        plugin.busy = false
        if (xhr.status === 200) {
          statusLabel.step("")
          plugin.showResults(xhr.responseText)
        } else if (xhr.status === 401) {
          statusLabel.error(qsTr("Błędny klucz API (401). Sprawdź klucz na my.plantnet.org."))
        } else if (xhr.status === 404) {
          statusLabel.error(qsTr("Brak dopasowania w tej florze (404) — spróbuj przełączyć florę na inną."))
        } else if (xhr.status === 413) {
          statusLabel.error(qsTr("Zdjęcia łącznie za duże (413) — usuń któreś i spróbuj ponownie."))
        } else if (xhr.status === 429) {
          statusLabel.error(qsTr("Wyczerpany dzienny limit zapytań (429)."))
        } else if (xhr.status === 0) {
          statusLabel.error(qsTr("Brak odpowiedzi (status 0) — problem z siecią lub wysyłką."))
        } else {
          statusLabel.error(qsTr("Błąd serwera: ") + xhr.status + " "
                            + xhr.responseText.substring(0, 120))
        }
      }
      xhr.send(body.buffer)
    } catch (e) {
      statusLabel.error(qsTr("Błąd przy wysyłce: ") + e)
    }
  }

  function showResults(responseText) {
    try {
      var json = JSON.parse(responseText)
      var results = json.results || []
      if (results.length === 0) {
        statusLabel.error(qsTr("Brak wyników."))
        return
      }
      for (var i = 0; i < results.length; i++) {
        var r = results[i]
        var common = ""
        if (r.species.commonNames && r.species.commonNames.length > 0)
          common = r.species.commonNames.join(", ")
        resultsModel.append({
          score: Math.round(r.score * 100),
          scientificName: r.species.scientificNameWithoutAuthor,
          commonName: common
        })
      }
      plugin.zbudujCechy()
    } catch (e) {
      statusLabel.error(qsTr("Nie udało się odczytać odpowiedzi serwera: ") + e)
    }
  }
}
